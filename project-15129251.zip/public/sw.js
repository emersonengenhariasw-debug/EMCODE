/* =====================================================================
   JULY QUARTZO — Borracharia Digital — Service Worker
   Guarda APENAS a casca da interface (HTML + arquivos estáticos do site).
   Nunca armazena: respostas do Backend, dados das ordens de serviço,
   fotos, histórico ou qualquer requisição sensível.
   Requisições para outro domínio (Backend, storage, CDNs, APIs) são
   ignoradas e seguem direto para a rede.
   ===================================================================== */

/* A versão do cache muda a cada publicação: garante que a versão antiga
   nunca fique presa e impeça a abertura do sistema. */
const CACHE = "jqz-shell-v3";
const CORE = ["./", "./index.html"];

/* Nunca guardamos na cache o próprio service worker nem o manifesto:
   o navegador precisa sempre buscar a versão nova para permitir a
   atualização do aplicativo instalado. */
function isBypass(url) {
  const p = url.pathname;
  return (
    p.endsWith("/sw.js") ||
    p.endsWith("/manifest.webmanifest") ||
    p.endsWith("/.well-known/assetlinks.json")
  );
}

self.addEventListener("install", (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches
      .open(CACHE)
      .then((cache) => Promise.allSettled(CORE.map((u) => cache.add(u))))
      .catch(() => {})
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      try {
        const keys = await caches.keys();
        await Promise.all(
          keys.filter((key) => key !== CACHE).map((key) => caches.delete(key))
        );
      } catch (e) {
        /* limpeza silenciosa */
      }
      await self.clients.claim();
    })()
  );
});

/* Quando a interface pede, assume o controle imediatamente (troca de versão). */
self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") self.skipWaiting();
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  let url;
  try {
    url = new URL(request.url);
  } catch (e) {
    return;
  }

  // Só atua no próprio domínio do site. Backend, storage e CDNs externos
  // passam direto — nenhum dado sensível é colocado em cache.
  if (url.origin !== self.location.origin) return;

  // Service worker e manifesto: sempre direto para a rede.
  if (isBypass(url)) return;

  // Navegação (abrir o app): rede primeiro; se estiver offline, devolve a
  // casca salva. A resposta boa mais recente é arquivada para uso offline.
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response && response.ok && response.type === "basic") {
            const copy = response.clone();
            caches
              .open(CACHE)
              .then((cache) => cache.put("./index.html", copy))
              .catch(() => {});
          }
          return response;
        })
        .catch(() =>
          caches
            .match("./index.html")
            .then((cached) => cached || caches.match("./"))
            .then((cached) => cached || Response.error())
        )
    );
    return;
  }

  // Arquivos estáticos da interface: cache primeiro, rede como reforço.
  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request)
        .then((response) => {
          if (response && response.ok && response.type === "basic") {
            const copy = response.clone();
            caches
              .open(CACHE)
              .then((cache) => cache.put(request, copy))
              .catch(() => {});
          }
          return response;
        })
        .catch(() => Response.error());
    })
  );
});