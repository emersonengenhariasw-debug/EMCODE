import * as ExcelJS from "exceljs";
import type { SavedOs } from "@/lib/osTypes";
import { getOs, saveOs } from "@/lib/osDb";
import { logOsChanges, type OsChangeInput } from "@/lib/osChangeLog";
import { isBackendReady, supabase } from "@/lib/supabase";
import { OS_MOTIVES } from "@/mocks/osForm";

/*
 * SINCRONIZAÇÃO EXCEL ↔ SISTEMA (vai-e-volta do arquivo).
 *
 * A planilha leva dois identificadores escondidos por linha:
 *   _OS_ID   → Nº único da OS (nunca muda, mesmo que a célula "Nº OS" seja editada)
 *   _PNEU_ID → Nº da OS + posição do pneu (ex.: "12-P3")
 * Com eles, cada linha do Excel é casada com o pneu exato do banco — nunca
 * pela posição da linha, então nunca altera a OS errada nem duplica registro.
 *
 * O sistema guarda uma "foto" (baseline) de cada OS no momento da exportação.
 * O conflito é detectado comparando: valor do Excel × valor atual do sistema
 * × valor da última foto. Se o sistema mudou E o Excel mudou no mesmo campo,
 * é conflito — o usuário escolhe qual vale, e a decisão vai pro histórico.
 */

const SYNC_TABLE = "tire_os_sync";
const TIRE_TABLE = "tire_os";

interface ColMap {
  col: number;
  path: string;
  label: string;
  date?: boolean;
  numeric?: boolean;
}

/* Coluna (1-based, na aba CONTROLE DE PNEUS) → campo do sistema. */
const EDITABLE: ColMap[] = [
  { col: 1, path: "equip", label: "EQUIPAMENTO" },
  { col: 2, path: "retirados.{i}.posicao", label: "POSIÇÃO" },
  { col: 3, path: "retirados.{i}.fogo", label: "FOGO (retirado)" },
  { col: 4, path: "retirados.{i}.marca", label: "MARCA (retirado)" },
  { col: 6, path: "dataEntrada", label: "DATA DE ENTRADA", date: true },
  { col: 7, path: "dataSaida", label: "DATA DE SAÍDA", date: true },
  { col: 8, path: "horimetro", label: "HORÍMETRO ENTRADA", numeric: true },
  { col: 9, path: "horimetro", label: "HORÍMETRO SAÍDA", numeric: true },
  { col: 11, path: "instalados.{i}.mm", label: "MM ENTRADA", numeric: true },
  { col: 12, path: "retirados.{i}.mm", label: "MM SAÍDA", numeric: true },
  { col: 14, path: "retirados.{i}.motivo", label: "MOTIVO RETIRADA" },
  { col: 19, path: "instalados.{i}.marca", label: "MARCA INSTALADO" },
  { col: 20, path: "instalados.{i}.fogo", label: "FOGO INSTALADO" },
];

/* ---------------------------------------------------- arquivo profissional */

interface ProField {
  path: string;
  label: string;
  date?: boolean;
  numeric?: boolean;
  motive?: boolean;
}

const filledRet = (r?: { marca?: string; fogo?: string; mm?: string }) =>
  Boolean(r && ((r.marca || "").trim() || (r.fogo || "").trim() || (r.mm || "").trim()));
const filledIns = (t?: { marca?: string; fogo?: string; mm?: string }) =>
  Boolean(t && ((t.marca || "").trim() || (t.fogo || "").trim() || (t.mm || "").trim()));

/** Motivo sem o código, sem caixa e sem acento de diferença — base de comparação. */
const normMotive = (t: string) =>
  (t || "").replace(/^\s*\d+\s*-\s*/, "").trim().toUpperCase();

/** Recupera o motivo canônico (com o código) a partir do texto da planilha. */
function resolveMotive(text: string): string {
  const key = normMotive(text);
  if (!key) return text;
  const hit = OS_MOTIVES.flat().find((m) => normMotive(m) === key);
  return hit ?? text;
}

/**
 * Mapeia uma coluna do arquivo PROFISSIONAL para o campo do sistema.
 * O destino depende do estado real da OS (a mesma coluna "FOGO" pode ser
 * o fogo do retirado ou do instalado), então decidimos linha a linha.
 */
function proTarget(header: string, os: SavedOs, slot: number): ProField | null {
  const hasRet = filledRet(os.retirados[slot]);
  const hasIns = filledIns(os.instalados[slot]);
  switch (header) {
    case "CB / EQUIP.":
      return { path: "equip", label: "EQUIPAMENTO" };
    case "POSIÇÃO":
      return hasRet ? { path: "retirados.{i}.posicao", label: "POSIÇÃO" } : null;
    case "FOGO":
      return hasRet
        ? { path: "retirados.{i}.fogo", label: "FOGO (retirado)" }
        : { path: "instalados.{i}.fogo", label: "FOGO (instalado)" };
    case "MARCA":
      return hasRet
        ? { path: "retirados.{i}.marca", label: "MARCA (retirado)" }
        : { path: "instalados.{i}.marca", label: "MARCA (instalado)" };
    case "DATA ENTRADA":
      return { path: "dataEntrada", label: "DATA DE ENTRADA", date: true };
    case "DATA SAÍDA":
      return { path: "dataSaida", label: "DATA DE SAÍDA", date: true };
    case "HORÍMETRO ENTRADA":
      return { path: "horimetro", label: "HORÍMETRO ENTRADA", numeric: true };
    case "HORÍMETRO SAÍDA":
      return { path: "horimetro", label: "HORÍMETRO SAÍDA", numeric: true };
    case "MM ENTRADA":
      return hasIns ? { path: "instalados.{i}.mm", label: "MM ENTRADA", numeric: true } : null;
    case "MM SAÍDA":
      return hasRet ? { path: "retirados.{i}.mm", label: "MM SAÍDA", numeric: true } : null;
    case "MOTIVO RETIRADA":
      return hasRet ? { path: "retirados.{i}.motivo", label: "MOTIVO RETIRADA", motive: true } : null;
    default:
      return null;
  }
}

export interface FieldChange {
  key: string;
  osNumero: string;
  pneuId: string;
  slot: number;
  path: string;
  label: string;
  base: string;
  db: string;
  xls: string;
  /** Valor efetivamente gravado (quando difere do exibido, ex.: motivo). */
  applyValue?: string;
  conflict: boolean;
}

export interface ImportResult {
  fileName: string;
  rowsRead: number;
  changes: FieldChange[];
  notFound: string[];
}

export interface ImportDecision {
  change: FieldChange;
  useExcel: boolean;
}

/* ---------------------------------------------------------------- leitura */

/** Converte o valor cru de uma célula do ExcelJS em texto. */
function cellText(value: unknown): string {
  if (value === null || value === undefined) return "";
  if (typeof value === "string") return value;
  if (typeof value === "number") return String(value);
  if (typeof value === "boolean") return value ? "SIM" : "";
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  if (typeof value === "object") {
    const v = value as Record<string, unknown>;
    if (typeof v.text === "string") return v.text;
    if (Array.isArray(v.richText)) {
      return (v.richText as { text?: string }[]).map((r) => r.text ?? "").join("");
    }
    if (v.result !== undefined) return cellText(v.result);
  }
  return "";
}

/** DD/MM/AAAA (ou ISO) → ISO AAAA-MM-DD. Preserva o original se não reconhecer. */
function toIsoDate(raw: string): string {
  const s = (raw || "").trim();
  if (!s) return "";
  const br = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(s);
  if (br) return `${br[3]}-${br[2]}-${br[1]}`;
  const iso = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;
  return s;
}

/** Normaliza números (vírgula → ponto, sem zeros inúteis) para comparar. */
function numStr(v: string): string {
  const t = (v ?? "").trim().replace(",", ".");
  if (!t) return "";
  const n = Number(t);
  return Number.isFinite(n) ? String(n) : t;
}

/** Posição do pneu a partir do _PNEU_ID (ex.: "12-P3" → 2). */
function slotOf(pneuId: string, rowNumber: number): number {
  const m = /-P(\d+)\s*$/.exec(pneuId);
  if (m) return Math.max(0, parseInt(m[1], 10) - 1);
  return Math.max(0, rowNumber - 3);
}

function getOsValue(os: SavedOs, path: string, slot: number): string {
  const m = /^(retirados|instalados)\.\{i\}\.(posicao|marca|fogo|mm|motivo|vidas)$/.exec(path);
  if (m) {
    const arr =
      m[1] === "retirados"
        ? (os.retirados as unknown as Record<string, string>[])
        : (os.instalados as unknown as Record<string, string>[]);
    const item = arr?.[slot];
    return item ? String(item[m[2]] ?? "") : "";
  }
  return String((os as unknown as Record<string, unknown>)[path] ?? "");
}

function setOsValue(os: SavedOs, path: string, slot: number, value: string): SavedOs {
  const clone: SavedOs = {
    ...os,
    retirados: os.retirados.map((r) => ({ ...r })),
    instalados: os.instalados.map((r) => ({ ...r })),
  };
  const m = /^(retirados|instalados)\.\{i\}\.(posicao|marca|fogo|mm|motivo|vidas)$/.exec(path);
  if (m) {
    if (m[1] === "retirados") {
      while (clone.retirados.length <= slot) {
        clone.retirados.push({ posicao: "", marca: "", fogo: "", mm: "", motivo: "", vidas: "" });
      }
      (clone.retirados[slot] as unknown as Record<string, string>)[m[2]] = value;
    } else {
      while (clone.instalados.length <= slot) {
        clone.instalados.push({ marca: "", fogo: "", mm: "", vidas: "" });
      }
      (clone.instalados[slot] as unknown as Record<string, string>)[m[2]] = value;
    }
  } else {
    (clone as unknown as Record<string, unknown>)[path] = value;
  }
  return clone;
}

/* --------------------------------------------------------- dados do banco */

async function loadAllOs(): Promise<Map<string, SavedOs>> {
  const map = new Map<string, SavedOs>();
  if (!isBackendReady) return map;
  const { data, error } = await supabase
    .from(TIRE_TABLE)
    .select("numero, data, finalized, saved_at");
  if (error) throw new Error(error.message);
  (data ?? []).forEach((row) => {
    const r = row as { numero: string; data: SavedOs; finalized: boolean; saved_at: string };
    map.set(r.numero, {
      ...(r.data as SavedOs),
      numero: r.numero,
      id: r.numero,
      finalized: r.finalized,
      savedAt: r.saved_at,
    });
  });
  return map;
}

async function loadBaselines(): Promise<Map<string, SavedOs>> {
  const map = new Map<string, SavedOs>();
  if (!isBackendReady) return map;
  const { data, error } = await supabase.from(SYNC_TABLE).select("numero, baseline");
  if (error) return map;
  (data ?? []).forEach((row) => {
    const r = row as { numero: string; baseline: SavedOs };
    if (r.baseline) map.set(r.numero, r.baseline);
  });
  return map;
}

/** Guarda a "foto" do que foi para a planilha, para detectar mudanças depois. */
export async function captureBaselines(orders: SavedOs[]): Promise<void> {
  if (!isBackendReady || !orders.length) return;
  const now = new Date().toISOString();
  const rows = orders
    .map((o) => ({
      numero: (o.numero || o.id || "").trim(),
      baseline: o,
      baseline_at: now,
      updated_at: now,
    }))
    .filter((r) => r.numero);
  if (!rows.length) return;
  try {
    await supabase.from(SYNC_TABLE).upsert(rows, { onConflict: "numero" });
  } catch {
    /* a foto é opcional — sem ela, o import apenas não detecta conflito fino */
  }
}

/* ---------------------------------------------------------------- análise */

/** Lê a planilha editada e devolve as mudanças (com marcação de conflito). */
export async function parseExcelImport(file: File): Promise<ImportResult> {
  const buffer = await file.arrayBuffer();
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buffer);

  const normHead = (s: string) => s.replace(/\s+/g, " ").trim().toUpperCase();

  // Aceita tanto o formato antigo ("CONTROLE DE PNEUS") quanto o novo
  // arquivo profissional (aba "Controle de Pneus").
  const ws =
    wb.getWorksheet("CONTROLE DE PNEUS") ??
    wb.getWorksheet("Controle de Pneus") ??
    (wb.worksheets.find((w) => /controle/i.test(w.name) && /pneu/i.test(w.name)) ?? undefined) ??
    wb.worksheets[0];
  if (!ws) return { fileName: file.name, rowsRead: 0, changes: [], notFound: [] };

  const headers: string[] = [];
  ws.getRow(2).eachCell((cell, col) => {
    headers[col] = normHead(cellText(cell.value));
  });
  const colOf = (name: string) => headers.findIndex((h) => h === name);
  const cOsId = colOf("_OS_ID");
  const cPneuId = colOf("_PNEU_ID");
  const cNumero = colOf("Nº OS");
  // O arquivo profissional é reconhecido pela coluna "CB / EQUIP.".
  const isPro = colOf("CB / EQUIP.") > 0;

  const proHeaders: { col: number; header: string }[] = [];
  if (isPro) {
    headers.forEach((h, col) => {
      if (col > 0 && h) proHeaders.push({ col, header: h });
    });
  }

  const dbMap = await loadAllOs();
  const baselineMap = await loadBaselines();

  const changes: FieldChange[] = [];
  const notFound = new Set<string>();
  let rowsRead = 0;

  ws.eachRow((row, rowNumber) => {
    if (rowNumber <= 2) return;
    const osIdCell = cOsId > 0 ? cellText(row.getCell(cOsId).value).trim() : "";
    const numero = osIdCell || (cNumero > 0 ? cellText(row.getCell(cNumero).value).trim() : "");
    if (!numero) return;

    const os = dbMap.get(numero);
    if (!os) {
      notFound.add(numero);
      return;
    }

    const pneuIdCell = cPneuId > 0 ? cellText(row.getCell(cPneuId).value).trim() : "";
    const pneuId = pneuIdCell || `${numero}-P${rowNumber - 2}`;
    const slot = slotOf(pneuId, rowNumber);
    const base = baselineMap.get(numero) ?? os;

    interface XlsEntry {
      raw: string;
      label: string;
      date?: boolean;
      numeric?: boolean;
      motive?: boolean;
    }
    const xlsByPath = new Map<string, XlsEntry>();
    const pushEntry = (path: string, entry: XlsEntry) => {
      const prev = xlsByPath.get(path);
      if (!prev || (entry.raw.trim() && !prev.raw.trim())) xlsByPath.set(path, entry);
    };

    if (isPro) {
      proHeaders.forEach(({ col, header }) => {
        const target = proTarget(header, os, slot);
        if (!target) return;
        pushEntry(target.path, { raw: cellText(row.getCell(col).value), ...target });
      });
    } else {
      EDITABLE.forEach((map) => {
        pushEntry(map.path, {
          raw: cellText(row.getCell(map.col).value),
          label: map.label,
          date: map.date,
          numeric: map.numeric,
        });
      });
    }

    xlsByPath.forEach((entry, path) => {
      const rawText = entry.raw.trim();
      const dbRaw = getOsValue(os, path, slot);
      const baseRaw = getOsValue(base, path, slot);

      // Motivo: compara ignorando o código e a grafia, senão o texto "bonito"
      // da planilha apareceria como mudança em toda importação.
      if (entry.motive) {
        if (normMotive(rawText) === normMotive(dbRaw)) return;
        const conflict = normMotive(dbRaw) !== normMotive(baseRaw);
        changes.push({
          key: `${numero}|${pneuId}|${path}`,
          osNumero: numero,
          pneuId,
          slot,
          path,
          label: entry.label,
          base: baseRaw,
          db: dbRaw,
          xls: rawText,
          applyValue: resolveMotive(rawText),
          conflict,
        });
        return;
      }

      const xlsVal = entry.date ? toIsoDate(rawText) : entry.numeric ? numStr(rawText) : rawText;
      const dbVal = entry.numeric ? numStr(dbRaw) : dbRaw;
      const baseVal = entry.numeric ? numStr(baseRaw) : baseRaw;

      if (xlsVal === dbVal) return; // nada mudou
      if (xlsVal === baseVal) return; // só o sistema mudou — o Excel não toca

      const conflict = dbVal !== baseVal; // sistema e Excel mudaram os dois
      changes.push({
        key: `${numero}|${pneuId}|${path}`,
        osNumero: numero,
        pneuId,
        slot,
        path,
        label: entry.label,
        base: baseVal,
        db: dbVal,
        xls: xlsVal,
        applyValue: xlsVal,
        conflict,
      });
    });

    rowsRead += 1;
  });

  return { fileName: file.name, rowsRead, changes, notFound: Array.from(notFound) };
}

/* ---------------------------------------------------------------- aplicar */

/** Aplica as decisões: atualiza as OS, grava no histórico e renova a foto. */
export async function applyImport(
  decisions: ImportDecision[],
): Promise<{ osCount: number; applied: number }> {
  if (!isBackendReady) throw new Error("Backend não configurado.");

  const byOs = new Map<string, ImportDecision[]>();
  decisions.forEach((d) => {
    const arr = byOs.get(d.change.osNumero) ?? [];
    arr.push(d);
    byOs.set(d.change.osNumero, arr);
  });

  let applied = 0;
  const logEntries: OsChangeInput[] = [];
  const baselines: SavedOs[] = [];

  for (const [numero, list] of Array.from(byOs.entries())) {
    const current = await getOs(numero);
    if (!current) continue;

    let next: SavedOs = current;
    list.forEach((d) => {
      if (d.useExcel) {
        const value = d.change.applyValue ?? d.change.xls;
        next = setOsValue(next, d.change.path, d.change.slot, value);
        logEntries.push({
          osNumero: numero,
          pneuId: d.change.pneuId,
          campo: d.change.label,
          valorAnterior: d.change.db,
          valorNovo: value,
          origem: "excel",
        });
        applied += 1;
      } else {
        logEntries.push({
          osNumero: numero,
          pneuId: d.change.pneuId,
          campo: `${d.change.label} (conflito — mantido o sistema)`,
          valorAnterior: d.change.xls,
          valorNovo: d.change.db,
          origem: "excel",
        });
      }
    });

    next = { ...next, savedAt: new Date().toISOString() };
    await saveOs(next);
    baselines.push(next);
  }

  await logOsChanges(logEntries);
  await captureBaselines(baselines);
  return { osCount: byOs.size, applied };
}