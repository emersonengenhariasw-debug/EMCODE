import type { OsPhotoDraft } from "@/lib/osTypes";

/*
 * Cópia carimbada das fotos da OS.
 * A foto ORIGINAL guardada no Backend nunca é alterada: o sistema gera uma
 * CÓPIA com a data e a hora impressas em um pequeno texto no rodapé.
 * - Quando a data/hora real da captura está disponível (arquivo da câmera),
 *   usa-se ela ("Captura").
 * - Caso contrário, usa-se a data/hora em que a foto foi salva no sistema
 *   ("Salvo em"), identificando corretamente a informação.
 */

const pad = (n: number) => String(n).padStart(2, "0");

/** Formata "DD/MM/AAAA HH:MM". */
export function formatStamp(d: Date): string {
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** Texto do rodapé: captura (se houver) ou salvamento no sistema. */
export function photoStampCaption(photo: OsPhotoDraft): string {
  const captured = photo.file?.lastModified ? new Date(photo.file.lastModified) : null;
  if (captured && !Number.isNaN(captured.getTime())) {
    return `Captura: ${formatStamp(captured)}`;
  }
  const saved = photo.uploadedAt ? new Date(photo.uploadedAt) : null;
  if (saved && !Number.isNaN(saved.getTime())) {
    return `Salvo em: ${formatStamp(saved)}`;
  }
  return `Salvo em: ${formatStamp(new Date())}`;
}

function loadImage(src: string, crossOrigin = false): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    if (crossOrigin) img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Não foi possível abrir a imagem."));
    img.src = src;
  });
}

/**
 * Gera e baixa uma cópia da foto com a data/hora no rodapé.
 * Usa fetch → blob para evitar o bloqueio de "canvas contaminado" (CORS).
 */
export async function downloadPhotoWithStamp(
  url: string,
  filename: string,
  caption: string,
): Promise<void> {
  if (!url) throw new Error("Foto indisponível para download.");

  let img: HTMLImageElement;
  let objectUrl = "";
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error("fetch");
    const blob = await res.blob();
    objectUrl = URL.createObjectURL(blob);
    img = await loadImage(objectUrl);
  } catch {
    // Pré-visualização local (blob:) — não passa por fetch/CORS.
    img = await loadImage(url, true);
  }

  const w = img.naturalWidth || img.width;
  const h = img.naturalHeight || img.height;
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    throw new Error("Não foi possível preparar a imagem.");
  }
  ctx.drawImage(img, 0, 0, w, h);

  const fs = Math.max(14, Math.round(w * 0.024));
  const padPx = Math.round(fs * 0.55);
  const barH = fs + padPx * 2;
  ctx.fillStyle = "rgba(0,0,0,0.58)";
  ctx.fillRect(0, h - barH, w, barH);
  ctx.fillStyle = "#ffffff";
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";
  ctx.font = `700 ${fs}px Arial, Helvetica, sans-serif`;
  ctx.fillText(caption, padPx, h - barH / 2);

  const outBlob: Blob = await new Promise((resolve, reject) => {
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error("Falha ao gerar a imagem."))),
      "image/jpeg",
      0.92,
    );
  });
  if (objectUrl) URL.revokeObjectURL(objectUrl);

  const dl = URL.createObjectURL(outBlob);
  const a = document.createElement("a");
  a.href = dl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(dl), 4000);
}