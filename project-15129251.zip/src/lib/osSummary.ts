import type { SavedOs } from "@/lib/osTypes";
import { OS_MOTIVES } from "@/mocks/osForm";

/*
  Motive aggregation for finalized work orders.

  Totals are built from BOTH sources asked for by the operation:
  1. the MOTIVO(S)/CAUSA(S) checkboxes of each OS (`motivos`), and
  2. the free-text MOTIVO typed on every removed tire (`retirados[].motivo`).

  Free text is normalized (accents/case/spacing) and resolved against the
  official list so "FURO POR METAL", "11 - furo por metal" and
  "11-FURO POR METAL" all land on the same official code.
*/

export interface MotiveAgg {
  key: string;
  code: string;
  label: string;
  short: string;
  count: number;
}

export interface MotiveSummary {
  items: MotiveAgg[];
  total: number;
  osCount: number;
  tires: number;
}

const stripAccents = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "");

const norm = (s: string) => stripAccents(s).toUpperCase().replace(/\s+/g, " ").trim();

interface Canon {
  full: string;
  short: string;
  code: string;
  nfull: string;
  nshort: string;
}

const CANON: Canon[] = OS_MOTIVES.flat().map((full) => {
  const m = full.match(/^(\d+)\s*-\s*(.*)$/);
  const code = m ? m[1] : "";
  const short = m ? m[2] : full;
  return { full, short, code, nfull: norm(full), nshort: norm(short) };
});

interface Resolved {
  key: string;
  code: string;
  label: string;
  short: string;
}

function resolve(raw: string): Resolved {
  const n = norm(raw);

  const byText = CANON.find((c) => c.nfull === n || c.nshort === n);
  if (byText) {
    return { key: byText.full, code: byText.code, label: byText.full, short: byText.short };
  }

  const codeMatch = n.match(/^(\d+)\b/);
  if (codeMatch) {
    const candidates = CANON.filter((c) => c.code === codeMatch[1]);
    if (candidates.length === 1) {
      const c = candidates[0];
      return { key: c.full, code: c.code, label: c.full, short: c.short };
    }
  }

  // Unmapped or hand-written motive — keep it, grouped by its own text.
  const clean = raw.trim();
  return { key: n || clean, code: codeMatch ? codeMatch[1] : "", label: clean, short: clean };
}

/** Aggregates every motive occurrence across the given OS records. */
export function buildMotiveSummary(orders: SavedOs[]): MotiveSummary {
  const map = new Map<string, MotiveAgg>();
  let total = 0;
  let tires = 0;

  const bump = (raw: string) => {
    if (!raw || !raw.trim()) return;
    const r = resolve(raw);
    const found = map.get(r.key);
    if (found) found.count += 1;
    else map.set(r.key, { key: r.key, code: r.code, label: r.label, short: r.short, count: 1 });
    total += 1;
  };

  orders.forEach((o) => {
    o.motivos.forEach(bump);
    o.retirados.forEach((t) => {
      if (t.motivo && t.motivo.trim()) {
        bump(t.motivo);
        tires += 1;
      }
    });
  });

  const items = Array.from(map.values()).sort(
    (a, b) => b.count - a.count || a.label.localeCompare(b.label),
  );

  return { items, total, osCount: orders.length, tires };
}

/** Keeps only OS whose date (or save date) falls inside the range. ISO yyyy-mm-dd. */
export function filterByPeriod(orders: SavedOs[], from: string, to: string): SavedOs[] {
  if (!from && !to) return orders;
  return orders.filter((o) => {
    const day = o.data || (o.savedAt ? o.savedAt.slice(0, 10) : "");
    if (!day) return false;
    if (from && day < from) return false;
    if (to && day > to) return false;
    return true;
  });
}