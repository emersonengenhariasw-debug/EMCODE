import * as ExcelJS from "exceljs";
import type { OsFormData, OsTireInstalled, OsTireRemoved, SavedOs } from "@/lib/osTypes";
import type { LostTireRecord } from "@/lib/lostTiresTypes";
import { computeKpis, monthlySeries, motiveSegments, turmaBreakdown } from "@/lib/osDashboard";

/* =====================================================================
   JULY QUARTZO — exportação para Excel
   Gera um arquivo .xlsx com as abas:
   - CONTROLE DE PNEUS           → uma linha por movimentação de pneu (fixada à OS);
   - OS FINALIZADAS              → uma linha por ordem de serviço (ficha completa);
   - INDICADORES                 → os KPIs do dashboard (OS, retirados, instalados, perdidos);
   - MOVIMENTAÇÕES POR MÊS       → série mensal (retirados × instalados);
   - MOTIVOS                     → motivos mais frequentes (com o código);
   - POR TURMA                   → movimentações por turma/letra.
   Os indicadores usam os mesmos cálculos que aparecem na tela do dashboard.
   Cabeçalhos verdes, filtros em todas as colunas, primeira linha de
   cabeçalhos congelada, larguras ajustadas e datas em DD/MM/AAAA.
   ===================================================================== */

const GREEN_TITLE = "FF1B4332";
const GREEN_HEAD = "FF2D6A4F";
const STRIPE = "FFF1F5F2";
const INK = "FF24352B";
const LINE = "FFCFD8D3";
const LINK = "FF1B5E3A";

type CellKind = "text" | "num";

/** Valor de célula: texto/número comum ou link clicável. */
type CellValue = string | number | { text: string; hyperlink: string };

interface ColSpec {
  header: string;
  width: number;
  kind: CellKind;
}

/* Ordem exata da planilha CONTROLE DE PNEUS da JULY QUARTZO. */
const CONTROLE_COLS: ColSpec[] = [
  { header: "CB / EQUIP.", width: 18, kind: "text" },
  { header: "POSIÇÃO", width: 11, kind: "text" },
  { header: "FOGO", width: 13, kind: "text" },
  { header: "MARCA", width: 15, kind: "text" },
  { header: "STATUS", width: 14, kind: "text" },
  { header: "DATA DE ENTRADA", width: 14, kind: "text" },
  { header: "DATA DE SAÍDA", width: 14, kind: "text" },
  { header: "HORÍMETRO ENTRADA", width: 16, kind: "num" },
  { header: "HORÍMETRO SAÍDA", width: 16, kind: "num" },
  { header: "HORÍMETRO RODADO", width: 16, kind: "num" },
  { header: "MM ENTRADA", width: 11, kind: "num" },
  { header: "MM SAÍDA", width: 11, kind: "num" },
  { header: "CÓD. MOTIVO", width: 11, kind: "text" },
  { header: "MOTIVO RETIRADA", width: 36, kind: "text" },
  { header: "BORRACHEIRO", width: 24, kind: "text" },
  { header: "OPERADOR", width: 24, kind: "text" },
  { header: "REFORMAS", width: 11, kind: "num" },
  { header: "Nº OS", width: 13, kind: "text" },
  { header: "MARCA INSTALADO", width: 17, kind: "text" },
  { header: "FOGO INSTALADO", width: 15, kind: "text" },
  { header: "VIDAS RETIRADO", width: 14, kind: "num" },
  { header: "VIDAS INSTALADO", width: 14, kind: "num" },
  { header: "DATA FINALIZAÇÃO", width: 16, kind: "text" },
  { header: "HORA FINALIZAÇÃO", width: 16, kind: "text" },
  { header: "OBSERVAÇÕES", width: 42, kind: "text" },
  { header: "SUPERVISOR", width: 24, kind: "text" },
  { header: "FOTOS", width: 16, kind: "text" },
];

/* Colunas-índice escondidas: identificam cada linha de movimentação para a
   sincronização (nunca mudam e não aparecem para quem usa a planilha). */
const ID_COLS: ColSpec[] = [
  { header: "_OS_ID", width: 10, kind: "text" },
  { header: "_PNEU_ID", width: 14, kind: "text" },
];

const OS_COLS: ColSpec[] = [
  { header: "Nº OS", width: 13, kind: "text" },
  { header: "DATA DE ENTRADA", width: 14, kind: "text" },
  { header: "DATA DE SAÍDA", width: 14, kind: "text" },
  { header: "HORÁRIO/TURNO", width: 14, kind: "text" },
  { header: "INÍCIO", width: 10, kind: "text" },
  { header: "TÉRMINO", width: 10, kind: "text" },
  { header: "HORÍMETRO", width: 12, kind: "num" },
  { header: "OPERADOR/CONDUTOR", width: 26, kind: "text" },
  { header: "KM", width: 10, kind: "num" },
  { header: "EQUIP.", width: 16, kind: "text" },
  { header: "EXECUTANTE(S)", width: 26, kind: "text" },
  { header: "LOCAL DA OCORRÊNCIA", width: 30, kind: "text" },
  { header: "TURNO", width: 10, kind: "text" },
  { header: "MOTIVO(S) / CAUSA(S)", width: 42, kind: "text" },
  { header: "OBSERVAÇÕES", width: 46, kind: "text" },
  { header: "DATA FINALIZAÇÃO", width: 16, kind: "text" },
  { header: "HORA FINALIZAÇÃO", width: 16, kind: "text" },
  { header: "SITUAÇÃO", width: 18, kind: "text" },
  { header: "SUPERVISOR", width: 24, kind: "text" },
];

/* Abas de indicadores do dashboard (mesmos números que aparecem na tela 02). */
const KPI_COLS: ColSpec[] = [
  { header: "INDICADOR", width: 34, kind: "text" },
  { header: "VALOR", width: 16, kind: "num" },
];

const MONTH_COLS: ColSpec[] = [
  { header: "PERÍODO (AAAA-MM)", width: 18, kind: "text" },
  { header: "MÊS", width: 12, kind: "text" },
  { header: "PNEUS RETIRADOS", width: 18, kind: "num" },
  { header: "PNEUS INSTALADOS", width: 18, kind: "num" },
];

const MOTIVE_COLS: ColSpec[] = [
  { header: "MOTIVO (CÓDIGO)", width: 42, kind: "text" },
  { header: "QUANTIDADE", width: 16, kind: "num" },
];

const TURMA_COLS: ColSpec[] = [
  { header: "TURMA / LETRA", width: 20, kind: "text" },
  { header: "MOVIMENTAÇÕES", width: 18, kind: "num" },
];

const ALL_BORDERS = {
  top: { style: "thin" as const, color: { argb: LINE } },
  left: { style: "thin" as const, color: { argb: LINE } },
  bottom: { style: "thin" as const, color: { argb: LINE } },
  right: { style: "thin" as const, color: { argb: LINE } },
};

/* ---------------------------------------------------------------- helpers */

const isFilledRemoved = (t: OsTireRemoved) =>
  Boolean(t && (t.marca || t.fogo || t.mm || t.motivo || t.vidas));

const isFilledInstalled = (t: OsTireInstalled) =>
  Boolean(t && (t.marca || t.fogo || t.mm || t.vidas));

/** ISO yyyy-mm-dd (ou datetime) → DD/MM/AAAA. */
function fmtDate(iso: string): string {
  if (!iso) return "";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : iso;
}

/** ISO datetime → HH:MM. */
function fmtTime(iso: string): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

/** Leading digits of a free-text motive = the official code. */
function codeOf(motivo: string): string {
  const m = /^\s*(\d+)/.exec(motivo || "");
  return m ? m[1] : "";
}

/** Numeric when possible, otherwise the original text (never invented). */
function toNum(v: string | number): number | string {
  if (v === "" || v === null || v === undefined) return "";
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : String(v);
}

/** Keeps one record per OS number (latest save wins) to avoid duplicated lines. */
function dedup(orders: SavedOs[]): SavedOs[] {
  const map = new Map<string, SavedOs>();
  orders.forEach((o) => {
    const key = (o.numero || o.id || "").trim() || o.id;
    const prev = map.get(key);
    if (!prev || (o.savedAt || "") >= (prev.savedAt || "")) map.set(key, o);
  });
  return Array.from(map.values()).sort((a, b) => ((a.savedAt || "") < (b.savedAt || "") ? -1 : 1));
}

/* ------------------------------------------------------------ row builders */

function photoCell(urls: string[]): CellValue {
  if (!urls.length) return "";
  return {
    text: urls.length === 1 ? "Ver foto" : `Ver ${urls.length} fotos`,
    hyperlink: urls[0],
  };
}

/** One spreadsheet line per movement: SAÍDA = removed tire, ENTRADA = installed. */
function movementRow(
  o: SavedOs,
  r: OsTireRemoved | undefined,
  ins: OsTireInstalled | undefined,
  position: number,
  photoUrls: string[],
): CellValue[] {
  const hasR = isFilledRemoved(r as OsTireRemoved);
  const hasI = isFilledInstalled(ins as OsTireInstalled);
  const status = hasR && hasI ? "SUBSTITUÍDO" : hasR ? "RETIRADO" : "INSTALADO";

  return [
    o.equip, // CB / EQUIP.
    hasR ? String(position) : "", // POSIÇÃO (numeração fixa da linha 1..10)
    hasR ? r!.fogo : "", // FOGO (retirado — preserva zeros à esquerda)
    hasR ? r!.marca : "", // MARCA (retirado)
    status, // STATUS
    hasI ? fmtDate(o.dataEntrada) : "", // DATA DE ENTRADA (pneu instalado)
    hasR ? fmtDate(o.dataSaida) : "", // DATA DE SAÍDA (pneu retirado)
    hasI ? o.horimetro : "", // HORÍMETRO ENTRADA
    hasR ? o.horimetro : "", // HORÍMETRO SAÍDA
    "", // HORÍMETRO RODADO (não existe dado por pneu — em branco)
    hasI ? ins!.mm : "", // MM ENTRADA
    hasR ? r!.mm : "", // MM SAÍDA
    hasR ? codeOf(r!.motivo) : "", // CÓD. MOTIVO
    hasR ? r!.motivo : "", // MOTIVO RETIRADA
    o.executantes, // BORRACHEIRO
    o.operador, // OPERADOR
    "", // REFORMAS (não existe no sistema — em branco)
    o.numero, // Nº OS
    hasI ? ins!.marca : "", // MARCA INSTALADO
    hasI ? ins!.fogo : "", // FOGO INSTALADO
    hasR ? r!.vidas : "", // VIDAS RETIRADO
    hasI ? ins!.vidas : "", // VIDAS INSTALADO
    fmtDate(o.finalizedAt ?? ""), // DATA FINALIZAÇÃO
    fmtTime(o.finalizedAt ?? ""), // HORA FINALIZAÇÃO
    o.observacoes, // OBSERVAÇÕES
    o.supervisorNome, // SUPERVISOR
    photoCell(photoUrls), // FOTOS (link protegido)
  ];
}

function osRow(o: SavedOs): (string | number)[] {
  return [
    o.numero,
    fmtDate(o.dataEntrada),
    fmtDate(o.dataSaida),
    o.turno,
    o.inicio,
    o.termino,
    o.horimetro,
    o.operador,
    o.km,
    o.equip,
    o.executantes,
    o.local,
    o.turma,
    o.motivos.join(" | "),
    o.observacoes,
    fmtDate(o.finalizedAt ?? ""),
    fmtTime(o.finalizedAt ?? ""),
    o.finalized ? "FINALIZADA" : "EM PREENCHIMENTO",
    o.supervisorNome,
  ];
}

/* -------------------------------------------------------------- sheet build */

function writeCell(cell: ExcelJS.Cell, value: CellValue, kind: CellKind) {
  if (value === "" || value === null || value === undefined) {
    cell.value = null;
    return;
  }
  if (typeof value === "object") {
    cell.value = { text: value.text, hyperlink: value.hyperlink };
    return;
  }
  cell.value = kind === "num" ? toNum(value) : String(value);
}

function styleBody(row: ExcelJS.Row, cols: ColSpec[], stripe: boolean, values: CellValue[]) {
  for (let c = 1; c <= cols.length; c += 1) {
    const cell = row.getCell(c);
    const v = values[c - 1];
    cell.font =
      v && typeof v === "object"
        ? { size: 10, color: { argb: LINK }, underline: true }
        : { size: 10, color: { argb: INK } };
    cell.border = ALL_BORDERS;
    cell.alignment = {
      vertical: "middle",
      horizontal: cols[c - 1].kind === "num" ? "right" : "left",
      wrapText: cols[c - 1].kind === "text" && cols[c - 1].width >= 30,
    };
    cell.numFmt = cols[c - 1].kind === "num" ? "#,##0.###" : "@";
    if (stripe) cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: STRIPE } };
  }
}

function buildSheet(
  ws: ExcelJS.Worksheet,
  title: string,
  cols: ColSpec[],
  rows: CellValue[][],
  hideFrom?: number,
) {
  cols.forEach((c, i) => {
    ws.getColumn(i + 1).width = c.width;
  });

  // Esconde as colunas-índice (a partir de hideFrom, 1-based).
  if (hideFrom && hideFrom > 0) {
    for (let c = hideFrom; c <= cols.length; c += 1) {
      ws.getColumn(c).hidden = true;
    }
  }

  // Título
  ws.mergeCells(1, 1, 1, cols.length);
  const titleCell = ws.getCell(1, 1);
  titleCell.value = title;
  titleCell.font = { bold: true, size: 12.5, color: { argb: "FFFFFFFF" } };
  titleCell.alignment = { vertical: "middle", horizontal: "left" };
  titleCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: GREEN_TITLE } };
  ws.getRow(1).height = 26;

  // Cabeçalhos
  const head = ws.getRow(2);
  cols.forEach((c, i) => {
    const cell = head.getCell(i + 1);
    cell.value = c.header;
    cell.font = { bold: true, size: 9.5, color: { argb: "FFFFFFFF" } };
    cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: GREEN_HEAD } };
    cell.alignment = { vertical: "middle", horizontal: "center", wrapText: true };
    cell.border = ALL_BORDERS;
  });
  head.height = 30;

  // Dados
  rows.forEach((values, ri) => {
    const row = ws.getRow(ri + 3);
    values.forEach((v, ci) => writeCell(row.getCell(ci + 1), v, cols[ci].kind));
    styleBody(row, cols, ri % 2 === 1, values);
  });

  // Filtro em todas as colunas + cabeçalho congelado
  const lastRow = Math.max(2, rows.length + 2);
  const lastCol = hideFrom && hideFrom > 1 ? hideFrom - 1 : cols.length;
  ws.autoFilter = { from: { row: 2, column: 1 }, to: { row: lastRow, column: lastCol } };
  ws.views = [{ state: "frozen", ySplit: 2 }];
}

/* ---------------------------------------------------------------- download */

function downloadBlob(filename: string, data: ArrayBuffer | string, mime: string) {
  const blob = new Blob([data], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

const safeName = (numero: string) => (numero || "sem-numero").replace(/[^a-zA-Z0-9-_]/g, "-");

/* ------------------------------------------------------------------ exports */

/**
 * Gera a planilha CONTROLE DE PNEUS (.xlsx) a partir das OS informadas.
 * Uma linha por movimentação, vinculada ao Nº da OS; uma aba extra com a
 * ficha completa das ordens; e as abas de indicadores do dashboard
 * (calculadas sobre TODAS as OS acumuladas, sem filtro de data).
 */
export async function exportExcel(
  orders: SavedOs[],
  photoLinks: Record<string, string[]> = {},
  lost: LostTireRecord[] = [],
): Promise<void> {
  const unique = dedup(orders);

  const wb = new ExcelJS.Workbook();
  wb.creator = "JULY QUARTZO";
  wb.created = new Date();

  const ws = wb.addWorksheet("CONTROLE DE PNEUS");
  const movements: CellValue[][] = [];
  unique.forEach((o) => {
    const urls = photoLinks[(o.numero || o.id).trim()] ?? [];
    const numero = (o.numero || o.id).trim();
    const total = Math.max(o.retirados.length, o.instalados.length);
    for (let i = 0; i < total; i += 1) {
      const r = o.retirados[i];
      const ins = o.instalados[i];
      if (!isFilledRemoved(r as OsTireRemoved) && !isFilledInstalled(ins as OsTireInstalled)) continue;
      // As duas últimas células são os identificadores escondidos (OS + pneu).
      movements.push([...movementRow(o, r, ins, i + 1, urls), numero, `${numero}-P${i + 1}`]);
    }
  });
  const controleCols = [...CONTROLE_COLS, ...ID_COLS];
  buildSheet(
    ws,
    "CONTROLE DE PNEUS — JULY QUARTZO · MINERAÇÃO E CONSTRUÇÃO",
    controleCols,
    movements,
    CONTROLE_COLS.length + 1,
  );

  const wsOs = wb.addWorksheet("OS FINALIZADAS");
  buildSheet(
    wsOs,
    "OS FINALIZADAS — JULY QUARTZO · OS - MOVIMENTAÇÃO DE PNEU",
    OS_COLS,
    unique.map(osRow),
  );

  /* ------------------------------------------- indicadores do dashboard
     Reaproveita exatamente os cálculos da tela 02 (osDashboard), agora
     sobre todas as OS acumuladas — sem filtro de data. */
  const kpis = computeKpis(unique, lost);
  const series = monthlySeries(unique, 6);
  const donut = motiveSegments(unique, 5);
  const turmas = turmaBreakdown(unique);

  const wsKpi = wb.addWorksheet("INDICADORES");
  buildSheet(
    wsKpi,
    "INDICADORES DO DASHBOARD — JULY QUARTZO · CONTROLE DE PNEUS",
    KPI_COLS,
    [
      ["OS finalizadas", kpis.osFinalizadas],
      ["Pneus retirados", kpis.pneusRetirados],
      ["Pneus instalados", kpis.pneusInstalados],
      ["Pneus perdidos", kpis.pneusPerdidos],
      ["Total de OS exportadas", unique.length],
      ["Total de movimentações de pneu", kpis.pneusRetirados + kpis.pneusInstalados],
    ],
  );

  const wsMonth = wb.addWorksheet("MOVIMENTAÇÕES POR MÊS");
  buildSheet(
    wsMonth,
    "MOVIMENTAÇÕES POR MÊS — JULY QUARTZO · CONTROLE DE PNEUS",
    MONTH_COLS,
    series.map((p) => [p.key, p.label, p.retirados, p.instalados]),
  );

  const wsMotive = wb.addWorksheet("MOTIVOS");
  buildSheet(
    wsMotive,
    "MOTIVOS MAIS FREQUENTES — JULY QUARTZO · CONTROLE DE PNEUS",
    MOTIVE_COLS,
    donut.segments.map((s) => [s.label, s.value]),
  );

  const wsTurma = wb.addWorksheet("POR TURMA");
  buildSheet(
    wsTurma,
    "MOVIMENTAÇÕES POR TURMA/LETRA — JULY QUARTZO · CONTROLE DE PNEUS",
    TURMA_COLS,
    turmas.map((t) => [t.label, t.value]),
  );

  const buffer = await wb.xlsx.writeBuffer();
  downloadBlob(
    "CONTROLE_GERAL_DE_PNEUS_JULY_QUARTZO.xlsx",
    buffer,
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  );
}

/** Flat JSON record ready to be refreshed in Power BI. */
export function exportPowerBi(d: OsFormData) {
  const record = {
    origem: "JULY QUARTZO - MINERAÇÃO E CONSTRUÇÃO",
    documento: "OS - MOVIMENTAÇÃO DE PNEU",
    numero: d.numero,
    turno: d.turno,
    inicio: d.inicio,
    termino: d.termino,
    horimetro: d.horimetro,
    data: d.data,
    data_entrada: d.dataEntrada,
    data_saida: d.dataSaida,
    operador: d.operador,
    km: d.km,
    equip: d.equip,
    executantes: d.executantes,
    local: d.local,
    turma: d.turma,
    pneus_retirados: d.retirados.filter(
      (t) => t.posicao || t.marca || t.fogo || t.mm || t.motivo || t.vidas,
    ),
    pneus_instalados: d.instalados.filter((t) => t.marca || t.fogo || t.mm || t.vidas),
    motivos: d.motivos,
    observacoes: d.observacoes,
    supervisor: d.supervisorNome || "ALAN BAGANO P",
  };
  downloadBlob(
    `OS-${safeName(d.numero)}.json`,
    JSON.stringify(record, null, 2),
    "application/json",
  );
}