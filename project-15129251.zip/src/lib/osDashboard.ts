import type { SavedOs, OsTireRemoved, OsTireInstalled } from "@/lib/osTypes";
import type { LostTireRecord } from "@/lib/lostTiresTypes";
import { OS_TURMA_OPTIONS } from "@/mocks/osForm";
import { buildMotiveSummary } from "@/lib/osSummary";

/*
 * Indicadores do DASHBOARD (bloco 02).
 * Tudo é calculado em cima das OS reais salvas (tire_os) e dos pneus
 * perdidos (lost_tires). Não existe número fictício aqui: quando não há
 * registro, o valor é 0 e a interface escreve "Sem dados".
 */

export interface DashboardFilters {
  from: string;
  to: string;
  equip: string;
  operador: string;
  turma: string;
  turno: string;
}

export const EMPTY_FILTERS: DashboardFilters = {
  from: "",
  to: "",
  equip: "",
  operador: "",
  turma: "",
  turno: "",
};

const norm = (s: string) => (s || "").trim().toUpperCase();

/* ------------------------------------------------------ linhas de pneu */

const hasRemoved = (r: OsTireRemoved) =>
  Boolean((r.marca || "").trim() || (r.fogo || "").trim() || (r.mm || "").trim());
const hasInstalled = (t: OsTireInstalled) =>
  Boolean((t.marca || "").trim() || (t.fogo || "").trim() || (t.mm || "").trim());

export const countRemoved = (o: SavedOs) => o.retirados.filter(hasRemoved).length;
export const countInstalled = (o: SavedOs) => o.instalados.filter(hasInstalled).length;

/** Dia de referência da OS (data de entrada ou, na falta, o dia do salvamento). */
export function osDay(o: SavedOs): string {
  return (o.data || (o.savedAt ? o.savedAt.slice(0, 10) : "")) || "";
}

/* ------------------------------------------------------------- filtros */

export function filterOrders(orders: SavedOs[], f: DashboardFilters): SavedOs[] {
  return orders.filter((o) => {
    const day = osDay(o);
    if (f.from && (!day || day < f.from)) return false;
    if (f.to && (!day || day > f.to)) return false;
    if (f.equip && norm(o.equip) !== norm(f.equip)) return false;
    if (f.operador && norm(o.operador) !== norm(f.operador)) return false;
    if (f.turma && norm(o.turma) !== norm(f.turma)) return false;
    if (f.turno && norm(o.turno) !== norm(f.turno)) return false;
    return true;
  });
}

export function filterLost(lost: LostTireRecord[], f: DashboardFilters): LostTireRecord[] {
  return lost.filter((r) => {
    const day = r.dataOcorrencia || (r.createdAt ? r.createdAt.slice(0, 10) : "");
    if (f.from && (!day || day < f.from)) return false;
    if (f.to && (!day || day > f.to)) return false;
    if (f.equip && norm(r.equipamento) !== norm(f.equip)) return false;
    if (f.operador && norm(r.operador) !== norm(f.operador)) return false;
    if (f.turma && norm(r.turma) !== norm(f.turma)) return false;
    // Pneus perdidos não têm turno — o filtro de turno simplesmente não os afeta.
    return true;
  });
}

/* ----------------------------------------------- valores para os campos */

export function distinctValues(orders: SavedOs[], pick: (o: SavedOs) => string): string[] {
  const set = new Set<string>();
  orders.forEach((o) => {
    const v = (pick(o) || "").trim();
    if (v) set.add(v);
  });
  return Array.from(set).sort((a, b) => a.localeCompare(b, "pt-BR", { numeric: true }));
}

export function turmaOptions(_orders: SavedOs[]): string[] {
  // Lista fixa oficial de Turma/Letra (ADM, A–C): sempre completa no filtro,
  // independentemente de haver OS salva com cada letra.
  return [...OS_TURMA_OPTIONS];
}

/* ------------------------------------------------------------- KPIs */

export interface DashboardKpis {
  osFinalizadas: number;
  pneusRetirados: number;
  pneusInstalados: number;
  pneusPerdidos: number;
}

export function computeKpis(orders: SavedOs[], lost: LostTireRecord[]): DashboardKpis {
  return {
    osFinalizadas: orders.filter((o) => o.finalized).length,
    pneusRetirados: orders.reduce((s, o) => s + countRemoved(o), 0),
    pneusInstalados: orders.reduce((s, o) => s + countInstalled(o), 0),
    pneusPerdidos: lost.length,
  };
}

/** Janela anterior de mesmo tamanho, para o "vs. período anterior". */
export function previousRange(f: DashboardFilters): DashboardFilters | null {
  if (!f.from || !f.to) return null;
  const from = new Date(`${f.from}T00:00:00`);
  const to = new Date(`${f.to}T00:00:00`);
  if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime()) || to < from) return null;
  const days = Math.round((to.getTime() - from.getTime()) / 86400000) + 1;
  const prevTo = new Date(from.getTime() - 86400000);
  const prevFrom = new Date(prevTo.getTime() - (days - 1) * 86400000);
  const iso = (d: Date) => d.toISOString().slice(0, 10);
  return { ...f, from: iso(prevFrom), to: iso(prevTo) };
}

/** Número inteiro grande → legível (1250 → "1.250"). */
export function formatInt(n: number): string {
  return new Intl.NumberFormat("pt-BR").format(n);
}

/** % de variação arredondada, ou null quando não há base de comparação. */
export function deltaPct(current: number, previous: number): number | null {
  if (previous <= 0) return current > 0 ? 100 : null;
  return Math.round(((current - previous) / previous) * 100);
}

/* ------------------------------------------------ gráfico por mês */

export interface MonthPoint {
  key: string;
  label: string;
  retirados: number;
  instalados: number;
}

const MONTHS_PT = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

/** Série dos últimos N meses (âncora = mês mais recente com dados, senão o atual). */
export function monthlySeries(orders: SavedOs[], months = 6): MonthPoint[] {
  const agg = new Map<string, { r: number; i: number }>();
  orders.forEach((o) => {
    const day = osDay(o);
    if (!day) return;
    const key = day.slice(0, 7);
    const cur = agg.get(key) || { r: 0, i: 0 };
    cur.r += countRemoved(o);
    cur.i += countInstalled(o);
    agg.set(key, cur);
  });

  const keys = Array.from(agg.keys()).sort();
  const end = keys.length ? keys[keys.length - 1] : new Date().toISOString().slice(0, 7);
  const [ey, em] = end.split("-").map(Number);

  const out: MonthPoint[] = [];
  for (let k = months - 1; k >= 0; k -= 1) {
    const d = new Date(ey, em - 1 - k, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const v = agg.get(key) || { r: 0, i: 0 };
    out.push({ key, label: MONTHS_PT[d.getMonth()], retirados: v.r, instalados: v.i });
  }
  return out;
}

/* ------------------------------------------------ motivos e turmas */

export interface DonutSegment {
  label: string;
  value: number;
}

export function motiveSegments(orders: SavedOs[], max = 5): { segments: DonutSegment[]; total: number } {
  const summary = buildMotiveSummary(orders);
  const segments = summary.items.slice(0, max).map((i) => ({ label: i.short || i.label, value: i.count }));
  const rest = summary.items.slice(max).reduce((s, i) => s + i.count, 0);
  if (rest > 0) segments.push({ label: "Outros", value: rest });
  return { segments, total: summary.total };
}

export interface TurmaBar {
  label: string;
  value: number;
}

export function turmaBreakdown(orders: SavedOs[]): TurmaBar[] {
  const map = new Map<string, number>();
  OS_TURMA_OPTIONS.forEach((t) => map.set(t, 0));
  orders.forEach((o) => {
    const t = norm(o.turma);
    if (!t) return;
    const moves = countRemoved(o) + countInstalled(o);
    map.set(t, (map.get(t) || 0) + moves);
  });
  return OS_TURMA_OPTIONS.map((t) => ({ label: `Turma ${t}`, value: map.get(t) || 0 }));
}