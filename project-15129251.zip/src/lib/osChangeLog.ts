import type { SavedOs } from "@/lib/osTypes";
import { isBackendReady, supabase } from "@/lib/supabase";

/*
 * HISTÓRICO DE ALTERAÇÕES das OS (MOVIMENTAÇÃO DE PNEU).
 * Cada edição de campo — venha do sistema ou do Excel — vira uma linha aqui,
 * com valor anterior, valor novo, data/hora e a origem. Nunca bloqueia o
 * salvamento: se o registro do histórico falhar, a OS continua salva.
 */

const TABLE = "tire_os_changes";

export type ChangeOrigin = "sistema" | "excel";

export interface OsChangeInput {
  osNumero: string;
  pneuId?: string;
  campo: string;
  valorAnterior: string;
  valorNovo: string;
  origem: ChangeOrigin;
  responsavel?: string;
}

export interface OsChangeRow {
  id: number;
  os_numero: string;
  pneu_id: string | null;
  campo: string;
  valor_anterior: string | null;
  valor_novo: string | null;
  origem: string;
  responsavel: string | null;
  alterado_em: string;
}

/** Grava as alterações no histórico (silencioso em caso de falha). */
export async function logOsChanges(entries: OsChangeInput[]): Promise<void> {
  if (!isBackendReady || !entries.length) return;
  const rows = entries.map((e) => ({
    os_numero: e.osNumero,
    pneu_id: e.pneuId ?? null,
    campo: e.campo,
    valor_anterior: e.valorAnterior ?? "",
    valor_novo: e.valorNovo ?? "",
    origem: e.origem,
    responsavel: e.responsavel ?? null,
  }));
  try {
    await supabase.from(TABLE).insert(rows);
  } catch {
    /* o histórico nunca pode impedir o salvamento da OS */
  }
}

/** Lê as alterações mais recentes (opcionalmente de uma OS específica). */
export async function listOsChanges(limit = 400, osNumero?: string): Promise<OsChangeRow[]> {
  if (!isBackendReady) return [];
  let query = supabase
    .from(TABLE)
    .select("*")
    .order("alterado_em", { ascending: false })
    .limit(limit);
  if (osNumero) query = query.eq("os_numero", osNumero);
  const { data, error } = await query;
  if (error) throw new Error(error.message);
  return (data ?? []) as OsChangeRow[];
}

/** Compara a OS anterior com a nova e devolve as diferenças campo a campo. */
export function diffOs(prev: SavedOs | undefined, next: SavedOs): OsChangeInput[] {
  const out: OsChangeInput[] = [];
  const numero = (next.numero || next.id || "").trim();
  if (!numero) return out;

  const push = (campo: string, a: string, b: string, pneuId?: string) => {
    if ((a ?? "") === (b ?? "")) return;
    out.push({
      osNumero: numero,
      pneuId,
      campo,
      valorAnterior: a ?? "",
      valorNovo: b ?? "",
      origem: "sistema",
    });
  };

  if (!prev) {
    out.push({
      osNumero: numero,
      campo: "OS CRIADA",
      valorAnterior: "",
      valorNovo: numero,
      origem: "sistema",
    });
    return out;
  }

  push("EQUIPAMENTO", prev.equip, next.equip);
  push("OPERADOR", prev.operador, next.operador);
  push("HORÍMETRO", prev.horimetro, next.horimetro);
  push("DATA DE ENTRADA", prev.dataEntrada, next.dataEntrada);
  push("DATA DE SAÍDA", prev.dataSaida, next.dataSaida);
  push("TURMA/LETRA", prev.turma, next.turma);
  push("HORÁRIO/TURNO", prev.turno, next.turno);
  push("LOCAL DA OCORRÊNCIA", prev.local, next.local);
  push("OBSERVAÇÕES", prev.observacoes, next.observacoes);
  push("SUPERVISOR", prev.supervisorNome, next.supervisorNome);

  const len = Math.max(prev.retirados?.length ?? 0, next.retirados?.length ?? 0);
  for (let i = 0; i < len; i += 1) {
    const pid = `${numero}-P${i + 1}`;
    const pr = prev.retirados?.[i];
    const nr = next.retirados?.[i];
    push("POSIÇÃO", pr?.posicao ?? "", nr?.posicao ?? "", pid);
    push("MARCA (retirado)", pr?.marca ?? "", nr?.marca ?? "", pid);
    push("FOGO (retirado)", pr?.fogo ?? "", nr?.fogo ?? "", pid);
    push("MM SAÍDA", pr?.mm ?? "", nr?.mm ?? "", pid);
    push("MOTIVO RETIRADA", pr?.motivo ?? "", nr?.motivo ?? "", pid);
    push("VIDAS RETIRADO", pr?.vidas ?? "", nr?.vidas ?? "", pid);

    const pi = prev.instalados?.[i];
    const ni = next.instalados?.[i];
    push("MARCA INSTALADO", pi?.marca ?? "", ni?.marca ?? "", pid);
    push("FOGO INSTALADO", pi?.fogo ?? "", ni?.fogo ?? "", pid);
    push("MM ENTRADA", pi?.mm ?? "", ni?.mm ?? "", pid);
    push("VIDAS INSTALADO", pi?.vidas ?? "", ni?.vidas ?? "", pid);
  }

  return out;
}