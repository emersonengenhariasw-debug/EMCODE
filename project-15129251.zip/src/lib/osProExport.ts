import ExcelJS from "exceljs";
import type { SavedOs } from "@/lib/osTypes";
import type { LostTireRecord } from "@/lib/lostTiresTypes";
import { OS_MOTIVES, OS_TURMA_OPTIONS, OS_TURNO_OPTIONS } from "@/mocks/osForm";
import {
  monthlySeries,
  motiveSegments,
  distinctValues,
  computeKpis,
  deltaPct,
  countRemoved,
  countInstalled,
} from "@/lib/osDashboard";
import { buildMotiveSummary } from "@/lib/osSummary";
import { injectNativeCharts } from "@/lib/xlsxChartInjection";
import { buildColumnChart, buildDoughnutChart } from "@/lib/xlsxChartXml";

/* =====================================================================
   DASHBOARD PROFISSIONAL — "CONTROLE DE PNEUS"
   Gera uma planilha .xlsx com 7 abas (Dashboard, Controle de Pneus,
   Movimentações, Reformas, Estoque, Análise, Cadastros), cartões de
   indicador, gráficos NATIVOS do Excel (colunas + rosca + turno/turma),
   imagens no cabeçalho e a tabela principal com AutoFiltro.
   ===================================================================== */

const DARK = "FF14342B";
const DARK2 = "FF1F5A45";
const GOLD = "FFC79A2E";
const CARD_BG = "FFFFFFFF";
const STRIPE = "FFF2F6F3";
const LINE = "FFD8E0DB";
const WHITE = "FFFFFFFF";
const INK = "FF20302A";
const MUTED = "FF6B7A73";
const RED = "FFB3261E";
const GREEN_TXT = "FF1B7A46";

const SHEET_CONTROLE = "Controle de Pneus";
const SHEET_MOV = "Movimentações";
const SHEET_ANALISE = "Análise";
const SHEET_CADASTROS = "Cadastros";

const HEADERS = [
  "ID",
  "CB / EQUIP.",
  "POSIÇÃO",
  "FOGO",
  "MARCA",
  "STATUS",
  "DATA\nENTRADA",
  "DATA\nSAÍDA",
  "HORÍMETRO\nENTRADA",
  "HORÍMETRO\nSAÍDA",
  "HORÍMETRO\nRODADO",
  "MM\nENTRADA",
  "MM\nSAÍDA",
  "CÓD.\nMOTIVO",
  "MOTIVO RETIRADA",
  "OPERADOR",
  "BORRACHEIRO",
  "REFORMA",
];
const WIDTHS = [6, 12, 9, 10, 13, 13, 12, 12, 13, 13, 14, 10, 10, 10, 24, 18, 18, 10];

const AVARIA_CODES = new Set(["2", "3", "4", "5", "13", "14", "15"]);

/* ---------------------------------------------- imagens do cabeçalho */

const TIRE_ICON_URL =
  "https://readdy.ai/api/search-image?query=Flat%20vector%20style%20icon%20of%20a%20heavy%20mining%20truck%20tire%20wheel%2C%20centered%20on%20a%20solid%20very%20dark%20green%20background%2C%20minimal%20clean%20industrial%20design%20with%20golden%20rim%20accents%2C%20high%20contrast%2C%20simple%20professional%20look%2C%20uniform%20consistent%20style&width=200&height=200&seq=jq-tire-icon-01&orientation=squarish";

const TRUCK_PHOTO_URL =
  "https://readdy.ai/api/search-image?query=Professional%20product%20photograph%20of%20a%20large%20yellow%20mining%20dump%20truck%20side%20view%2C%20isolated%20on%20a%20solid%20very%20dark%20green%20background%2C%20dramatic%20even%20studio%20lighting%2C%20dark%20green%20and%20gold%20color%20palette%2C%20clean%20simple%20composition%2C%20high%20detail&width=880&height=240&seq=jq-mining-truck-01&orientation=landscape";

/** Busca uma imagem e devolve em base64 (ou null se a rede bloquear). */
async function fetchImageBase64(
  url: string,
): Promise<{ base64: string; extension: "png" | "jpeg" } | null> {
  try {
    const res = await fetch(url, { mode: "cors" });
    if (!res.ok) return null;
    const buf = await res.arrayBuffer();
    const bytes = new Uint8Array(buf);
    let bin = "";
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      bin += String.fromCharCode(...Array.from(bytes.subarray(i, i + chunk)));
    }
    const base64 = btoa(bin);
    const type = res.headers.get("content-type") || "";
    const extension: "png" | "jpeg" = /jpe?g/i.test(type) ? "jpeg" : "png";
    return { base64, extension };
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------- helpers */

const thin = (): Partial<ExcelJS.Borders> => ({
  top: { style: "thin", color: { argb: LINE } },
  left: { style: "thin", color: { argb: LINE } },
  bottom: { style: "thin", color: { argb: LINE } },
  right: { style: "thin", color: { argb: LINE } },
});

interface CellStyle {
  fill?: string;
  bold?: boolean;
  size?: number;
  color?: string;
  align?: ExcelJS.Alignment["horizontal"];
  vAlign?: ExcelJS.Alignment["vertical"];
  wrap?: boolean;
  border?: boolean;
  numFmt?: string;
}

function put(ws: ExcelJS.Worksheet, addr: string, value: ExcelJS.CellValue, s: CellStyle = {}) {
  const cell = ws.getCell(addr);
  cell.value = value;
  if (s.fill) cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: s.fill } };
  cell.font = { name: "Calibri", size: s.size ?? 10, bold: s.bold ?? false, color: { argb: s.color ?? INK } };
  cell.alignment = {
    horizontal: s.align ?? "left",
    vertical: s.vAlign ?? "middle",
    wrapText: s.wrap ?? false,
  };
  if (s.border) cell.border = thin();
  if (s.numFmt) cell.numFmt = s.numFmt;
  return cell;
}

function fillRange(ws: ExcelJS.Worksheet, from: string, to: string, s: CellStyle = {}) {
  const start = ws.getCell(from);
  const end = ws.getCell(to);
  for (let r = start.row; r <= end.row; r += 1) {
    for (let c = start.col; c <= end.col; c += 1) {
      const cell = ws.getCell(r, c);
      if (s.fill) cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: s.fill } };
      if (s.border) cell.border = thin();
      if (s.color) {
        cell.font = { name: "Calibri", size: s.size ?? 10, bold: s.bold ?? false, color: { argb: s.color } };
      }
    }
  }
}

const norm = (s: string) => (s || "").trim().toUpperCase();

function motiveCode(text: string): string {
  const m = /^\s*(\d+)/.exec(text || "");
  return m ? m[1] : "";
}

function motiveShort(text: string): string {
  if (!text) return "";
  const canon = OS_MOTIVES.flat().find((f) => norm(f) === norm(text));
  const base = canon ? canon.replace(/^\d+\s*-\s*/, "") : text;
  return base;
}

/** Abreviação de 2 letras no estilo da referência (FM, DS, ES, RF...). */
function motiveAbbrev(text: string): string {
  const t = norm(motiveShort(text));
  if (!t) return "";
  const map: [RegExp, string][] = [
    [/FURO/, "FM"],
    [/DESGASTE/, "DS"],
    [/ESTOURO/, "ES"],
    [/REFORM/, "RF"],
    [/RESERVA/, "RV"],
    [/DEFEITO/, "DF"],
    [/ROD[ÍI]ZIO/, "RZ"],
    [/SUCATA/, "SC"],
    [/ARRANC/, "AB"],
    [/RODA/, "RD"],
    [/C[ÂA]MARA/, "CM"],
    [/PROTETOR/, "PT"],
    [/TROCA/, "TH"],
    [/ACIDENTE/, "AC"],
  ];
  const hit = map.find(([re]) => re.test(t));
  if (hit) return hit[1];
  const words = t.split(/[\s(]+/).filter(Boolean);
  return (words[0]?.slice(0, 2) || "").toUpperCase();
}

function prettify(text: string): string {
  const s = motiveShort(text).trim();
  if (!s) return "";
  const lower = s.toLowerCase();
  return lower.charAt(0).toUpperCase() + lower.slice(1);
}

const filledRemoved = (r: { marca?: string; fogo?: string; mm?: string }) =>
  Boolean((r.marca || "").trim() || (r.fogo || "").trim() || (r.mm || "").trim());
const filledInstalled = (t: { marca?: string; fogo?: string; mm?: string }) =>
  Boolean((t.marca || "").trim() || (t.fogo || "").trim() || (t.mm || "").trim());

interface Movement {
  id: string;
  equip: string;
  posicao: string;
  fogo: string;
  marca: string;
  retirado: boolean;
  instalado: boolean;
  dataEntrada: string;
  dataSaida: string;
  horimetro: string;
  mmEntrada: string;
  mmSaida: string;
  codMotivo: string;
  motivo: string;
  operador: string;
  borracheiro: string;
  reforma: string;
  osNumero: string;
  /** Identificador de sincronização do pneu (ex.: "12-P3"). */
  pneuId: string;
  firstOfOs: boolean;
  avaria: boolean;
}

/* Uma linha por posição real do formulário: o índice preserva a posição
   exata do pneu em retirados[] / instalados[], o que permite reimportar o
   arquivo sem alterar o pneu errado. */
function buildMovements(orders: SavedOs[]): Movement[] {
  const out: Movement[] = [];
  let seq = 0;
  orders.forEach((o) => {
    const osNum = (o.numero || o.id || "").trim();
    const rows = Math.max(o.retirados.length, o.instalados.length);
    let seen = false;
    for (let i = 0; i < rows; i += 1) {
      const ret = o.retirados[i];
      const ins = o.instalados[i];
      const hasR = ret ? filledRemoved(ret) : false;
      const hasI = ins ? filledInstalled(ins) : false;
      if (!hasR && !hasI) continue;
      seq += 1;
      const motivoRaw = hasR ? ret?.motivo || "" : "";
      const code = motiveCode(motivoRaw);
      out.push({
        id: String(seq).padStart(4, "0"),
        equip: o.equip || "",
        posicao: hasR ? ret?.posicao || "" : "",
        fogo: (hasR ? ret?.fogo : ins?.fogo) || "",
        marca: (hasR ? ret?.marca : ins?.marca) || "",
        retirado: hasR,
        instalado: hasI,
        dataEntrada: o.dataEntrada || o.data || "",
        dataSaida: o.dataSaida || "",
        horimetro: o.horimetro || "",
        mmEntrada: hasI ? ins?.mm || "" : "",
        mmSaida: hasR ? ret?.mm || "" : "",
        codMotivo: motiveAbbrev(motivoRaw),
        motivo: prettify(motivoRaw),
        operador: o.operador || "",
        borracheiro: o.executantes || "",
        reforma: /REFORM/i.test(motiveShort(motivoRaw)) ? "Sim" : "Não",
        osNumero: osNum,
        pneuId: `${osNum}-P${i + 1}`,
        firstOfOs: !seen,
        avaria: AVARIA_CODES.has(code) || /ACIDENTE|ESTOURO|AVARIA/i.test(motivoRaw),
      });
      seen = true;
    }
  });
  return out;
}

function statusRich(m: Movement): ExcelJS.CellValue | string {
  if (m.retirado && m.instalado) {
    return {
      richText: [
        { font: { name: "Calibri", size: 10, bold: true, color: { argb: RED } }, text: "RETIRADO" },
        { font: { name: "Calibri", size: 10, bold: true, color: { argb: GREEN_TXT } }, text: "\nINSTALADO" },
      ],
    };
  }
  if (m.retirado) return "RETIRADO";
  if (m.instalado) return "INSTALADO";
  return "—";
}

function statusColor(m: Movement): string {
  if (m.retirado) return RED;
  if (m.instalado) return GREEN_TXT;
  return MUTED;
}

/* ------------------------------------------------- aba: tabela de pneus */

function writeTireTable(ws: ExcelJS.Worksheet, movements: Movement[], startRow: number) {
  ws.getCell(startRow, 1).value = "";
  HEADERS.forEach((h, i) => {
    const cell = put(ws, `${String.fromCharCode(65 + i)}${startRow}`, h, {
      fill: DARK,
      color: WHITE,
      bold: true,
      size: 9,
      align: "center",
      wrap: true,
      border: true,
    });
    cell.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
  });
  // Colunas-identificador ocultas (X, Y) — permitem reimportar o arquivo.
  put(ws, `X${startRow}`, "_OS_ID", { fill: DARK, color: WHITE, bold: true, size: 9, align: "center", border: true });
  put(ws, `Y${startRow}`, "_PNEU_ID", { fill: DARK, color: WHITE, bold: true, size: 9, align: "center", border: true });
  ws.getRow(startRow).height = 30;

  movements.forEach((m, idx) => {
    const r = startRow + 1 + idx;
    const stripe = idx % 2 === 1 ? STRIPE : WHITE;
    const vals: ExcelJS.CellValue[] = [
      m.id,
      m.equip,
      m.posicao,
      m.fogo,
      m.marca,
      statusRich(m),
      m.dataEntrada,
      m.dataSaida,
      m.horimetro,
      "",
      null,
      m.mmEntrada,
      m.mmSaida,
      m.codMotivo,
      m.motivo,
      m.operador,
      m.borracheiro,
      m.reforma,
    ];
    vals.forEach((v, i) => {
      const col = String.fromCharCode(65 + i);
      const centered = [1, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 18].includes(i + 1);
      const cell = put(ws, `${col}${r}`, v, {
        fill: stripe,
        size: 9,
        align: centered ? "center" : "left",
        wrap: false,
        border: true,
        color: i + 1 === 6 ? statusColor(m) : INK,
        bold: i + 1 === 6,
      });
      if (i + 1 === 6 && typeof v === "string" && v !== "—") cell.font = { ...cell.font, bold: true, color: { argb: statusColor(m) } };
      if (i + 1 === 15) cell.alignment = { horizontal: "left", vertical: "middle", wrapText: false };
    });
    // Horímetro rodado = saída - entrada (em branco quando falta leitura).
    put(ws, `K${r}`, null, { fill: stripe, size: 9, align: "center", border: true });
    ws.getCell(`K${r}`).value = { formula: `IF(OR(I${r}="",J${r}=""),"",J${r}-I${r})` };
    ws.getCell(`K${r}`).alignment = { horizontal: "center", vertical: "middle" };
    ws.getCell(`K${r}`).fill = { type: "pattern", pattern: "solid", fgColor: { argb: stripe } };
    ws.getCell(`K${r}`).border = thin();
    ws.getCell(`K${r}`).font = { name: "Calibri", size: 9, color: { argb: INK } };

    // Colunas-auxiliares (ocultas) usadas pelos cartões e pela análise.
    ws.getCell(`S${r}`).value = m.retirado ? 1 : 0;
    ws.getCell(`T${r}`).value = m.instalado ? 1 : 0;
    ws.getCell(`U${r}`).value = m.firstOfOs ? 1 : 0;
    ws.getCell(`V${r}`).value = m.avaria ? 1 : 0;
    ws.getCell(`W${r}`).value = m.osNumero;
    // Colunas-identificador (ocultas) para a sincronização de volta.
    ws.getCell(`X${r}`).value = m.osNumero;
    ws.getCell(`Y${r}`).value = m.pneuId;
  });

  ws.getColumn("S").hidden = true;
  ws.getColumn("T").hidden = true;
  ws.getColumn("U").hidden = true;
  ws.getColumn("V").hidden = true;
  ws.getColumn("W").hidden = true;
  ws.getColumn("X").hidden = true;
  ws.getColumn("Y").hidden = true;
  return startRow + 1 + movements.length;
}

/* ------------------------------------------------------------- cabeçalho */

function writeBrandHeader(ws: ExcelJS.Worksheet, currentDate: string, withTruck: boolean) {
  ws.mergeCells("A1:E2");
  const title = ws.getCell("A1");
  title.value = {
    richText: [
      { font: { name: "Calibri", size: 20, bold: true, color: { argb: WHITE } }, text: "CONTROLE DE " },
      { font: { name: "Calibri", size: 20, bold: true, color: { argb: GOLD } }, text: "PNEUS" },
      { font: { name: "Calibri", size: 9, color: { argb: "FFCFE0D8" } }, text: "\nMINERAÇÃO E CONSTRUÇÃO" },
    ],
  };
  title.alignment = { horizontal: "center", vertical: "middle", wrapText: true };

  ws.mergeCells("F1:J2");
  const brand = ws.getCell("F1");
  brand.value = {
    richText: [
      { font: { name: "Calibri", size: 16, bold: true, color: { argb: WHITE } }, text: "JULY QUARTZO" },
      { font: { name: "Calibri", size: 8, color: { argb: "FFCFE0D8" } }, text: "\nMINERAÇÃO E CONSTRUÇÃO" },
    ],
  };
  brand.alignment = { horizontal: "center", vertical: "middle", wrapText: true };

  ws.mergeCells("K1:O2");
  const truck = ws.getCell("K1");
  // Deixa a área livre para a imagem; texto só quando a imagem não carrega.
  truck.value = withTruck ? "" : "FROTA  ·  PNEUS  ·  SEGURANÇA";
  truck.alignment = { horizontal: "center", vertical: "middle" };
  truck.font = { name: "Calibri", size: 9, italic: true, color: { argb: "FF8FB3A6" } };

  ws.mergeCells("P1:R2");
  const date = ws.getCell("P1");
  date.value = {
    richText: [
      { font: { name: "Calibri", size: 8, bold: true, color: { argb: GOLD } }, text: "DATA ATUAL\n" },
      { font: { name: "Calibri", size: 14, bold: true, color: { argb: WHITE } }, text: `${currentDate}` },
    ],
  };
  date.alignment = { horizontal: "center", vertical: "middle", wrapText: true };

  fillRange(ws, "A1", "R2", { fill: DARK });
  ws.getCell("P1").border = {
    top: { style: "thin", color: { argb: GOLD } },
    left: { style: "thin", color: { argb: GOLD } },
    bottom: { style: "thin", color: { argb: GOLD } },
    right: { style: "thin", color: { argb: GOLD } },
  };
  ws.getRow(1).height = 26;
  ws.getRow(2).height = 26;
}

/* --------------------------------------------------------------- cartão */

function writeCard(
  ws: ExcelJS.Worksheet,
  cols: [string, string],
  row: number,
  label: string,
  value: ExcelJS.CellValue,
  deltaText: string,
  deltaUp: boolean,
  icon: string,
) {
  const [c1, c2] = cols;
  const r0 = row;
  const r1 = row + 3;
  ws.mergeCells(`${c1}${r0}:${c2}${r0}`);
  ws.mergeCells(`${c1}${r0 + 1}:${c2}${r0 + 1}`);
  ws.mergeCells(`${c1}${r0 + 2}:${c2}${r0 + 2}`);
  ws.mergeCells(`${c1}${r0 + 3}:${c2}${r0 + 3}`);

  const head = ws.getCell(`${c1}${r0}`);
  head.value = `${icon}  ${label}`;
  head.font = { name: "Calibri", size: 10, bold: true, color: { argb: WHITE } };
  head.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
  head.fill = { type: "pattern", pattern: "solid", fgColor: { argb: DARK } };

  const val = ws.getCell(`${c1}${r0 + 1}`);
  val.value = value;
  val.font = { name: "Calibri", size: 26, bold: true, color: { argb: INK } };
  val.alignment = { horizontal: "center", vertical: "middle" };

  const d = ws.getCell(`${c1}${r0 + 2}`);
  d.value = deltaText;
  d.font = { name: "Calibri", size: 11, bold: true, color: { argb: deltaUp ? GREEN_TXT : RED } };
  d.alignment = { horizontal: "center", vertical: "middle" };

  const note = ws.getCell(`${c1}${r0 + 3}`);
  note.value = "vs. mês anterior";
  note.font = { name: "Calibri", size: 9, color: { argb: MUTED } };
  note.alignment = { horizontal: "center", vertical: "middle" };

  fillRange(ws, `${c1}${r0 + 1}`, `${c2}${r1}`, { fill: CARD_BG, border: true });
  ws.getCell(`${c1}${r0}`).border = {
    top: { style: "medium", color: { argb: DARK } },
    left: { style: "medium", color: { argb: DARK } },
    right: { style: "medium", color: { argb: DARK } },
  };
  ws.getRow(r0).height = 22;
  ws.getRow(r0 + 1).height = 30;
  ws.getRow(r0 + 2).height = 18;
  ws.getRow(r0 + 3).height = 16;
}

/* ============================================================ EXPORT */

export async function exportProDashboard(orders: SavedOs[], lost: LostTireRecord[]): Promise<void> {
  const movements = buildMovements(orders);
  const kpis = computeKpis(orders, lost);
  const month = monthlySeries(orders, 6);

  // Movimentações por turno e por turma (para o gráfico de barras).
  const turnoAgg = new Map<string, number>();
  const turmaAgg = new Map<string, number>();
  orders.forEach((o) => {
    const moves = countRemoved(o) + countInstalled(o);
    const t = norm(o.turno);
    const g = norm(o.turma);
    if (t) turnoAgg.set(t, (turnoAgg.get(t) || 0) + moves);
    if (g) turmaAgg.set(g, (turmaAgg.get(g) || 0) + moves);
  });
  const barLabels = [
    ...OS_TURNO_OPTIONS.map((t) => `Turno ${t}`),
    ...OS_TURMA_OPTIONS.map((g) => `Turma ${g}`),
  ];
  const barValues = [
    ...OS_TURNO_OPTIONS.map((t) => turnoAgg.get(t) || 0),
    ...OS_TURMA_OPTIONS.map((g) => turmaAgg.get(g) || 0),
  ];

  const now = new Date();
  const currentDate = `${String(now.getDate()).padStart(2, "0")}/${String(now.getMonth() + 1).padStart(2, "0")}/${now.getFullYear()}`;

  const wb = new ExcelJS.Workbook();
  wb.creator = "July Quartzo — Controle de Pneus";
  wb.created = now;

  /* ----------------------------------------------------- 1) DASHBOARD */
  const dash = wb.addWorksheet("Dashboard", {
    properties: { defaultRowHeight: 16 },
    views: [{ showGridLines: false }],
  });
  WIDTHS.forEach((w, i) => {
    dash.getColumn(i + 1).width = w;
  });

  // As demais abas são criadas JÁ nesta ordem para as guias ficarem na sequência certa.
  const ctrl = wb.addWorksheet(SHEET_CONTROLE, { views: [{ state: "frozen", ySplit: 2, showGridLines: false }] });
  const mov = wb.addWorksheet(SHEET_MOV, { views: [{ showGridLines: false }] });
  const refor = wb.addWorksheet("Reformas", { views: [{ showGridLines: false }] });
  const est = wb.addWorksheet("Estoque", { views: [{ showGridLines: false }] });
  const an = wb.addWorksheet(SHEET_ANALISE, { views: [{ showGridLines: false }] });
  const cad = wb.addWorksheet(SHEET_CADASTROS, { views: [{ showGridLines: false }] });

  // Imagens do cabeçalho (buscadas em runtime; se a rede bloquear, seguimos sem elas).
  const [tireImg, truckImg] = await Promise.all([
    fetchImageBase64(TIRE_ICON_URL),
    fetchImageBase64(TRUCK_PHOTO_URL),
  ]);
  writeBrandHeader(dash, currentDate, Boolean(truckImg));
  if (tireImg) {
    const id = wb.addImage({ base64: tireImg.base64, extension: tireImg.extension });
    dash.addImage(id, { tl: { col: 0.16, row: 0.16 }, ext: { width: 28, height: 28 } });
  }
  if (truckImg) {
    const id = wb.addImage({ base64: truckImg.base64, extension: truckImg.extension });
    dash.addImage(id, { tl: { col: 11.25, row: 0.14 }, ext: { width: 176, height: 48 } });
  }

  const FR = 18; // linha dos rótulos dos filtros
  const FV = 19; // linha dos valores dos filtros
  const tableTop = 21; // linha do cabeçalho da tabela principal

  dash.getRow(3).height = 6;

  // Cartões (A..H) — valores ligados às células de filtro por fórmula.
  const dataRows = Math.max(movements.length, 1);
  const lastRow = 2 + dataRows + 400;
  const rng = (col: string) => `'${SHEET_CONTROLE}'!$${col}$3:$${col}$${lastRow}`;
  const cond = (col: string, cell: string) =>
    `(${rng(col)}=IF(${cell}="Todos",${rng(col)},${cell}))`;

  const fv = (col: string) => `$${col}$${FV}`;
  const baseConds =
    `${cond("B", fv("E"))}*${cond("E", fv("G"))}*${cond("O", fv("K"))}*` +
    `${cond("P", fv("M"))}*${cond("Q", fv("O"))}`;

  const fRet = `SUMPRODUCT(${baseConds}*${rng("S")})`;
  const fIns = `SUMPRODUCT(${baseConds}*${rng("T")})`;
  const fOs = `SUMPRODUCT(${baseConds}*${rng("U")})`;
  const fAva = `SUMPRODUCT(${baseConds}*${rng("V")})`;

  const retCount = movements.filter((m) => m.retirado).length;
  const insCount = movements.filter((m) => m.instalado).length;
  const avaCount = movements.filter((m) => m.avaria).length;
  const osCount = orders.filter(
    (o) => o.retirados.some(filledRemoved) || o.instalados.some(filledInstalled),
  ).length;

  const fmtDelta = (cur: number, prev: number): { text: string; up: boolean } => {
    const d = deltaPct(cur, prev);
    if (d === null) return { text: "—", up: true };
    return { text: `${d >= 0 ? "▲" : "▼"} ${Math.abs(d)}%`, up: d >= 0 };
  };
  const lastM = month[month.length - 1] || { retirados: 0, instalados: 0 };
  const prevM = month[month.length - 2] || { retirados: 0, instalados: 0 };
  const dRet = fmtDelta(lastM.retirados, prevM.retirados);
  const dIns = fmtDelta(lastM.instalados, prevM.instalados);

  const cardRow = 4;
  writeCard(dash, ["A", "B"], cardRow, "PNEUS RETIRADOS", { formula: fRet, result: retCount }, dRet.text, dRet.up, "◉");
  writeCard(dash, ["C", "D"], cardRow, "PNEUS INSTALADOS", { formula: fIns, result: insCount }, dIns.text, dIns.up, "◉");
  writeCard(dash, ["E", "F"], cardRow, "OS FINALIZADAS", { formula: fOs, result: osCount }, "", true, "☑");
  writeCard(dash, ["G", "H"], cardRow, "AVARIAS", { formula: fAva, result: avaCount }, "", false, "⚠");
  void kpis;

  // Barra de filtros (linhas FR / FV).
  dash.getRow(FR - 1).height = 6;
  const filterDefs: { labelCell: string; valueCell: string; label: string }[] = [
    { labelCell: `A${FR}`, valueCell: `A${FV}`, label: "PERÍODO" },
    { labelCell: `E${FR}`, valueCell: `E${FV}`, label: "EQUIPAMENTO" },
    { labelCell: `G${FR}`, valueCell: `G${FV}`, label: "MARCA" },
    { labelCell: `I${FR}`, valueCell: `I${FV}`, label: "STATUS" },
    { labelCell: `K${FR}`, valueCell: `K${FV}`, label: "MOTIVO" },
    { labelCell: `M${FR}`, valueCell: `M${FV}`, label: "OPERADOR" },
    { labelCell: `O${FR}`, valueCell: `O${FV}`, label: "BORRACHEIRO" },
  ];
  const labelSpans: Record<string, string> = {
    [`A${FR}`]: `A${FR}:D${FR}`,
    [`E${FR}`]: `E${FR}:F${FR}`,
    [`G${FR}`]: `G${FR}:H${FR}`,
    [`I${FR}`]: `I${FR}:J${FR}`,
    [`K${FR}`]: `K${FR}:L${FR}`,
    [`M${FR}`]: `M${FR}:N${FR}`,
    [`O${FR}`]: `O${FR}:P${FR}`,
  };
  const valueSpans: Record<string, string> = {
    [`A${FV}`]: `A${FV}:D${FV}`,
    [`E${FV}`]: `E${FV}:F${FV}`,
    [`G${FV}`]: `G${FV}:H${FV}`,
    [`I${FV}`]: `I${FV}:J${FV}`,
    [`K${FV}`]: `K${FV}:L${FV}`,
    [`M${FV}`]: `M${FV}:N${FV}`,
    [`O${FV}`]: `O${FV}:P${FV}`,
  };
  filterDefs.forEach((f) => {
    fillRange(dash, valueSpans[f.labelCell].split(":")[0], valueSpans[f.labelCell].split(":")[1], { fill: DARK2 });
    fillRange(dash, labelSpans[f.labelCell].split(":")[0], labelSpans[f.labelCell].split(":")[1], { fill: DARK });
    dash.mergeCells(labelSpans[f.labelCell]);
    dash.mergeCells(valueSpans[f.labelCell]);
    const lc = dash.getCell(f.labelCell);
    lc.value = f.label;
    lc.font = { name: "Calibri", size: 8, bold: true, color: { argb: GOLD } };
    lc.alignment = { horizontal: "center", vertical: "middle" };
    const vc = dash.getCell(f.valueCell);
    vc.font = { name: "Calibri", size: 10, bold: true, color: { argb: WHITE } };
    vc.alignment = { horizontal: "center", vertical: "middle" };
  });
  // Valores iniciais dos filtros.
  dash.getCell(`A${FV}`).value = "01/01/2020  até  31/12/2030";
  dash.getCell(`E${FV}`).value = "Todos";
  dash.getCell(`G${FV}`).value = "Todos";
  dash.getCell(`I${FV}`).value = "Todos";
  dash.getCell(`K${FV}`).value = "Todos";
  dash.getCell(`M${FV}`).value = "Todos";
  dash.getCell(`O${FV}`).value = "Todos";

  // Botão LIMPAR FILTROS.
  dash.mergeCells(`Q${FR}:R${FV}`);
  const clear = dash.getCell(`Q${FR}`);
  clear.value = "LIMPAR FILTROS";
  clear.font = { name: "Calibri", size: 10, bold: true, color: { argb: "FF2A2410" } };
  clear.alignment = { horizontal: "center", vertical: "middle" };
  fillRange(dash, `Q${FR}`, `R${FV}`, { fill: GOLD, border: true });
  dash.getCell(`Q${FR}`).value = "LIMPAR FILTROS";

  dash.getRow(FR).height = 12;
  dash.getRow(FV).height = 20;
  dash.getRow(FV + 1).height = 8;

  // Tabela principal (linha tableTop = cabeçalho).
  writeTireTable(dash, movements, tableTop);
  dash.autoFilter = {
    from: { row: tableTop, column: 1 },
    to: { row: tableTop + Math.max(movements.length, 1), column: 18 },
  };

  /* ------------------------------------------------ 2) CONTROLE DE PNEUS */
  WIDTHS.forEach((w, i) => ctrl.getColumn(i + 1).width = w);
  ctrl.mergeCells("A1:R1");
  const ctrlTitle = ctrl.getCell("A1");
  ctrlTitle.value = "CONTROLE DE PNEUS — MOVIMENTAÇÃO COMPLETA";
  ctrlTitle.font = { name: "Calibri", size: 14, bold: true, color: { argb: WHITE } };
  ctrlTitle.alignment = { horizontal: "center", vertical: "middle" };
  fillRange(ctrl, "A1", "R1", { fill: DARK });
  ctrl.getRow(1).height = 26;
  writeTireTable(ctrl, movements, 2);
  ctrl.autoFilter = {
    from: { row: 2, column: 1 },
    to: { row: 2 + Math.max(movements.length, 1), column: 18 },
  };

  /* -------------------------------------------------- 5) REFORMAS */
  const reformRows = movements.filter((m) => m.reforma === "Sim");
  const reforHeads = ["OS", "EQUIPAMENTO", "POSIÇÃO", "FOGO", "MARCA", "MM SAÍDA", "MOTIVO", "OPERADOR", "BORRACHEIRO", "STATUS"];
  reforHeads.forEach((h, i) => put(refor, `${String.fromCharCode(65 + i)}1`, h, { fill: DARK, color: WHITE, bold: true, size: 10, align: "center", border: true }));
  refor.getRow(1).height = 22;
  (reformRows.length ? reformRows : []).forEach((m, idx) => {
    const r = idx + 2;
    const stripe = idx % 2 ? STRIPE : WHITE;
    const vals = [m.osNumero, m.equip, m.posicao, m.fogo, m.marca, m.mmSaida, m.motivo, m.operador, m.borracheiro, "REFORMAR"];
    vals.forEach((v, i) => put(refor, `${String.fromCharCode(65 + i)}${r}`, v, { fill: stripe, size: 10, align: i === 1 || i === 2 ? "center" : "left", border: true }));
  });
  if (!reformRows.length) put(refor, "A2", "Nenhum pneu encaminhado para reforma até o momento.", { size: 10, color: MUTED });
  [10, 14, 10, 12, 14, 12, 26, 18, 18, 12].forEach((w, i) => refor.getColumn(i + 1).width = w);

  /* -------------------------------------------------- 6) ESTOQUE */
  const estHeads = ["FOGO", "MARCA", "MM ATUAL", "EQUIPAMENTO", "POSIÇÃO", "DATA ENTRADA", "VIDAS", "STATUS"];
  estHeads.forEach((h, i) => put(est, `${String.fromCharCode(65 + i)}1`, h, { fill: DARK, color: WHITE, bold: true, size: 10, align: "center", border: true }));
  est.getRow(1).height = 22;
  const stock: { fogo: string; marca: string; mm: string; equip: string; pos: string; data: string; vidas: string }[] = [];
  orders.forEach((o) => {
    o.instalados.filter(filledInstalled).forEach((t, i) => {
      stock.push({
        fogo: t.fogo || "",
        marca: t.marca || "",
        mm: t.mm || "",
        equip: o.equip || "",
        pos: String(i + 1),
        data: o.dataEntrada || o.data || "",
        vidas: t.vidas || "",
      });
    });
  });
  stock.forEach((s, idx) => {
    const r = idx + 2;
    const stripe = idx % 2 ? STRIPE : WHITE;
    const vals = [s.fogo, s.marca, s.mm, s.equip, s.pos, s.data, s.vidas, "INSTALADO"];
    vals.forEach((v, i) => put(est, `${String.fromCharCode(65 + i)}${r}`, v, { fill: stripe, size: 10, align: i === 4 ? "center" : "left", border: true }));
  });
  if (!stock.length) put(est, "A2", "Sem pneus instalados registrados.", { size: 10, color: MUTED });
  [12, 14, 12, 14, 10, 14, 10, 12].forEach((w, i) => est.getColumn(i + 1).width = w);

  /* -------------------------------------------------- 3) MOVIMENTAÇÕES */
  mov.mergeCells("A1:D1");
  const movTitle = mov.getCell("A1");
  movTitle.value = "MOVIMENTAÇÃO MENSAL DE PNEUS";
  movTitle.font = { name: "Calibri", size: 13, bold: true, color: { argb: WHITE } };
  movTitle.alignment = { horizontal: "center", vertical: "middle" };
  fillRange(mov, "A1", "D1", { fill: DARK });
  mov.getRow(1).height = 24;
  ["PERÍODO", "MÊS", "PNEUS RETIRADOS (SAÍDAS)", "PNEUS INSTALADOS (ENTRADAS)"].forEach((h, i) => {
    put(mov, `${String.fromCharCode(65 + i)}2`, h, { fill: DARK2, color: WHITE, bold: true, size: 10, align: "center", wrap: true, border: true });
  });
  mov.getRow(2).height = 28;
  month.forEach((p, i) => {
    const r = 3 + i;
    const stripe = i % 2 ? STRIPE : WHITE;
    put(mov, `A${r}`, p.key, { fill: stripe, size: 10, align: "center", border: true });
    put(mov, `B${r}`, p.label, { fill: stripe, size: 10, align: "center", border: true });
    put(mov, `C${r}`, p.retirados, { fill: stripe, size: 10, align: "center", border: true });
    put(mov, `D${r}`, p.instalados, { fill: stripe, size: 10, align: "center", border: true });
  });
  put(mov, `B${3 + month.length}`, "TOTAL", { size: 10, bold: true, align: "center" });
  put(mov, `C${3 + month.length}`, month.reduce((s, p) => s + p.retirados, 0), { size: 10, bold: true, align: "center" });
  put(mov, `D${3 + month.length}`, month.reduce((s, p) => s + p.instalados, 0), { size: 10, bold: true, align: "center" });
  [14, 10, 26, 26].forEach((w, i) => mov.getColumn(i + 1).width = w);

  /* -------------------------------------------------- 4) ANÁLISE */
  an.mergeCells("A1:F1");
  const anTitle = an.getCell("A1");
  anTitle.value = "ANÁLISE GERENCIAL — JULY QUARTZO";
  anTitle.font = { name: "Calibri", size: 13, bold: true, color: { argb: WHITE } };
  anTitle.alignment = { horizontal: "center", vertical: "middle" };
  fillRange(an, "A1", "F1", { fill: DARK });
  an.getRow(1).height = 24;

  const motiveAgg = buildMotiveSummary(orders);
  const motiveChart = motiveSegments(orders, 5);
  an.mergeCells("A3:B3");
  put(an, "A3", "PRINCIPAIS MOTIVOS DE RETIRADA", { fill: DARK2, color: WHITE, bold: true, size: 10, align: "center" });
  put(an, "A4", "MOTIVO", { fill: STRIPE, bold: true, size: 10, border: true });
  put(an, "B4", "QUANTIDADE", { fill: STRIPE, bold: true, size: 10, align: "center", border: true });
  const motiveRows = motiveChart.segments.slice(0, 6);
  while (motiveRows.length < 6) motiveRows.push({ label: "", value: 0 });
  motiveRows.forEach((seg, i) => {
    const r = 5 + i;
    put(an, `A${r}`, seg.label, { size: 10, border: true });
    put(an, `B${r}`, seg.value, { size: 10, align: "center", border: true });
  });

  let blockRow = 13;
  const block = (title: string, pairs: { label: string; value: number }[]) => {
    an.mergeCells(`A${blockRow}:B${blockRow}`);
    put(an, `A${blockRow}`, title, { fill: DARK2, color: WHITE, bold: true, size: 10, align: "center" });
    put(an, `A${blockRow + 1}`, "DESCRIÇÃO", { fill: STRIPE, bold: true, size: 10, border: true });
    put(an, `B${blockRow + 1}`, "TOTAL", { fill: STRIPE, bold: true, size: 10, align: "center", border: true });
    pairs.forEach((p, i) => {
      put(an, `A${blockRow + 2 + i}`, p.label, { size: 10, border: true });
      put(an, `B${blockRow + 2 + i}`, p.value, { size: 10, align: "center", border: true });
    });
    blockRow += 3 + pairs.length;
  };

  const byOperator = new Map<string, number>();
  const byEquip = new Map<string, number>();
  const byBrand = new Map<string, number>();
  movements.forEach((m) => {
    if (m.operador) byOperator.set(m.operador, (byOperator.get(m.operador) || 0) + 1);
    if (m.equip) byEquip.set(m.equip, (byEquip.get(m.equip) || 0) + 1);
    if (m.marca) byBrand.set(m.marca, (byBrand.get(m.marca) || 0) + 1);
  });
  const sortPairs = (mp: Map<string, number>) =>
    Array.from(mp.entries()).map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);

  block("MOVIMENTAÇÕES POR OPERADOR", sortPairs(byOperator));
  block("MOVIMENTAÇÕES POR EQUIPAMENTO", sortPairs(byEquip));
  block("MOVIMENTAÇÕES POR MARCA", sortPairs(byBrand));
  put(an, `A${blockRow + 1}`, "PNEUS PERDIDOS (AVARIAS REGISTRADAS)", { bold: true, size: 10 });
  put(an, `B${blockRow + 1}`, lost.length, { bold: true, size: 10, align: "center" });

  // Dados do gráfico de barras (Turno / Turma) — colunas H/I.
  an.getColumn("H").width = 16;
  an.getColumn("I").width = 14;
  put(an, "H3", "AGRUPAMENTO", { fill: DARK2, color: WHITE, bold: true, size: 10, align: "center", border: true });
  put(an, "I3", "MOVIMENTAÇÕES", { fill: DARK2, color: WHITE, bold: true, size: 10, align: "center", border: true });
  barLabels.forEach((l, i) => {
    put(an, `H${4 + i}`, l, { size: 10, border: true });
    put(an, `I${4 + i}`, barValues[i], { size: 10, align: "center", border: true });
  });

  // Resumo de motivos por quantidade (usa o agregado completo).
  void motiveAgg;
  [30, 16, 14, 14, 14, 14].forEach((w, i) => an.getColumn(i + 1).width = w);

  /* -------------------------------------------------- 7) CADASTROS */
  cad.mergeCells("A1:H1");
  const cadTitle = cad.getCell("A1");
  cadTitle.value = "CADASTROS — LISTAS DE APOIO";
  cadTitle.font = { name: "Calibri", size: 13, bold: true, color: { argb: WHITE } };
  cadTitle.alignment = { horizontal: "center", vertical: "middle" };
  fillRange(cad, "A1", "H1", { fill: DARK });
  cad.getRow(1).height = 24;

  const cadHeads = ["MOTIVOS / CAUSAS", "EQUIPAMENTOS", "MARCAS", "OPERADORES", "BORRACHEIROS", "TURNOS", "TURMAS", "STATUS"];
  cadHeads.forEach((h, i) => put(cad, `${String.fromCharCode(65 + i)}2`, h, { fill: DARK2, color: WHITE, bold: true, size: 10, align: "center", border: true }));

  const equips = distinctValues(orders, (o) => o.equip);
  const marcas = distinctValues(orders, (o) => o.retirados.filter(filledRemoved).map((r) => r.marca).filter(Boolean).join("|"))
    .flatMap((s) => s.split("|"))
    .filter((v, i, a) => v && a.indexOf(v) === i);
  const operadores = distinctValues(orders, (o) => o.operador);
  const borracheiros = distinctValues(orders, (o) => o.executantes);
  const motivosList = OS_MOTIVES.flat();

  const fillColumn = (col: string, values: string[]) => {
    values.forEach((v, i) => put(cad, `${col}${3 + i}`, v, { size: 10, border: true }));
  };
  fillColumn("A", motivosList);
  fillColumn("B", equips);
  fillColumn("C", marcas);
  fillColumn("D", operadores);
  fillColumn("E", borracheiros);
  fillColumn("F", OS_TURNO_OPTIONS);
  fillColumn("G", OS_TURMA_OPTIONS);
  fillColumn("H", ["RETIRADO", "INSTALADO", "SUBSTITUÍDO", "EM ESTOQUE", "REFORMADO", "DESCARTADO"]);

  // Listas (ocultas) para os menus suspensos da barra de filtros.
  const helperCols: { col: string; title: string; values: string[] }[] = [
    { col: "J", title: "Filtro Equipamentos", values: ["Todos", ...equips] },
    { col: "K", title: "Filtro Marcas", values: ["Todos", ...marcas] },
    { col: "L", title: "Filtro Motivos", values: ["Todos", ...Array.from(new Set(movements.map((m) => m.motivo).filter(Boolean))) ] },
    { col: "M", title: "Filtro Operadores", values: ["Todos", ...operadores] },
    { col: "N", title: "Filtro Borracheiros", values: ["Todos", ...borracheiros] },
    { col: "O", title: "Filtro Status", values: ["Todos", "RETIRADO", "INSTALADO"] },
  ];
  helperCols.forEach((h) => {
    put(cad, `${h.col}1`, h.title, { size: 9, bold: true, color: MUTED });
    h.values.forEach((v, i) => { cad.getCell(`${h.col}${2 + i}`).value = v; });
    cad.getColumn(h.col).hidden = true;
  });
  [26, 16, 14, 18, 18, 10, 10, 14].forEach((w, i) => cad.getColumn(i + 1).width = w);

  // Menus suspensos na barra de filtros do Dashboard.
  const listRange = (col: string, count: number) => `Cadastros!$${col}$2:$${col}$${Math.max(2, count + 1)}`;
  const dv = (cell: string, range: string) => {
    dash.getCell(cell).dataValidation = {
      type: "list",
      allowBlank: true,
      formulae: [range],
      showErrorMessage: false,
    };
  };
  dv(`E${FV}`, listRange("J", helperCols[0].values.length));
  dv(`G${FV}`, listRange("K", helperCols[1].values.length));
  dv(`K${FV}`, listRange("L", helperCols[2].values.length));
  dv(`M${FV}`, listRange("M", helperCols[3].values.length));
  dv(`O${FV}`, listRange("N", helperCols[4].values.length));
  dv(`I${FV}`, listRange("O", helperCols[5].values.length));

  /* -------------------------------------------- gráficos nativos */
  const chartXml: { sheetName: string; anchor: { fromCol: number; fromRow: number; toCol: number; toRow: number }; xml: string }[] = [];

  chartXml.push({
    sheetName: "Dashboard",
    anchor: { fromCol: 9, fromRow: 4, toCol: 13, toRow: 7 },
    xml: buildColumnChart({
      title: "MOVIMENTAÇÃO MENSAL DE PNEUS",
      titleColor: INK,
      catSheet: SHEET_MOV,
      catRange: `$B$3:$B$${2 + month.length}`,
      catLabels: month.map((p) => p.label),
      axisColor: MUTED,
      series: [
        { name: "Entradas", sheet: SHEET_MOV, valRange: `$D$3:$D$${2 + month.length}`, values: month.map((p) => p.instalados), color: DARK2 },
        { name: "Saídas", sheet: SHEET_MOV, valRange: `$C$3:$C$${2 + month.length}`, values: month.map((p) => p.retirados), color: GOLD },
      ],
    }),
  });

  chartXml.push({
    sheetName: "Dashboard",
    anchor: { fromCol: 14, fromRow: 4, toCol: 18, toRow: 7 },
    xml: buildDoughnutChart({
      title: "PRINCIPAIS MOTIVOS DE RETIRADA",
      titleColor: INK,
      sheet: SHEET_ANALISE,
      catRange: "$A$5:$A$10",
      catLabels: motiveRows.map((s) => s.label || "—"),
      valRange: "$B$5:$B$10",
      values: motiveRows.map((s) => s.value),
      colors: [DARK2, "FF2E7D55", GOLD, "FFE0B84C", "FF7FA894", "FFB7CCBF"],
    }),
  });

  // Gráfico de barras por Turno / Turma (abaixo dos cartões, largura total).
  chartXml.push({
    sheetName: "Dashboard",
    anchor: { fromCol: 1, fromRow: 8, toCol: 18, toRow: 16 },
    xml: buildColumnChart({
      title: "MOVIMENTAÇÃO POR TURNO E TURMA",
      titleColor: INK,
      catSheet: SHEET_ANALISE,
      catRange: `$H$4:$H$${3 + barLabels.length}`,
      catLabels: barLabels,
      axisColor: MUTED,
      dir: "bar",
      series: [
        { name: "Movimentações", sheet: SHEET_ANALISE, valRange: `$I$4:$I$${3 + barLabels.length}`, values: barValues, color: DARK2 },
      ],
    }),
  });

  const buffer = (await wb.xlsx.writeBuffer()) as ArrayBuffer;
  const withCharts = await injectNativeCharts(buffer, chartXml);

  const blob = new Blob([withCharts], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "CONTROLE_DE_PNEUS_JULY_QUARTZO.xlsx";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}