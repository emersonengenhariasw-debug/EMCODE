import type { SavedOs } from "@/lib/osTypes";
import { isBackendReady, supabase } from "@/lib/supabase";

/*
 * Persistência das OS no Readdy Backend (tabela tire_os).
 * - uma linha por OS, com número único (nada de registros duplicados);
 * - a ficha completa fica guardada em "data" (JSONB) para reconstruir o Excel;
 * - o histórico antigo que estava só no navegador é enviado uma vez, sem duplicar.
 */

const TIRE_TABLE = "tire_os";

const SELECT_COLS = "numero, data, finalized, finalized_at, saved_at";

interface OsRow {
  numero: string;
  data: SavedOs;
  finalized: boolean;
  finalized_at: string | null;
  saved_at: string;
}

/* Linha do banco → objeto da OS usado pelo app. */
function rowToRecord(row: OsRow): SavedOs {
  return {
    ...(row.data as SavedOs),
    id: row.numero,
    savedAt: row.saved_at,
    finalized: row.finalized,
  };
}

/* Garante um número de OS sempre preenchido (chave única da linha). */
function normalize(record: SavedOs): { numero: string; data: SavedOs } {
  const numero = (record.numero || "").trim() || record.id || `os-${Date.now()}`;
  return { numero, data: { ...record, numero, id: numero } };
}

/* ----------------------------------------------------------------- backend */

export async function saveOs(record: SavedOs): Promise<void> {
  if (!isBackendReady) throw new Error("Backend não configurado.");
  const { numero, data } = normalize(record);
  const savedAt = record.savedAt || new Date().toISOString();

  const { error } = await supabase.from(TIRE_TABLE).upsert(
    {
      numero,
      data: { ...data, savedAt },
      finalized: Boolean(record.finalized),
      finalized_at: record.finalizedAt ?? null,
      saved_at: savedAt,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "numero" },
  );
  if (error) throw new Error(error.message);
}

export async function listOs(): Promise<SavedOs[]> {
  if (!isBackendReady) return [];
  const { data, error } = await supabase
    .from(TIRE_TABLE)
    .select(SELECT_COLS)
    .order("saved_at", { ascending: false });
  if (error) throw new Error(error.message);
  return (data as OsRow[]).map(rowToRecord);
}

export async function getOs(id: string): Promise<SavedOs | undefined> {
  if (!isBackendReady) return undefined;
  const { data, error } = await supabase
    .from(TIRE_TABLE)
    .select(SELECT_COLS)
    .eq("numero", id)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data ? rowToRecord(data as OsRow) : undefined;
}

export async function deleteOs(id: string): Promise<void> {
  if (!isBackendReady) return;
  const { error } = await supabase.from(TIRE_TABLE).delete().eq("numero", id);
  if (error) throw new Error(error.message);
}

/* ------------------------------------------- migração do histórico local */

const LOCAL_DB = "julyquartzo_os";
const LOCAL_STORE = "ordens";

/** Lê o histórico antigo que ficou guardado no navegador (IndexedDB). */
function readLocalOs(): Promise<SavedOs[]> {
  return new Promise((resolve) => {
    if (typeof indexedDB === "undefined") {
      resolve([]);
      return;
    }
    const req = indexedDB.open(LOCAL_DB);
    req.onerror = () => resolve([]);
    req.onsuccess = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(LOCAL_STORE)) {
        db.close();
        resolve([]);
        return;
      }
      const tx = db.transaction(LOCAL_STORE, "readonly");
      const get = tx.objectStore(LOCAL_STORE).getAll();
      get.onsuccess = () => {
        resolve((get.result as SavedOs[]) ?? []);
        db.close();
      };
      get.onerror = () => {
        resolve([]);
        db.close();
      };
    };
  });
}

/**
 * Envia para o backend as OS que estavam salvas apenas neste tablet.
 * Só insere o que ainda não existe (pelo número) — nunca sobrescreve nem duplica.
 * Retorna quantas OS foram migradas.
 */
export async function migrateLocalHistory(): Promise<number> {
  if (!isBackendReady) return 0;
  const locals = await readLocalOs();
  if (!locals.length) return 0;

  const { data, error } = await supabase.from(TIRE_TABLE).select("numero");
  if (error) throw new Error(error.message);
  const existing = new Set((data ?? []).map((r) => (r as { numero: string }).numero));

  const now = new Date().toISOString();
  const rows = locals
    .map((l) => {
      const { numero, data: payload } = normalize(l);
      return {
        numero,
        data: payload,
        finalized: Boolean(l.finalized),
        finalized_at: l.finalizedAt ?? null,
        saved_at: l.savedAt || now,
        updated_at: now,
      };
    })
    .filter((r) => !existing.has(r.numero));

  if (!rows.length) return 0;

  const { error: insErr } = await supabase
    .from(TIRE_TABLE)
    .upsert(rows, { onConflict: "numero", ignoreDuplicates: true });
  if (insErr) throw new Error(insErr.message);
  return rows.length;
}