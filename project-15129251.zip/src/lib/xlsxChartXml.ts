/*
 * Construtores de XML (OOXML) para os gráficos nativos do Excel.
 * Formato <c:chartSpace> da especificação DrawingML de gráficos.
 */

const C = "http://schemas.openxmlformats.org/drawingml/2006/chart";
const A = "http://schemas.openxmlformats.org/drawingml/2006/main";
const R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

function esc(v: string): string {
  return String(v)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function ref(sheet: string, range: string): string {
  return `'${esc(sheet)}'!${range}`;
}

function titleXml(title: string, color: string): string {
  return (
    "<c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/>" +
    `<a:p><a:pPr><a:defRPr sz="1100" b="1"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill></a:defRPr></a:pPr>` +
    `<a:r><a:rPr lang="pt-BR" sz="1100" b="1"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill></a:rPr><a:t>${esc(title)}</a:t></a:r>` +
    "</a:p></c:rich></c:tx><c:overlay val=\"0\"/></c:title>"
  );
}

function strCache(labels: string[]): string {
  const pts = labels
    .map((l, i) => `<c:pt idx="${i}"><c:v>${esc(l)}</c:v></c:pt>`)
    .join("");
  return `<c:ptCount val="${labels.length}"/>${pts}`;
}

function numCache(values: number[]): string {
  const pts = values
    .map((v, i) => `<c:pt idx="${i}"><c:v>${Number.isFinite(v) ? v : 0}</c:v></c:pt>`)
    .join("");
  return `<c:ptCount val="${values.length}"/>${pts}`;
}

export interface ColumnSeries {
  name: string;
  sheet: string;
  valRange: string;
  values: number[];
  color: string;
}

export function buildColumnChart(opts: {
  title: string;
  titleColor: string;
  catSheet: string;
  catRange: string;
  catLabels: string[];
  series: ColumnSeries[];
  axisColor: string;
  /** "col" = colunas verticais; "bar" = barras horizontais. */
  dir?: "col" | "bar";
}): string {
  const ax1 = 111111111;
  const ax2 = 222222222;
  const horizontal = opts.dir === "bar";
  const catPos = horizontal ? "l" : "b";
  const valPos = horizontal ? "b" : "l";

  const seriesXml = opts.series
    .map((s, i) => {
      return (
        "<c:ser>" +
        `<c:idx val="${i}"/><c:order val="${i}"/>` +
        `<c:tx><c:v>${esc(s.name)}</c:v></c:tx>` +
        `<c:spPr><a:solidFill><a:srgbClr val="${s.color}"/></a:solidFill><a:ln><a:noFill/></a:ln></c:spPr>` +
        `<c:invertIfNegative val="0"/>` +
        `<c:cat><c:strRef><c:f>${ref(opts.catSheet, opts.catRange)}</c:f><c:strCache>${strCache(opts.catLabels)}</c:strCache></c:strRef></c:cat>` +
        `<c:val><c:numRef><c:f>${ref(s.sheet, s.valRange)}</c:f><c:numCache><c:formatCode>General</c:formatCode>${numCache(s.values)}</c:numCache></c:numRef></c:val>` +
        "</c:ser>"
      );
    })
    .join("");

  return (
    `<c:chartSpace xmlns:c="${C}" xmlns:a="${A}" xmlns:r="${R}">` +
    "<c:chart>" +
    titleXml(opts.title, opts.titleColor) +
    '<c:autoTitleDeleted val="0"/>' +
    "<c:plotArea><c:layout/>" +
    `<c:barChart><c:barDir val="${opts.dir ?? "col"}"/><c:grouping val="clustered"/><c:varyColors val="0"/>` +
    seriesXml +
    '<c:gapWidth val="60"/><c:overlap val="-10"/>' +
    `<c:axId val="${ax1}"/><c:axId val="${ax2}"/>` +
    "</c:barChart>" +
    '<c:catAx><c:axId val="' + ax1 + '"/><c:scaling><c:orientation val="minMax"/></c:scaling>' +
    `<c:delete val="0"/><c:axPos val="${catPos}"/>` +
    `<c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="900"><a:solidFill><a:srgbClr val="${opts.axisColor}"/></a:solidFill></a:defRPr></a:pPr><a:endParaRPr lang="pt-BR"/></a:p></c:txPr>` +
    `<c:crossAx val="${ax2}"/></c:catAx>` +
    '<c:valAx><c:axId val="' + ax2 + '"/><c:scaling><c:orientation val="minMax"/></c:scaling>' +
    `<c:delete val="0"/><c:axPos val="${valPos}"/>` +
    `<c:majorGridlines><c:spPr><a:ln w="9525"><a:solidFill><a:srgbClr val="FFE3E8E5"/></a:solidFill></a:ln></c:spPr></c:majorGridlines>` +
    `<c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="900"><a:solidFill><a:srgbClr val="${opts.axisColor}"/></a:solidFill></a:defRPr></a:pPr><a:endParaRPr lang="pt-BR"/></a:p></c:txPr>` +
    `<c:crossAx val="${ax1}"/></c:valAx>` +
    "</c:plotArea>" +
    '<c:legend><c:legendPos val="t"/><c:overlay val="0"/></c:legend>' +
    '<c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/>' +
    "</c:chart></c:chartSpace>"
  );
}

export function buildDoughnutChart(opts: {
  title: string;
  titleColor: string;
  sheet: string;
  catRange: string;
  catLabels: string[];
  valRange: string;
  values: number[];
  colors: string[];
}): string {
  const dPt = opts.colors
    .map(
      (c, i) =>
        `<c:dPt><c:idx val="${i}"/><c:bubble3D val="0"/><c:spPr><a:solidFill><a:srgbClr val="${c}"/></a:solidFill><a:ln><a:solidFill><a:srgbClr val="FFFFFFFF"/></a:solidFill></a:ln></c:spPr></c:dPt>`,
    )
    .join("");

  return (
    `<c:chartSpace xmlns:c="${C}" xmlns:a="${A}" xmlns:r="${R}">` +
    "<c:chart>" +
    titleXml(opts.title, opts.titleColor) +
    '<c:autoTitleDeleted val="0"/>' +
    "<c:plotArea><c:layout/>" +
    '<c:doughnutChart><c:varyColors val="1"/>' +
    "<c:ser><c:idx val=\"0\"/><c:order val=\"0\"/>" +
    dPt +
    '<c:dLbls><c:showLegendKey val="0"/><c:showVal val="0"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="1"/><c:showBubbleSize val="0"/><c:showLeaderLines val="1"/><c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="900" b="1"><a:solidFill><a:srgbClr val="FFFFFFFF"/></a:solidFill></a:defRPr></a:pPr><a:endParaRPr lang="pt-BR"/></a:p></c:txPr></c:dLbls>' +
    `<c:cat><c:strRef><c:f>${ref(opts.sheet, opts.catRange)}</c:f><c:strCache>${strCache(opts.catLabels)}</c:strCache></c:strRef></c:cat>` +
    `<c:val><c:numRef><c:f>${ref(opts.sheet, opts.valRange)}</c:f><c:numCache><c:formatCode>General</c:formatCode>${numCache(opts.values)}</c:numCache></c:numRef></c:val>` +
    "</c:ser>" +
    '<c:firstSliceAng val="0"/><c:holeSize val="58"/>' +
    "</c:doughnutChart>" +
    "</c:plotArea>" +
    '<c:legend><c:legendPos val="r"/><c:overlay val="0"/><c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="900"/></a:pPr><a:endParaRPr lang="pt-BR"/></a:p></c:txPr></c:legend>' +
    '<c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/>' +
    "</c:chart></c:chartSpace>"
  );
}