import type { LostPhoto, LostTireRecord } from "@/lib/lostTiresTypes";
import { isBackendReady, supabase } from "@/lib/supabase";

/*
 * Persistência do painel PNEUS PERDIDOS — totalmente separada das OS.
 * - tabela própria (lost_tires), numeração própria (PP-0001…);
 * - fotos guardadas no cofre de imagens "pneus-perdidos", organizadas por registro;
 * - nenhuma relação com tire_os.
 */

const TABLE = "lost_tires";
const BUCKET = "pneus-perdidos";

const SELECT_COLS =
  "registro, data_ocorrencia, operador, equipamento, posicao, marca, fogo, mm, horimetro, " +
  "local, turma, motivo, motivo_outros, descricao, fotos, responsavel, observacoes, status, " +
  "created_at, updated_at";

interface LostRow {
  registro: string;
  data_ocorrencia: string | null;
  operador: string | null;
  equipamento: string | null;
  posicao: string | null;
  marca: string | null;
  fogo: string | null;
  mm: string | null;
  horimetro: string | null;
  local: string | null;
  turma: string | null;
  motivo: string | null;
  motivo_outros: string | null;
  descricao: string | null;
  fotos: LostPhoto[] | null;
  responsavel: string | null;
  observacoes: string | null;
  status: string;
  created_at: string;
  updated_at: string;
}

function rowToRecord(row: LostRow): LostTireRecord {
  return {
    id: row.registro,
    registro: row.registro,
    dataOcorrencia: row.data_ocorrencia ?? "",
    operador: row.operador ?? "",
    equipamento: row.equipamento ?? "",
    posicao: row.posicao ?? "",
    marca: row.marca ?? "",
    fogo: row.fogo ?? "",
    mm: row.mm ?? "",
    horimetro: row.horimetro ?? "",
    local: row.local ?? "",
    turma: row.turma ?? "",
    motivo: row.motivo ?? "",
    motivoOutros: row.motivo_outros ?? "",
    descricao: row.descricao ?? "",
    fotos: Array.isArray(row.fotos) ? row.fotos : [],
    responsavel: row.responsavel ?? "",
    observacoes: row.observacoes ?? "",
    status: row.status === "finalizado" ? "finalizado" : "rascunho",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

/* ------------------------------------------------------------ registros */

export async function listLostTires(): Promise<LostTireRecord[]> {
  if (!isBackendReady) return [];
  const { data, error } = await supabase
    .from(TABLE)
    .select(SELECT_COLS)
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return (data as LostRow[]).map(rowToRecord);
}

export async function saveLostTire(record: LostTireRecord): Promise<void> {
  if (!isBackendReady) throw new Error("Backend não configurado.");
  const now = new Date().toISOString();
  const { error } = await supabase.from(TABLE).upsert(
    {
      registro: record.registro,
      data_ocorrencia: record.dataOcorrencia || null,
      operador: record.operador || null,
      equipamento: record.equipamento || null,
      posicao: record.posicao || null,
      marca: record.marca || null,
      fogo: record.fogo || null,
      mm: record.mm || null,
      horimetro: record.horimetro || null,
      local: record.local || null,
      turma: record.turma || null,
      motivo: record.motivo || null,
      motivo_outros: record.motivoOutros || null,
      descricao: record.descricao || null,
      fotos: record.fotos,
      responsavel: record.responsavel || null,
      observacoes: record.observacoes || null,
      status: record.status,
      created_at: record.createdAt || now,
      updated_at: now,
    },
    { onConflict: "registro" },
  );
  if (error) throw new Error(error.message);
}

export async function deleteLostTire(id: string): Promise<void> {
  if (!isBackendReady) return;
  const { error } = await supabase.from(TABLE).delete().eq("registro", id);
  if (error) throw new Error(error.message);
}

/* --------------------------------------------------------------- fotos */

/** Sobe uma foto para o cofre, dentro da pasta do nº do registro. */
export async function uploadLostPhoto(registro: string, file: File): Promise<LostPhoto> {
  if (!isBackendReady) throw new Error("Backend não configurado.");
  const ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
  const folder = (registro || "sem-registro").toLowerCase().replace(/[^a-z0-9._-]/g, "-");
  const path = `${folder}/foto-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
    upsert: false,
    contentType: file.type || "image/jpeg",
  });
  if (error) throw new Error(error.message);
  return { id: path, path, name: file.name, uploadedAt: new Date().toISOString() };
}

/** Gera um link temporário para exibir/baixar a foto guardada. */
export async function signLostPhoto(path: string): Promise<string> {
  if (!isBackendReady || !path) return "";
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(path, 3600);
  if (error) return "";
  return data?.signedUrl ?? "";
}