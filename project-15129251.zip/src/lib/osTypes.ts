export interface OsTireRemoved {
  posicao: string;
  marca: string;
  fogo: string;
  mm: string;
  motivo: string;
  vidas: string;
}

export interface OsTireInstalled {
  marca: string;
  fogo: string;
  mm: string;
  vidas: string;
}

/** Foto vinculada a uma OS (guardada no cofre privado de imagens). */
export interface OsPhoto {
  id: string;
  /** Caminho no cofre de fotos (preenchido depois do envio). */
  path?: string;
  name: string;
  /** Data e hora do envio da foto. */
  uploadedAt?: string;
  /** Posição do pneu, quando informada. */
  posicao?: string;
  /** Motivo da movimentação. */
  motivo?: string;
}

/** Foto ainda em preparação (antes/neste momento do envio). */
export interface OsPhotoDraft extends OsPhoto {
  previewUrl: string;
  file?: File;
}

export interface OsFormData {
  numero: string;
  turno: string;
  inicio: string;
  termino: string;
  horimetro: string;
  data: string;
  dataEntrada: string;
  dataSaida: string;
  operador: string;
  km: string;
  equip: string;
  executantes: string;
  local: string;
  turma: string;
  retirados: OsTireRemoved[];
  instalados: OsTireInstalled[];
  motivos: string[];
  observacoes: string;
  supervisorNome: string;
  fotos: OsPhoto[];
  finalizedAt?: string;
}

export interface SavedOs extends OsFormData {
  id: string;
  savedAt: string;
  finalized: boolean;
}