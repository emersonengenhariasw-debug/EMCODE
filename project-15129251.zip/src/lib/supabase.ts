import { createClient } from "@supabase/supabase-js";

/*
 * Cliente único do Readdy Backend (compatível com @supabase/supabase-js).
 * Uma instância só, reutilizada em todo o app.
 * As credenciais vêm do ambiente do projeto — nunca ficam no código.
 */
const env = import.meta.env as Record<string, string | undefined>;
const supabaseUrl = env.VITE_PUBLIC_SUPABASE_URL ?? "";
const supabaseAnonKey = env.VITE_PUBLIC_SUPABASE_ANON_KEY ?? "";

/** Indica se o backend está configurado e pronto para uso. */
export const isBackendReady = Boolean(supabaseUrl && supabaseAnonKey);

export const supabase = createClient(
  supabaseUrl || "https://placeholder.supabase.co",
  supabaseAnonKey || "public-anon-key",
  {
    auth: { persistSession: true, autoRefreshToken: true },
  },
);