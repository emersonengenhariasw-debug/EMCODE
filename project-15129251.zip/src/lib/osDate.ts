/*
 * Formatação de data e hora das Ordens de Serviço.
 * A data/hora do registro é gerada pelo próprio sistema no momento do salvamento
 * (savedAt) e exibida no formato "DD/MM/AAAA às HH:MM", no horário local do dispositivo.
 */

const pad = (n: number) => String(n).padStart(2, "0");

/** ISO → "12/10/2026 às 18:30" (horário local). */
export function formatOsDateTime(iso?: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} às ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** Somente a data → "12/10/2026". */
export function formatOsDate(iso?: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
}