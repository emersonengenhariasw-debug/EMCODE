import { isBackendReady, supabase } from "@/lib/supabase";
import type { TireStatus } from "@/lib/tireMap";

/*
 * SITUAÇÃO EDITÁVEL DE CADA PNEU (por caminhão + posição).
 * - A situação escolhida no mapa é gravada no Backend (tabela tire_statuses),
 *   vinculada ao CAMINHÃO e à POSIÇÃO correta do pneu.
 * - Ao trocar de caminhão, recarregar a página ou reabrir a OS, a situação
 *   volta exatamente como foi registrada.
 * - Nada aqui altera as OS nem o histórico: é uma camada separada que apenas
 *   informa a cor/situação de cada posição.
 */

const TABLE = "tire_statuses";
const MIN_POS = 1;
const MAX_POS = 10;

/** Situações que podem ser escolhidas manualmente (azul de "selecionado" é só realce). */
export type EditableTireStatus = Extract<TireStatus, "regular" | "manutencao" | "perda" | "semRegistro">;

export const EDITABLE_TIRE_STATUSES: EditableTireStatus[] = [
  "regular",
  "manutencao",
  "perda",
  "semRegistro",
];

export function isEditableTireStatus(value: string): value is EditableTireStatus {
  return (EDITABLE_TIRE_STATUSES as string[]).includes(value);
}

/** Situações já gravadas para um caminhão (posição → situação). */
export async function listTireStatuses(vehicle: string): Promise<Record<number, EditableTireStatus>> {
  const v = (vehicle || "").trim();
  if (!isBackendReady || !v) return {};

  const { data, error } = await supabase.from(TABLE).select("position, status").eq("vehicle", v);
  if (error) throw new Error(error.message);

  const out: Record<number, EditableTireStatus> = {};
  (data ?? []).forEach((row) => {
    const { position, status } = row as { position?: number; status?: string };
    const pos = Number(position);
    if (pos >= MIN_POS && pos <= MAX_POS && typeof status === "string" && isEditableTireStatus(status)) {
      out[pos] = status;
    }
  });
  return out;
}

/** Grava as situações escolhidas para um caminhão, vinculadas à posição. */
export async function saveTireStatuses(
  vehicle: string,
  statuses: Record<number, EditableTireStatus>,
): Promise<void> {
  const v = (vehicle || "").trim();
  if (!v) return;

  const rows = Object.entries(statuses)
    .map(([key, status]) => ({ position: Number(key), status }))
    .filter(
      (r) =>
        Number.isInteger(r.position) &&
        r.position >= MIN_POS &&
        r.position <= MAX_POS &&
        isEditableTireStatus(r.status),
    )
    .map((r) => ({
      vehicle: v,
      position: r.position,
      status: r.status,
      updated_at: new Date().toISOString(),
    }));

  if (!rows.length) return;
  if (!isBackendReady) throw new Error("Backend não configurado.");

  const { error } = await supabase.from(TABLE).upsert(rows, { onConflict: "vehicle,position" });
  if (error) throw new Error(error.message);
}