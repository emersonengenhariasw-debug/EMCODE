import * as ExcelJS from "exceljs";
import type { LostTireRecord } from "@/lib/lostTiresTypes";

/* =====================================================================
   JULY QUARTZO — PNEUS PERDIDOS
   Planilha exclusiva: CONTROLE_DE_PNEUS_PERDIDOS_JULY_QUARTZO.xlsx
   Uma linha por pneu perdido finalizado. Não mistura com o CONTROLE
   GERAL DE PNEUS das OS.
   ===================================================================== */

const GREEN_TITLE = "FF1B4332";
const GREEN_HEAD = "FF2D6A4F";
const STRIPE = "FFF1F5F2";
const INK = "FF24352B";
const LINE = "FFCFD8D3";

interface ColSpec {
  header: string;
  width: number;
  num?: boolean;
  wrap?: boolean;
}

const COLS: ColSpec[] = [
  { header: "Nº REGISTRO", width: 13 },
  { header: "DATA DA OCORRÊNCIA", width: 15 },
  { header: "OPERADOR", width: 26 },
  { header: "EQUIPAMENTO / PREFIXO", width: 20 },
  { header: "POSIÇÃO", width: 10 },
  { header: "MARCA", width: 16 },
  { header: "FOGO / IDENTIFICAÇÃO", width: 20 },
  { header: "MM", width: 9 },
  { header: "HORÍMETRO / KM", width: 15 },
  { header: "LOCAL DA OCORRÊNCIA", width: 26 },
  { header: "TURMA / LETRA", width: 12 },
  { header: "MOTIVO DA PERDA", width: 30, wrap: true },
  { header: "DESCRIÇÃO DA OCORRÊNCIA", width: 46, wrap: true },
  { header: "QTD. FOTOS", width: 11, num: true },
  { header: "REFERÊNCIA DAS FOTOS", width: 42, wrap: true },
  { header: "RESPONSÁVEL", width: 24 },
  { header: "OBSERVAÇÕES ADICIONAIS", width: 42, wrap: true },
  { header: "SITUAÇÃO", width: 15 },
  { header: "DATA/HORA DO REGISTRO", width: 20 },
];

const BORDERS = {
  top: { style: "thin" as const, color: { argb: LINE } },
  left: { style: "thin" as const, color: { argb: LINE } },
  bottom: { style: "thin" as const, color: { argb: LINE } },
  right: { style: "thin" as const, color: { argb: LINE } },
};

/** ISO yyyy-mm-dd (ou datetime) → DD/MM/AAAA. */
function fmtDate(iso: string): string {
  if (!iso) return "";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : iso;
}

/** ISO datetime → DD/MM/AAAA HH:MM. */
function fmtStamp(iso: string): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return `${d.toLocaleDateString("pt-BR")} ${d.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  })}`;
}

function rowValues(r: LostTireRecord): (string | number)[] {
  const refs = r.fotos.map((f) => f.name).join(" | ");
  return [
    r.registro,
    fmtDate(r.dataOcorrencia),
    r.operador,
    r.equipamento,
    r.posicao,
    r.marca,
    r.fogo,
    r.mm,
    r.horimetro,
    r.local,
    r.turma,
    r.motivo,
    r.descricao,
    r.fotos.length,
    refs,
    r.responsavel,
    r.observacoes,
    r.status === "finalizado" ? "FINALIZADO" : "RASCUNHO",
    fmtStamp(r.createdAt),
  ];
}

function downloadBlob(filename: string, data: ArrayBuffer, mime: string) {
  const blob = new Blob([data], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Gera a planilha exclusiva dos PNEUS PERDIDOS.
 * Somente os registros finalizados entram na planilha.
 */
export async function exportLostTiresExcel(records: LostTireRecord[]): Promise<number> {
  const finalized = records.filter((r) => r.status === "finalizado");

  const wb = new ExcelJS.Workbook();
  wb.creator = "JULY QUARTZO";
  wb.created = new Date();
  const ws = wb.addWorksheet("PNEUS PERDIDOS");

  COLS.forEach((c, i) => {
    ws.getColumn(i + 1).width = c.width;
  });

  // Título
  ws.mergeCells(1, 1, 1, COLS.length);
  const titleCell = ws.getCell(1, 1);
  titleCell.value = "CONTROLE DE PNEUS PERDIDOS — JULY QUARTZO · MINERAÇÃO E CONSTRUÇÃO";
  titleCell.font = { bold: true, size: 12.5, color: { argb: "FFFFFFFF" } };
  titleCell.alignment = { vertical: "middle", horizontal: "left" };
  titleCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: GREEN_TITLE } };
  ws.getRow(1).height = 26;

  // Cabeçalhos
  const head = ws.getRow(2);
  COLS.forEach((c, i) => {
    const cell = head.getCell(i + 1);
    cell.value = c.header;
    cell.font = { bold: true, size: 9.5, color: { argb: "FFFFFFFF" } };
    cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: GREEN_HEAD } };
    cell.alignment = { vertical: "middle", horizontal: "center", wrapText: true };
    cell.border = BORDERS;
  });
  head.height = 30;

  // Dados
  finalized.forEach((r, ri) => {
    const row = ws.getRow(ri + 3);
    rowValues(r).forEach((v, ci) => {
      const cell = row.getCell(ci + 1);
      const col = COLS[ci];
      if (v === "" || v === null || v === undefined) {
        cell.value = null;
      } else if (col.num) {
        const n = Number(v);
        cell.value = Number.isFinite(n) ? n : String(v);
      } else {
        cell.value = String(v);
      }
      cell.font = { size: 10, color: { argb: INK } };
      cell.border = BORDERS;
      cell.alignment = {
        vertical: "middle",
        horizontal: col.num ? "right" : "left",
        wrapText: Boolean(col.wrap),
      };
      cell.numFmt = col.num ? "#,##0.###" : "@";
      if (ri % 2 === 1) cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: STRIPE } };
    });
  });

  const lastRow = Math.max(2, finalized.length + 2);
  ws.autoFilter = { from: { row: 2, column: 1 }, to: { row: lastRow, column: COLS.length } };
  ws.views = [{ state: "frozen", ySplit: 2 }];

  const buffer = await wb.xlsx.writeBuffer();
  downloadBlob(
    "CONTROLE_DE_PNEUS_PERDIDOS_JULY_QUARTZO.xlsx",
    buffer,
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  );
  return finalized.length;
}