import { getSiteOrigin } from "@/lib/seo/site";

export interface RouteSeo {
  title: string;
  description: string;
  keywords: string;
  canonical: string;
  robots: string;
  ogType: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  twitterCard: string;
}

/**
 * Authoritative route metadata for the SPA.
 * Only "/" is public + indexable + sitemap-eligible.
 * Every other path resolves to the catch-all NotFound route (non-indexable).
 */
export const HOME_SEO = {
  title: "Movimentação de Pneu | July Quartzo Mineração e Construção",
  description:
    "Ordem de Serviço digital de movimentação de pneus da July Quartzo. Formulário para tablet: pneu retirado e instalado, dez posições, motivos e observações.",
  keywords:
    "OS movimentação de pneu, ordem de serviço digital, July Quartzo, mineração e construção, formulário de pneus, manutenção de frota",
  ogType: "website",
  ogTitle: "OS Movimentação de Pneu | July Quartzo",
  ogDescription:
    "A OS física de movimentação de pneu transformada em formulário digital para tablet. Preencha, finalize e salve cada ordem.",
  ogImage:
    "https://static.readdy.ai/image/609965e270ebc56f2a8bcb8a9ed920d6/836242f12a11986ae8fbf2c721600450.jpeg",
  twitterCard: "summary_large_image",
};

/**
 * Página pública de instalação do aplicativo (compartilhada no WhatsApp).
 * É indexável e possui metadados próprios para um bom preview do link.
 */
export const INSTALL_SEO = {
  title: "Instalar o aplicativo | JULY QUARTZO — Borracharia Digital",
  description:
    "Instale o aplicativo da JULY QUARTZO — Mineração e Construção · Borracharia Digital no celular ou tablet em poucos toques e abra as ordens de serviço direto da tela inicial.",
  keywords:
    "instalar aplicativo, JULY QUARTZO, borracharia digital, OS movimentação de pneu, aplicativo de pneus",
  ogType: "website",
  ogTitle: "Instale o aplicativo JULY QUARTZO — Borracharia Digital",
  ogDescription:
    "Toque em INSTALAR APLICATIVO e abra as ordens de serviço direto da tela inicial do seu celular ou tablet.",
  ogImage:
    "https://static.readdy.ai/image/609965e270ebc56f2a8bcb8a9ed920d6/836242f12a11986ae8fbf2c721600450.jpeg",
  twitterCard: "summary_large_image",
};

export function resolveRouteSeo(pathname: string, origin = getSiteOrigin()): RouteSeo {
  const base = origin.replace(/\/+$/, "");

  if (pathname === "/") {
    return {
      ...HOME_SEO,
      canonical: `${base}/`,
      robots: "index, follow",
    };
  }

  if (pathname === "/instalar" || pathname === "/instalar/") {
    return {
      ...INSTALL_SEO,
      canonical: `${base}/instalar`,
      robots: "index, follow",
    };
  }

  // Catch-all / unknown route → not indexable.
  return {
    title: "Página não encontrada | July Quartzo",
    description:
      "A página solicitada não foi encontrada na Borracharia Digital da July Quartzo Mineração e Construção.",
    keywords: "",
    canonical: `${base}${pathname}`,
    robots: "noindex, nofollow",
    ogType: "website",
    ogTitle: "Página não encontrada | July Quartzo",
    ogDescription: "A página solicitada não foi encontrada.",
    ogImage: "",
    twitterCard: "summary",
  };
}