/**
 * Resolves the real site origin used by runtime SEO (JSON-LD, canonical, OG).
 * Priority: VITE_SITE_URL (environment) > current browser origin.
 * Never invents a domain.
 */
export function getSiteOrigin(): string {
  const envUrl = import.meta.env.VITE_SITE_URL as string | undefined;
  const trimmed = typeof envUrl === "string" ? envUrl.trim() : "";
  if (trimmed) {
    return trimmed.replace(/\/+$/, "");
  }
  if (typeof window !== "undefined" && window.location && window.location.origin) {
    return window.location.origin.replace(/\/+$/, "");
  }
  return "";
}