import { getSiteOrigin } from "@/lib/seo/site";
import { HOME_SEO } from "@/lib/seo/routeSeo";

const ORG_NAME = "July Quartzo Mineração e Construção";
const APP_NAME = "JULY QUARTZO — Borracharia Digital";
const LOGO_URL = "https://public.readdy.ai/ai/img_res/a156b410-a185-484d-93b1-98da19bdb609.png";

/**
 * Schema.org JSON-LD for the home page.
 * Kept in its own module (separate from runtime OG/Twitter tag mutation).
 * Only includes facts that match the visible content of the site.
 */
export function buildHomeSchemas(origin = getSiteOrigin()): Record<string, unknown>[] {
  const base = origin.replace(/\/+$/, "");
  const homeUrl = `${base}/`;

  return [
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      name: APP_NAME,
      alternateName: HOME_SEO.ogTitle,
      url: homeUrl,
      inLanguage: "pt-BR",
      description: HOME_SEO.description,
      publisher: {
        "@type": "Organization",
        name: ORG_NAME,
      },
    },
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      name: ORG_NAME,
      url: homeUrl,
      logo: LOGO_URL,
      description:
        "Mineração e Construção. Ordem de Serviço digital de movimentação de pneu com posições, motivos e observações em um formulário para tablet.",
    },
  ];
}