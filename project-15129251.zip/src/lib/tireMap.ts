import type { SavedOs } from "@/lib/osTypes";
import type { LostTireRecord } from "@/lib/lostTiresTypes";

/*
 * MAPA DO CAMINHÃO E HISTÓRICO DE PNEUS.
 * - As 10 posições seguem exatamente o desenho oficial: 1 e 2 na dianteira,
 *   3,4,5,6 no 1º conjunto traseiro e 7,8,9,10 no 2º conjunto traseiro.
 * - Cada linha das tabelas da OS corresponde à sua posição (linha 1 = pneu 1 …).
 * - A situação e o histórico vêm SEMPRE dos registros reais (OS salvas + pneus
 *   perdidos). Nada é inventado: quando não há registro, a posição fica "não
 *   cadastrada" e o histórico mostra "Nenhum histórico registrado".
 */

export type TireGroup = "dianteira" | "traseiro1" | "traseiro2";

export interface TirePositionDef {
  id: number;
  group: TireGroup;
  side: "esquerdo" | "direito";
  /** Coordenada horizontal (x) e vertical (y) em % dentro do desenho. */
  x: number;
  y: number;
  /** Ajuste fino opcional em pixels, somado à coordenada em %. */
  dx?: number;
  dy?: number;
}

export const TIRE_GROUP_LABEL: Record<TireGroup, string> = {
  dianteira: "Dianteira",
  traseiro1: "1º conjunto traseiro",
  traseiro2: "2º conjunto traseiro",
};

/* Áreas clicáveis sobre o desenho oficial — a numeração NÃO muda.
 * Coordenadas centralizadas sobre o pneu desenhado (x = eixo horizontal,
 * y = eixo vertical, em % da imagem).
 * O eixo traseiro (3-10) fica mais próximo do centro do caminhão, então as
 * bolinhas são mantidas mais para dentro para caírem sobre o pneu desenhado. */
export const TIRE_POSITIONS: TirePositionDef[] = [
  { id: 1, group: "dianteira", side: "esquerdo", x: 33, y: 24 },
  { id: 2, group: "dianteira", side: "direito", x: 67, y: 24 },
  { id: 3, group: "traseiro1", side: "esquerdo", x: 16.1, y: 60.2 },
  { id: 4, group: "traseiro1", side: "esquerdo", x: 31.5, y: 60.2 },
  { id: 5, group: "traseiro1", side: "direito", x: 67.6, y: 60.2 },
  { id: 6, group: "traseiro1", side: "direito", x: 84.6, y: 60.9 },
  { id: 7, group: "traseiro2", side: "esquerdo", x: 17.3, y: 79.6 },
  { id: 8, group: "traseiro2", side: "esquerdo", x: 31.8, y: 79.6 },
  { id: 9, group: "traseiro2", side: "direito", x: 68.2, y: 78.9 },
  { id: 10, group: "traseiro2", side: "direito", x: 84.8, y: 78.9, dx: -3.15, dy: 6.3 },
];

export type TireStatus = "selecionado" | "regular" | "manutencao" | "perda" | "semRegistro";

export const TIRE_STATUS_META: { id: TireStatus; label: string; hint: string }[] = [
  { id: "selecionado", label: "Posição selecionada", hint: "Pneu em foco nesta OS" },
  { id: "regular", label: "Regular", hint: "Situação confirmada pelos dados" },
  { id: "manutencao", label: "Em manutenção", hint: "Serviço em andamento" },
  { id: "perda", label: "Perda confirmada", hint: "Pneu perdido registrado" },
  { id: "semRegistro", label: "Não cadastrado", hint: "Sem registro para a posição" },
];

/** Situações que podem ser ESCOLHIDAS manualmente para o pneu (o realce azul de
 *  "Posição selecionada" é apenas foco no mapa e não entra na escolha). */
export const EDITABLE_TIRE_STATUS_META = TIRE_STATUS_META.filter((m) => m.id !== "selecionado");

export interface TireEvent {
  key: string;
  kind: "retirada" | "instalacao" | "perda";
  date: string;
  osNumero: string;
  marca: string;
  fogo: string;
  mm: string;
  vidas: string;
  motivo: string;
  obs: string;
}

const normVeh = (s: string) => (s || "").trim().toUpperCase();
const hasText = (s?: string) => Boolean((s || "").trim());
const posNum = (s: string) => {
  const m = /(\d+)/.exec(s || "");
  return m ? Number(m[1]) : NaN;
};

/** Data principal do registro da OS: entrada → saída → momento do salvamento. */
const osDate = (o: SavedOs): string => o.dataEntrada || o.dataSaida || o.savedAt || "";

/** Lista os caminhões/veículos já usados nas OS e nos Pneus Perdidos. */
export function listVehicles(orders: SavedOs[], lost: LostTireRecord[]): string[] {
  const set = new Set<string>();
  orders.forEach((o) => {
    if (hasText(o.equip)) set.add(o.equip.trim());
  });
  lost.forEach((l) => {
    if (hasText(l.equipamento)) set.add(l.equipamento.trim());
  });
  return Array.from(set).sort((a, b) => a.localeCompare(b, "pt-BR", { numeric: true }));
}

/** Histórico real de um pneu (veículo + posição), do mais recente ao mais antigo. */
export function buildTireHistory(
  orders: SavedOs[],
  lost: LostTireRecord[],
  vehicle: string,
  position: number,
): TireEvent[] {
  const v = normVeh(vehicle);
  if (!v || !position) return [];
  const events: TireEvent[] = [];

  orders.forEach((o) => {
    if (normVeh(o.equip) !== v) return;
    const removed = o.retirados?.[position - 1];
    if (
      removed &&
      (hasText(removed.marca) ||
        hasText(removed.fogo) ||
        hasText(removed.mm) ||
        hasText(removed.motivo) ||
        hasText(removed.vidas))
    ) {
      events.push({
        key: `os-${o.numero}-r-${position}`,
        kind: "retirada",
        date: osDate(o),
        osNumero: o.numero,
        marca: removed.marca,
        fogo: removed.fogo,
        mm: removed.mm,
        vidas: removed.vidas,
        motivo: removed.motivo,
        obs: "",
      });
    }
    const installed = o.instalados?.[position - 1];
    if (
      installed &&
      (hasText(installed.marca) || hasText(installed.fogo) || hasText(installed.mm) || hasText(installed.vidas))
    ) {
      events.push({
        key: `os-${o.numero}-i-${position}`,
        kind: "instalacao",
        date: osDate(o),
        osNumero: o.numero,
        marca: installed.marca,
        fogo: installed.fogo,
        mm: installed.mm,
        vidas: installed.vidas,
        motivo: "",
        obs: "",
      });
    }
  });

  lost.forEach((l) => {
    if (normVeh(l.equipamento) !== v) return;
    if (posNum(l.posicao) !== position) return;
    events.push({
      key: `lost-${l.id}`,
      kind: "perda",
      date: l.dataOcorrencia || l.createdAt,
      osNumero: l.registro,
      marca: l.marca,
      fogo: l.fogo,
      mm: l.mm,
      vidas: "",
      motivo: l.motivo || l.motivoOutros,
      obs: l.descricao || l.observacoes,
    });
  });

  return events.sort((a, b) => (b.date || "").localeCompare(a.date || ""));
}

/** Situação de uma posição, apurada a partir dos registros reais. */
export function computeTireStatus(
  orders: SavedOs[],
  lost: LostTireRecord[],
  vehicle: string,
  position: number,
): TireStatus {
  const v = normVeh(vehicle);
  if (!v || !position) return "semRegistro";
  const hasLoss = lost.some((l) => normVeh(l.equipamento) === v && posNum(l.posicao) === position);
  if (hasLoss) return "perda";
  const events = buildTireHistory(orders, lost, vehicle, position);
  if (!events.length) return "semRegistro";
  return events[0].kind === "instalacao" ? "regular" : "manutencao";
}

/** Mapa de situações das 10 posições do veículo (para colorir o desenho). */
export function buildTireStatusMap(
  orders: SavedOs[],
  lost: LostTireRecord[],
  vehicle: string,
): Record<number, TireStatus> {
  const out: Record<number, TireStatus> = {};
  TIRE_POSITIONS.forEach((p) => {
    out[p.id] = computeTireStatus(orders, lost, vehicle, p.id);
  });
  return out;
}

/** Identificação do pneu: usa o registro mais recente que tenha marca ou fogo. */
export function latestTireId(events: TireEvent[]): { fogo: string; marca: string } {
  const found = events.find((e) => hasText(e.fogo) || hasText(e.marca));
  return { fogo: found?.fogo || "", marca: found?.marca || "" };
}

/** Data/hora legível: "12/10/2026 às 18:30" quando houver horário; senão só a data. */
export function fmtEventDate(iso: string): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const date = d.toLocaleDateString("pt-BR");
  const hasTime = /T\d{2}:\d{2}/.test(iso);
  return hasTime ? `${date} às ${d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}` : date;
}

export const TIRE_EVENT_LABEL: Record<TireEvent["kind"], string> = {
  retirada: "Pneu retirado",
  instalacao: "Pneu instalado",
  perda: "Perda registrada",
};

export const TIRE_EVENT_ICON: Record<TireEvent["kind"], string> = {
  retirada: "ri-logout-box-r-line",
  instalacao: "ri-login-box-line",
  perda: "ri-error-warning-line",
};