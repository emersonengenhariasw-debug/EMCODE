export interface LostPhoto {
  id: string;
  /** Caminho no cofre de fotos (preenchido depois do envio). */
  path?: string;
  name: string;
  /** Data e hora do envio da foto. */
  uploadedAt?: string;
}

/** Foto ainda em preparação (antes/neste momento do envio). */
export interface PhotoDraft extends LostPhoto {
  previewUrl: string;
  file?: File;
}

export interface LostTireForm {
  registro: string;
  dataOcorrencia: string;
  operador: string;
  equipamento: string;
  posicao: string;
  marca: string;
  fogo: string;
  mm: string;
  horimetro: string;
  local: string;
  turma: string;
  motivo: string;
  motivoOutros: string;
  descricao: string;
  responsavel: string;
  observacoes: string;
}

export type LostStatus = "rascunho" | "finalizado";

export interface LostTireRecord extends LostTireForm {
  id: string;
  fotos: LostPhoto[];
  status: LostStatus;
  createdAt: string;
  updatedAt: string;
}