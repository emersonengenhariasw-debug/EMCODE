import { isBackendReady, supabase } from "@/lib/supabase";

/*
 * Cadastro manual de CAMINHÕES / EQUIPAMENTOS.
 * Guardado no Backend (tabela tire_vehicles), separado das OS.
 * - o CÓDIGO é o identificador do veículo (ex.: "CB-0", "CB 400");
 * - um código já existente NÃO gera um segundo cadastro (evita duplicados);
 * - o cadastro aparece na lista de seleção do mapa dos pneus.
 */

const TABLE = "tire_vehicles";

export interface Vehicle {
  code: string;
  name: string;
}

const normCode = (s: string) => (s || "").trim().toUpperCase();

/** Lista os caminhões cadastrados manualmente. */
export async function listRegisteredVehicles(): Promise<Vehicle[]> {
  if (!isBackendReady) return [];
  const { data, error } = await supabase
    .from(TABLE)
    .select("code, name")
    .order("code", { ascending: true });
  if (error) throw new Error(error.message);
  return (data ?? []).map((r) => ({
    code: (r as { code?: string }).code ?? "",
    name: (r as { name?: string }).name ?? "",
  }));
}

/**
 * Cadastra um caminhão. Se o código já existir, NÃO cria outro registro —
 * devolve um erro claro para a tela avisar em vez de duplicar.
 */
export async function saveVehicle(input: Vehicle): Promise<Vehicle> {
  if (!isBackendReady) throw new Error("Backend não configurado.");
  const code = normCode(input.code);
  const name = (input.name || "").trim();
  if (!code) throw new Error("Informe o código/identificação do caminhão.");

  const { data, error } = await supabase.from(TABLE).select("code").eq("code", code).maybeSingle();
  if (error) throw new Error(error.message);
  if (data) throw new Error(`O código "${code}" já está cadastrado. Use a seleção para escolhê-lo.`);

  const { error: insErr } = await supabase
    .from(TABLE)
    .insert({ code, name, updated_at: new Date().toISOString() });
  if (insErr) throw new Error(insErr.message);

  return { code, name };
}