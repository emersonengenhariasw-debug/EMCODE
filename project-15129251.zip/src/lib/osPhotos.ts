import type { OsPhoto } from "@/lib/osTypes";
import { isBackendReady, supabase } from "@/lib/supabase";

/*
 * REGISTRO FOTOGRÁFICO das OS — MOVIMENTAÇÃO DE PNEU.
 *
 * As fotos ficam guardadas no cofre privado "os-fotos" do Backend, sempre
 * dentro de UMA pasta por OS (o número da OS é o identificador único). Nada
 * é público: a exibição na tela e os links da planilha usam link assinado.
 *
 * Garantias importantes:
 * - cada arquivo recebe um nome único (data + código), então uma foto nova
 *   NUNCA sobrescreve uma foto anterior;
 * - o envio só é considerado concluído depois de o arquivo ser confirmado no
 *   cofre (não basta o upload responder "ok");
 * - a referência permanente guardada na OS é o "path" (nunca o link temporário).
 */

const BUCKET = "os-fotos";

/** Número da OS em formato seguro para nome de pasta (identificador único). */
function folderOf(numero: string): string {
  const clean = (numero || "sem-numero")
    .toLowerCase()
    .replace(/[^a-z0-9._-]/g, "-")
    .replace(/^-+|-+$/g, "");
  return `os-${clean || "sem-numero"}`.slice(0, 60);
}

/** Extensão válida (JPG, JPEG ou PNG). */
function extOf(name: string): string {
  const e = (name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "");
  return ["jpg", "jpeg", "png"].includes(e) ? e : "jpg";
}

/**
 * Sobe uma foto para a pasta da OS no cofre e devolve os metadados permanentes.
 * Nome único por arquivo: nunca sobrescreve uma foto já guardada.
 */
export async function uploadOsPhoto(numero: string, file: File, index: number): Promise<OsPhoto> {
  if (!isBackendReady) throw new Error("Backend não configurado.");
  const folder = folderOf(numero);
  const ext = extOf(file.name);
  const stamp = Date.now().toString(36);
  const rand = Math.random().toString(36).slice(2, 8);
  const path = `${folder}/${folder}_foto-${String(index).padStart(2, "0")}-${stamp}${rand}.${ext}`;

  const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
    upsert: false,
    contentType: file.type || "image/jpeg",
  });
  if (error) throw new Error(error.message);

  // Confirma que a foto ficou realmente guardada e acessível antes de dar como salva.
  const { data, error: signError } = await supabase.storage.from(BUCKET).createSignedUrl(path, 120);
  if (signError || !data?.signedUrl) {
    throw new Error("O envio da foto não pôde ser confirmado no armazenamento. Tente novamente.");
  }

  return { id: path, path, name: file.name, uploadedAt: new Date().toISOString() };
}

/** Link assinado (temporário) apenas para exibir/baixar a foto guardada. */
export async function signOsPhoto(path: string): Promise<string> {
  if (!isBackendReady || !path) return "";
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(path, 604800);
  if (error) return "";
  return data?.signedUrl ?? "";
}

/**
 * Resolve de uma vez os links de exibição de uma lista de fotos.
 * Devolve uma foto por item (mesma ordem), com link vazio quando indisponível —
 * assim o contador nunca "perde" uma foto que existe no registro.
 */
export async function signOsPhotos(fotos: OsPhoto[]): Promise<{ photo: OsPhoto; url: string }[]> {
  return Promise.all(
    (fotos ?? []).map(async (photo) => ({ photo, url: photo.path ? await signOsPhoto(photo.path) : "" })),
  );
}