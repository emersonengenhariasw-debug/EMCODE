import JSZip from "jszip";

/*
 * Injeção de GRÁFICOS NATIVOS do Excel.
 *
 * A biblioteca que gera a planilha (ExcelJS) não cria gráficos, então a
 * estratégia é: geramos o .xlsx normalmente e depois injetamos, dentro do
 * pacote (que é um ZIP), as peças OOXML que representam os gráficos
 * (xl/charts/*.xml, xl/drawings/*.xml + relacionamentos e content-types).
 *
 * Se QUALQUER coisa sair do esperado, devolvemos o buffer original sem
 * gráficos — assim o arquivo nunca sai corrompido.
 */

export interface ChartAnchor {
  /** Célula superior-esquerda (1-based) da área onde o gráfico será ancorado. */
  fromCol: number;
  fromRow: number;
  /** Célula inferior-direita (1-based). */
  toCol: number;
  toRow: number;
}

export interface NativeChart {
  /** Nome exato da aba que recebe o gráfico (ex.: "Dashboard"). */
  sheetName: string;
  anchor: ChartAnchor;
  /** Conteúdo completo do <c:chartSpace>. */
  xml: string;
}

const REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const XDR = "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing";
const A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main";
const C_NS = "http://schemas.openxmlformats.org/drawingml/2006/chart";

const EMPTY_RELS =
  '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
  '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"></Relationships>';

function attrs(tag: string): Record<string, string> {
  const out: Record<string, string> = {};
  const re = /([\w:]+)="([^"]*)"/g;
  let m = re.exec(tag);
  while (m) {
    out[m[1]] = m[2];
    m = re.exec(tag);
  }
  return out;
}

function resolveTarget(baseDir: string, target: string): string {
  if (target.startsWith("/")) return target.slice(1);
  const parts = baseDir.split("/").filter(Boolean);
  target.split("/").forEach((seg) => {
    if (seg === "." || seg === "") return;
    if (seg === "..") parts.pop();
    else parts.push(seg);
  });
  return parts.join("/");
}

function ensureOverride(ctXml: string, partName: string, contentType: string): string {
  if (ctXml.includes(`PartName="${partName}"`)) return ctXml;
  return ctXml.replace(
    "</Types>",
    `<Override PartName="${partName}" ContentType="${contentType}"/></Types>`,
  );
}

function ensureRNamespace(xml: string): string {
  if (xml.includes("xmlns:r=")) return xml;
  return xml.replace(/<worksheet\b([^>]*)>/, (_full, rest: string) => {
    return `<worksheet xmlns:r="${REL}"${rest}>`;
  });
}

function frameXml(a: ChartAnchor, relId: string, id: number): string {
  const fCol = a.fromCol - 1;
  const fRow = a.fromRow - 1;
  const tCol = a.toCol - 1;
  const tRow = a.toRow - 1;
  return (
    "<xdr:twoCellAnchor>" +
    `<xdr:from><xdr:col>${fCol}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${fRow}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>` +
    `<xdr:to><xdr:col>${tCol}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${tRow}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>` +
    '<xdr:graphicFrame macro="">' +
    `<xdr:nvGraphicFramePr><xdr:cNvPr id="${id}" name="Grafico ${id}"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr>` +
    '<xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm>' +
    `<a:graphic><a:graphicData uri="${C_NS}">` +
    `<c:chart xmlns:c="${C_NS}" xmlns:r="${REL}" r:id="${relId}"/>` +
    "</a:graphicData></a:graphic>" +
    "</xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor>"
  );
}

export async function injectNativeCharts(
  buffer: ArrayBuffer,
  charts: NativeChart[],
): Promise<ArrayBuffer> {
  if (!charts.length) return buffer;
  try {
    const zip = await JSZip.loadAsync(buffer);

    const wbFile = zip.file("xl/workbook.xml");
    const wbRelsFile = zip.file("xl/_rels/workbook.xml.rels");
    const ctFile = zip.file("[Content_Types].xml");
    if (!wbFile || !wbRelsFile || !ctFile) return buffer;

    const wbXml = await wbFile.async("string");
    const wbRels = await wbRelsFile.async("string");
    let ctXml = await ctFile.async("string");

    const relById = new Map<string, string>();
    (wbRels.match(/<Relationship\b[^>]*\/>/g) || []).forEach((tag) => {
      const a = attrs(tag);
      if (a.Id && a.Target) relById.set(a.Id, a.Target);
    });

    const sheetPathByName = new Map<string, string>();
    (wbXml.match(/<sheet\b[^>]*\/>/g) || []).forEach((tag) => {
      const a = attrs(tag);
      const rid = a["r:id"] || a.id;
      const target = rid ? relById.get(rid) : "";
      if (a.name && target) sheetPathByName.set(a.name, resolveTarget("xl", target));
    });

    const groups = new Map<string, NativeChart[]>();
    charts.forEach((ch) => {
      const p = sheetPathByName.get(ch.sheetName);
      if (!p) return;
      const list = groups.get(p) || [];
      list.push(ch);
      groups.set(p, list);
    });

    let maxChart = 0;
    let maxDrawing = 0;
    zip.forEach((path) => {
      const mc = /^xl\/charts\/chart(\d+)\.xml$/.exec(path);
      if (mc) maxChart = Math.max(maxChart, Number(mc[1]));
      const md = /^xl\/drawings\/drawing(\d+)\.xml$/.exec(path);
      if (md) maxDrawing = Math.max(maxDrawing, Number(md[1]));
    });

    let injected = 0;

    for (const [sheetPath, list] of groups) {
      const sheetFile = sheetPath.split("/").pop() || "";
      const sheetRelsPath = `xl/worksheets/_rels/${sheetFile}.rels`;
      const sheetRelsHandle = zip.file(sheetRelsPath);
      let sheetRelsXml = sheetRelsHandle ? await sheetRelsHandle.async("string") : EMPTY_RELS;
      let sheetXml = await zip.file(sheetPath)!.async("string");

      // Procura um drawing já existente nesta aba.
      let drawingPath = "";
      let drawingRelId = "";
      (sheetRelsXml.match(/<Relationship\b[^>]*\/>/g) || []).forEach((tag) => {
        const a = attrs(tag);
        if (a.Type && a.Type.endsWith("/drawing") && a.Target) {
          drawingRelId = a.Id;
          drawingPath = resolveTarget("xl/worksheets", a.Target);
        }
      });

      // Se não existe, cria um drawing novo e liga ao worksheet.
      if (!drawingPath) {
        maxDrawing += 1;
        const drawingFile = `drawing${maxDrawing}.xml`;
        drawingPath = `xl/drawings/${drawingFile}`;
        drawingRelId = `rIdDraw${maxDrawing}`;
        sheetRelsXml = sheetRelsXml.replace(
          "</Relationships>",
          `<Relationship Id="${drawingRelId}" Type="${REL}/drawing" Target="../drawings/${drawingFile}"/></Relationships>`,
        );
        zip.file(sheetRelsPath, sheetRelsXml);
        const drawingTag = `<drawing r:id="${drawingRelId}"/>`;
        const baseSheet = ensureRNamespace(sheetXml);
        if (baseSheet.includes("<tableParts")) {
          sheetXml = baseSheet.replace("<tableParts", `${drawingTag}<tableParts`);
        } else if (baseSheet.includes("<extLst")) {
          sheetXml = baseSheet.replace("<extLst", `${drawingTag}<extLst`);
        } else {
          sheetXml = baseSheet.replace("</worksheet>", `${drawingTag}</worksheet>`);
        }
        zip.file(sheetPath, sheetXml);
        ctXml = ensureOverride(
          ctXml,
          `/xl/drawings/${drawingFile}`,
          "application/vnd.openxmlformats-officedocument.drawing+xml",
        );
      } else {
        zip.file(sheetRelsPath, sheetRelsXml);
      }

      const drawingFile = drawingPath.split("/").pop() || "";
      const drawingRelsPath = `xl/drawings/_rels/${drawingFile}.rels`;
      const drawingRelsHandle = zip.file(drawingRelsPath);
      let drawingRelsXml = drawingRelsHandle
        ? await drawingRelsHandle.async("string")
        : EMPTY_RELS;

      let maxR = 0;
      (drawingRelsXml.match(/<Relationship\b[^>]*\/>/g) || []).forEach((tag) => {
        const a = attrs(tag);
        const m = /rId(\d+)/.exec(a.Id || "");
        if (m) maxR = Math.max(maxR, Number(m[1]));
      });

      const existing = zip.file(drawingPath);
      const existingXml = existing ? await existing.async("string") : "";
      let cNvId = 1;
      (existingXml.match(/<xdr:cNvPr\b[^>]*\/>/g) || []).forEach((tag) => {
        const a = attrs(tag);
        const id = Number(a.id || 0);
        if (id >= cNvId) cNvId = id + 1;
      });

      let frames = "";
      list.forEach((ch) => {
        maxChart += 1;
        const chartFile = `chart${maxChart}.xml`;
        const xmlDecl =
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
        zip.file(`xl/charts/${chartFile}`, xmlDecl + ch.xml);
        ctXml = ensureOverride(
          ctXml,
          `/xl/charts/${chartFile}`,
          "application/vnd.openxmlformats-officedocument.drawingml.chart+xml",
        );
        maxR += 1;
        const relId = `rId${maxR}`;
        drawingRelsXml = drawingRelsXml.replace(
          "</Relationships>",
          `<Relationship Id="${relId}" Type="${REL}/chart" Target="../charts/${chartFile}"/></Relationships>`,
        );
        frames += frameXml(ch.anchor, relId, cNvId);
        cNvId += 1;
        injected += 1;
      });

      const drawingRoot = existingXml
        ? existingXml
        : `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<xdr:wsDr xmlns:xdr="${XDR}" xmlns:a="${A_NS}"></xdr:wsDr>`;
      const drawingOut = drawingRoot.replace("</xdr:wsDr>", `${frames}</xdr:wsDr>`);
      zip.file(drawingPath, drawingOut);
      zip.file(drawingRelsPath, drawingRelsXml);
    }

    if (!injected) return buffer;

    zip.file("[Content_Types].xml", ctXml);
    return await zip.generateAsync({
      type: "arraybuffer",
      mimeType:
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
  } catch {
    return buffer;
  }
}