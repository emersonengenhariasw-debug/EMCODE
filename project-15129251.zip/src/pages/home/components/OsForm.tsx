import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type {
  OsFormData,
  OsPhoto,
  OsPhotoDraft,
  OsTireInstalled,
  OsTireRemoved,
  SavedOs,
} from "@/lib/osTypes";
import {
  createEmptyOs,
  osRequiresPhoto,
  OS_INSTALLED_ROWS,
  OS_REMOVED_ROWS,
} from "@/mocks/osForm";
import { OS_SAMPLE } from "@/mocks/osSample";
import { deleteOs, getOs, listOs, migrateLocalHistory, saveOs } from "@/lib/osDb";
import { listLostTires } from "@/lib/lostTiresDb";
import type { LostTireRecord } from "@/lib/lostTiresTypes";
import { listTireStatuses, saveTireStatuses, type EditableTireStatus } from "@/lib/tireStatusDb";
import { exportExcel } from "@/lib/osExport";
import { signOsPhoto, signOsPhotos, uploadOsPhoto } from "@/lib/osPhotos";
import { downloadPhotoWithStamp, photoStampCaption } from "@/lib/osPhotoStamp";
import {
  applyImport,
  captureBaselines,
  parseExcelImport,
  type ImportDecision,
  type ImportResult,
} from "@/lib/osSync";
import { diffOs, logOsChanges } from "@/lib/osChangeLog";
import OsHeaderFields from "@/pages/home/components/OsHeaderFields";
import OsTireTables from "@/pages/home/components/OsTireTables";
import OsMotives from "@/pages/home/components/OsMotives";
import OsObservations from "@/pages/home/components/OsObservations";
import OsPhotoField from "@/pages/home/components/OsPhotoField";
import TireMapBlock from "@/pages/home/components/TireMapBlock";
import FinalizeFlow from "@/pages/home/components/FinalizeFlow";
import OsHistory from "@/pages/home/components/OsHistory";
import OsSummary from "@/pages/home/components/OsSummary";
import OsChangeLog from "@/pages/home/components/OsChangeLog";
import OsImport from "@/pages/home/components/OsImport";

type Status = { type: "ok" | "err"; text: string } | null;

/* Garante que uma OS recuperada tenha sempre todas as linhas das tabelas,
   mesmo que tenha sido salva com menos (ou mais) linhas no passado. */
function padRows<T>(rows: T[] | undefined, length: number, empty: () => T): T[] {
  const out = Array.isArray(rows) ? [...rows] : [];
  while (out.length < length) out.push(empty());
  return out;
}

const emptyRemoved = (): OsTireRemoved => ({
  posicao: "",
  marca: "",
  fogo: "",
  mm: "",
  motivo: "",
  vidas: "",
});

const emptyInstalled = (): OsTireInstalled => ({ marca: "", fogo: "", mm: "", vidas: "" });

const MAX_OS_PHOTOS = 5;
const PHOTO_ACCEPT_TYPES = ["image/jpeg", "image/jpg", "image/png"];
const PHOTO_REQUIRED_MSG =
  "REGISTRO FOTOGRÁFICO OBRIGATÓRIO. ANEXE PELO MENOS UMA FOTO DO PNEU PARA FINALIZAR A OS.";

/* Sobe as fotos pendentes e devolve os metadados prontos para gravar na OS. */
async function ensurePhotosUploaded(drafts: OsPhotoDraft[], numero: string): Promise<OsPhoto[]> {
  const out: OsPhoto[] = [];
  for (const d of drafts) {
    if (d.path) {
      out.push({ id: d.id, path: d.path, name: d.name, uploadedAt: d.uploadedAt });
    } else if (d.file) {
      const up = await uploadOsPhoto(numero, d.file, out.length + 1);
      out.push(up);
    }
  }
  return out;
}

/* Próximo Nº da OS: maior número já salvo + 1 (começa em 1 quando ainda não há OS). */
function nextOsNumber(orders: SavedOs[]): string {
  let max = 0;
  for (const o of orders) {
    const n = parseInt(String(o.numero).replace(/\D/g, ""), 10);
    if (!Number.isNaN(n) && n > max) max = n;
  }
  return String(max + 1);
}

export default function OsForm() {
  const [form, setForm] = useState<OsFormData>(createEmptyOs);
  const [savedList, setSavedList] = useState<SavedOs[]>([]);
  const [finalized, setFinalized] = useState(false);
  const [savedFlag, setSavedFlag] = useState(false);
  const [status, setStatus] = useState<Status>(null);
  const [finishConfirmOpen, setFinishConfirmOpen] = useState(false);
  const [fotos, setFotos] = useState<OsPhotoDraft[]>([]);
  const [lightbox, setLightbox] = useState<{ urls: string[]; index: number; title: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const [activeOsId, setActiveOsId] = useState<string | undefined>(undefined);
  const [activeSavedAt, setActiveSavedAt] = useState<string | null>(null);
  const [openingId, setOpeningId] = useState<string | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const [importLoading, setImportLoading] = useState(false);
  const [importApplying, setImportApplying] = useState(false);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [changeLogKey, setChangeLogKey] = useState(0);
  const [lostTires, setLostTires] = useState<LostTireRecord[]>([]);
  const [mapPosition, setMapPosition] = useState<number | null>(null);
  const [situacoes, setSituacoes] = useState<Record<number, EditableTireStatus>>({});
  const scrollOnOpen = useRef(0);
  const photoRequired = useMemo(() => osRequiresPhoto(form), [form]);

  /* Situações dos pneus do caminhão em foco: recarrega do banco sempre que o
     veículo muda (troca de caminhão, abertura de OS ou recarregamento da página). */
  useEffect(() => {
    let active = true;
    const vehicle = form.equip.trim();
    if (!vehicle) {
      setSituacoes({});
      return () => {
        active = false;
      };
    }
    listTireStatuses(vehicle)
      .then((map) => {
        if (active) setSituacoes(map);
      })
      .catch(() => {
        if (active) setSituacoes({});
      });
    return () => {
      active = false;
    };
  }, [form.equip]);

  /* Guarda a situação escolhida para uma posição do pneu (antes de salvar). */
  const handleSetSituacao = useCallback((position: number, s: EditableTireStatus) => {
    setSituacoes((prev) => ({ ...prev, [position]: s }));
  }, []);

  const refreshList = useCallback(async () => {
    try {
      setSavedList(await listOs());
    } catch {
      /* storage may be unavailable on this device — the form still works */
    }
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        // Sobe para o banco o histórico que já existia neste tablet (uma vez, sem duplicar).
        await migrateLocalHistory();
        const [list, lostList] = await Promise.all([
          listOs(),
          listLostTires().catch(() => [] as LostTireRecord[]),
        ]);
        if (!active) return;
        setSavedList(list);
        setLostTires(lostList);
        // O Nº começa em 1 e segue a sequência das OS já salvas no banco.
        setForm((prev) => (prev.numero.trim() ? prev : { ...prev, numero: nextOsNumber(list) }));
      } catch {
        /* backend may be unreachable — the form still works offline */
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const patch = useCallback((p: Partial<OsFormData>) => {
    setForm((prev) => ({ ...prev, ...p }));
  }, []);

  const setRemoved = useCallback((index: number, key: keyof OsTireRemoved, value: string) => {
    setForm((prev) => {
      const retirados = prev.retirados.map((r, i) => (i === index ? { ...r, [key]: value } : r));
      return { ...prev, retirados };
    });
  }, []);

  const setInstalled = useCallback((index: number, key: keyof OsTireInstalled, value: string) => {
    setForm((prev) => {
      const instalados = prev.instalados.map((r, i) => (i === index ? { ...r, [key]: value } : r));
      return { ...prev, instalados };
    });
  }, []);

  const toggleMotivo = useCallback((motive: string) => {
    setForm((prev) => ({
      ...prev,
      motivos: prev.motivos.includes(motive)
        ? prev.motivos.filter((m) => m !== motive)
        : [...prev.motivos, motive],
    }));
  }, []);

  const addPhotos = useCallback(
    (files: File[]) => {
      const allowed = files.filter((f) => PHOTO_ACCEPT_TYPES.includes(f.type.toLowerCase()));
      if (!allowed.length) {
        setStatus({ type: "err", text: "Formato não aceito. Anexe imagens JPG, JPEG ou PNG." });
        return;
      }
      const room = MAX_OS_PHOTOS - fotos.length;
      if (room <= 0) {
        setStatus({ type: "err", text: `Limite de ${MAX_OS_PHOTOS} fotos por OS atingido.` });
        return;
      }
      const picked: OsPhotoDraft[] = allowed.slice(0, room).map((f, i) => ({
        id: `osf-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 7)}`,
        name: f.name,
        file: f,
        previewUrl: URL.createObjectURL(f),
      }));
      setFotos((prev) => [...prev, ...picked]);
      if (allowed.length > room) {
        setStatus({
          type: "err",
          text: `Só cabem ${MAX_OS_PHOTOS} fotos por OS. As demais foram ignoradas.`,
        });
      }
    },
    [fotos.length],
  );

  const removePhoto = useCallback((id: string) => {
    setFotos((prev) => {
      const target = prev.find((f) => f.id === id);
      if (target?.previewUrl && target.previewUrl.startsWith("blob:")) {
        URL.revokeObjectURL(target.previewUrl);
      }
      return prev.filter((f) => f.id !== id);
    });
  }, []);

  const filled = useMemo(() => {
    const hasHeader = Boolean(
      form.numero || form.turno || form.inicio || form.termino || form.horimetro || form.data ||
      form.dataEntrada || form.dataSaida ||
      form.operador || form.km || form.equip || form.executantes || form.local || form.turma,
    );
    const hasTires = form.retirados.some((r) => r.posicao || r.marca || r.fogo || r.mm || r.motivo || r.vidas)
      || form.instalados.some((r) => r.marca || r.fogo || r.mm || r.vidas);
    return hasHeader || hasTires || form.motivos.length > 0 || form.observacoes.length > 0;
  }, [form]);

  const persist = useCallback(
    async (markFinalized: boolean): Promise<SavedOs[] | null> => {
      if (saving) return null;
      setSaving(true);
      try {
        const finalStamp = markFinalized
          ? form.finalizedAt ?? new Date().toISOString()
          : form.finalizedAt;
        const numero = form.numero.trim() || `os-${Date.now()}`;
        // Sobe as fotos antes de gravar: só conclui se o armazenamento confirmar.
        const uploaded = await ensurePhotosUploaded(fotos, numero);
        // Foto anterior do registro (para o histórico de alterações).
        let prevRecord: SavedOs | undefined;
        try {
          prevRecord = await getOs(numero);
        } catch {
          prevRecord = undefined;
        }
        const record: SavedOs = {
          ...form,
          fotos: uploaded,
          finalizedAt: finalStamp,
          id: numero,
          savedAt: new Date().toISOString(),
          finalized: markFinalized || finalized,
        };
        await saveOs(record);
        // Grava a situação escolhida de cada pneu, vinculada ao caminhão e à posição.
        const vehicle = form.equip.trim();
        if (vehicle) {
          await saveTireStatuses(vehicle, situacoes);
        }
        // Registra no histórico o que o sistema alterou (nada é apagado).
        void logOsChanges(diffOs(prevRecord, record));
        setChangeLogKey((k) => k + 1);
        // Depois de salvar, o Nº já avança +1 para a próxima OS.
        const list = await listOs();
        setSavedList(list);
        setForm((prev) => ({
          ...prev,
          finalizedAt: finalStamp,
          numero: nextOsNumber(list),
          fotos: [],
        }));
        setFotos([]);
        setSavedFlag(true);
        setActiveOsId(undefined);
        setActiveSavedAt(record.savedAt);
        setMapPosition(null);
        if (markFinalized) setFinalized(true);
        setStatus({
          type: "ok",
          text: markFinalized
            ? `OS ${record.numero || "s/n"} finalizada e salva no banco de dados, com ${uploaded.length} foto(s) armazenada(s).`
            : `OS ${record.numero || "s/n"} salva no banco de dados e pronta para exportação.`,
        });
        return list;
      } catch {
        setStatus({
          type: "err",
          text: "Não foi possível concluir o salvamento agora. Verifique a conexão e tente novamente — os dados e as fotos continuam na tela.",
        });
        return null;
      } finally {
        setSaving(false);
      }
    },
    [form, finalized, fotos, saving, situacoes],
  );

  const handleSave = useCallback(() => {
    void persist(finalized);
  }, [persist, finalized]);

  /* ABRIR uma OS salva: identifica pelo Nº (identificador único), busca o registro
     completo no Backend, carrega TODOS os campos no formulário e só então rola a tela.
     Se a OS não for encontrada, avisa — sem limpar nem sobrescrever a ficha. */
  const handleOpenOs = useCallback(
    async (id: string) => {
      const key = (id || "").trim();
      if (!key) {
        setStatus({ type: "err", text: "Não foi possível identificar a OS selecionada." });
        return;
      }
      setOpeningId(key);
      // Reserva imediata: o registro já conhecido na lista (nunca abre vazio).
      let full: SavedOs | undefined = savedList.find((o) => o.id === key);
      let fetchError = false;
      try {
        const fresh = await getOs(key);
        if (fresh) full = fresh;
      } catch {
        fetchError = true;
      }
      // Não achou em lugar nenhum → mostra erro e NÃO mexe no que está na tela.
      if (!full) {
        setOpeningId(null);
        setStatus({
          type: "err",
          text: `A OS ${key} não foi encontrada no banco de dados${fetchError ? " (verifique a conexão)" : ""}. Nada foi alterado na ficha.`,
        });
        return;
      }
      const { id: recId, savedAt, finalized: fin, ...data } = full;
      void savedAt;
      setForm({
        ...createEmptyOs(),
        ...data,
        numero: data.numero || recId,
        dataEntrada: data.dataEntrada ?? "",
        dataSaida: data.dataSaida ?? "",
        supervisorNome: data.supervisorNome ?? "",
        fotos: data.fotos ?? [],
        retirados: padRows(data.retirados, OS_REMOVED_ROWS, emptyRemoved),
        instalados: padRows(data.instalados, OS_INSTALLED_ROWS, emptyInstalled),
      });
      setFinalized(Boolean(fin));
      setSavedFlag(true);
      setActiveOsId(recId);
      setActiveSavedAt(savedAt ?? null);
      setMapPosition(null);
      // Reconstrói TODAS as fotos anexadas (link protegido) para exibir na consulta.
      // Cada foto vira um item — mesmo que um link falhe, a foto continua contada.
      const resolved = await signOsPhotos(data.fotos ?? []);
      const drafts: OsPhotoDraft[] = resolved.map(({ photo, url }) => ({ ...photo, previewUrl: url }));
      setFotos(drafts);
      setStatus({
        type: "ok",
        text: `OS ${data.numero || recId} aberta com todos os dados preenchidos.`,
      });
      // Mantém o histórico em sincronia com o banco (sem apagar nada).
      void refreshList();
      // Só rola a tela depois que os dados já foram para o formulário.
      scrollOnOpen.current += 1;
      setOpeningId(null);
    },
    [savedList, refreshList],
  );

  // Rolagem garantida para a ficha, executada depois que o React renderiza os dados.
  useEffect(() => {
    if (!scrollOnOpen.current) return;
    scrollOnOpen.current = 0;
    const el = document.getElementById("os-form");
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [form]);

  const handleSample = useCallback(() => {
    setForm({ ...OS_SAMPLE, retirados: OS_SAMPLE.retirados.map((r) => ({ ...r })), instalados: OS_SAMPLE.instalados.map((r) => ({ ...r })) });
    setFotos([]);
    setFinalized(false);
    setSavedFlag(false);
    setActiveOsId(undefined);
    setActiveSavedAt(null);
    setMapPosition(null);
    setStatus({
      type: "ok",
      text: "OS de exemplo carregada. Clique em Excel para baixar a planilha com as colunas já ajustadas.",
    });
  }, []);

  /* Clique em um pneu do mapa: guarda a posição em foco e lança a posição na OS. */
  const handleMapSelect = useCallback((pos: number) => {
    setMapPosition(pos);
    setForm((prev) => ({
      ...prev,
      retirados: prev.retirados.map((r, i) => (i === pos - 1 ? { ...r, posicao: String(pos) } : r)),
    }));
  }, []);

  /* Zera a ficha e deixa o próximo Nº pronto — sem apagar as OS salvas. */
  const resetToNew = useCallback((list: SavedOs[]) => {
    setForm({ ...createEmptyOs(), numero: nextOsNumber(list) });
    setFotos([]);
    setFinalized(false);
    setSavedFlag(false);
    setActiveOsId(undefined);
    setActiveSavedAt(null);
    setMapPosition(null);
  }, []);

  /* Finalizar Serviço: registra a OS atual (nada é perdido) e limpa a ficha,
     deixando tudo pronto para uma nova OS. Não apaga OS salvas nem histórico. */
  const finishService = useCallback(async () => {
    setFinishConfirmOpen(false);
    if (filled) {
      const list = await persist(true);
      if (!list) return; // falhou ao salvar — a ficha continua como está
      resetToNew(list);
    } else {
      resetToNew(savedList);
    }
    setStatus({
      type: "ok",
      text: "Serviço finalizado. Ficha limpa e pronta para uma nova Ordem de Serviço.",
    });
    const el = document.getElementById("os-form");
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [filled, persist, resetToNew, savedList]);

  const handleFinishService = useCallback(() => {
    const hasMovement =
      form.retirados.some((r) => r.posicao || r.marca || r.fogo || r.mm || r.motivo || r.vidas) ||
      form.instalados.some((r) => r.marca || r.fogo || r.mm || r.vidas);
    // Perda / acidente / avaria exige registro fotográfico antes de finalizar.
    if (hasMovement && osRequiresPhoto(form) && fotos.length === 0) {
      setStatus({ type: "err", text: PHOTO_REQUIRED_MSG });
      return;
    }
    // Se houver preenchimento ainda não salvo, confirma antes de encerrar.
    if (filled && !savedFlag) {
      setFinishConfirmOpen(true);
      return;
    }
    void finishService();
  }, [form, fotos, filled, savedFlag, finishService]);

  /* Baixa uma cópia da foto com a data e a hora carimbadas no rodapé. */
  const handlePhotoDownload = useCallback(
    (index: number) => {
      const f = fotos[index];
      if (!f) return;
      const pad2 = (n: number) => String(n).padStart(2, "0");
      const now = new Date();
      const base = (f.name || `foto-${index + 1}`).replace(/\.[^.]+$/, "") || `foto-${index + 1}`;
      const fileName = `OS-${(form.numero || "s-n").replace(/\s/g, "")}_${base}_${pad2(now.getDate())}-${pad2(now.getMonth() + 1)}-${now.getFullYear()}.jpg`;
      downloadPhotoWithStamp(f.previewUrl, fileName, photoStampCaption(f)).catch(() => {
        setStatus({
          type: "err",
          text: "Não foi possível gerar a cópia com data e hora agora. Tente novamente.",
        });
      });
    },
    [fotos, form.numero],
  );

  const handleDelete = useCallback(
    async (id: string) => {
      try {
        await deleteOs(id);
        await refreshList();
        setStatus({ type: "ok", text: "OS removida do banco de dados." });
      } catch {
        setStatus({ type: "err", text: "Não foi possível remover a OS." });
      }
    },
    [refreshList],
  );

  /* EXCEL — acumula TODAS as OS do histórico no banco, finalizadas ou em
     preenchimento, sem filtro de data e sem substituir nenhum registro.
     Só cai na OS da tela quando ainda não existe nenhuma OS salva. */
  const handleExcel = useCallback(async () => {
    const source: SavedOs[] = savedList.length
      ? [...savedList]
      : filled
        ? [
            {
              ...form,
              id: form.numero.trim() || `os-${Date.now()}`,
              savedAt: new Date().toISOString(),
              finalized: true,
            },
          ]
        : [];
    if (!source.length) {
      setStatus({
        type: "err",
        text: "Nenhuma OS para exportar. Finalize (ou preencha) uma OS antes de gerar a planilha.",
      });
      return;
    }
    try {
      // Resolve os links protegidos das fotos de cada OS para a coluna FOTOS.
      const photoLinks: Record<string, string[]> = {};
      for (const o of source) {
        const urls: string[] = [];
        for (const p of o.fotos ?? []) {
          const url = p.path ? await signOsPhoto(p.path) : "";
          if (url) urls.push(url);
        }
        if (urls.length) photoLinks[(o.numero || o.id).trim()] = urls;
      }
      // Pneus perdidos (painel de manutenção) entram no indicador — se falhar, a planilha sai igual.
      let lost: LostTireRecord[] = [];
      try {
        lost = await listLostTires();
      } catch {
        lost = [];
      }
      await exportExcel(source, photoLinks, lost);
      // Guarda a "foto" do que foi para a planilha (detecta conflitos no import).
      await captureBaselines(source);
      const totalMov = source.reduce((acc, o) => {
        const r = o.retirados.filter((t) => t.posicao || t.marca || t.fogo || t.mm || t.motivo || t.vidas).length;
        const i = o.instalados.filter((t) => t.marca || t.fogo || t.mm || t.vidas).length;
        return acc + Math.max(r, i);
      }, 0);
      setStatus({
        type: "ok",
        text: `Planilha CONTROLE_GERAL_DE_PNEUS_JULY_QUARTZO.xlsx gerada com TODAS as ${source.length} OS do histórico (${totalMov} movimentações de pneu), a coluna FOTOS e as abas de indicadores do dashboard.`,
      });
    } catch {
      setStatus({
        type: "err",
        text: "Não foi possível gerar a planilha Excel neste dispositivo.",
      });
    }
  }, [savedList, form, filled]);

  const handlePrint = useCallback(() => {
    window.print();
  }, []);

  /* Sincronização (vai-e-volta do arquivo): lê a planilha editada, mostra as
     mudanças e conflitos e só grava depois da confirmação do usuário. */
  const handleImportOpen = useCallback(() => {
    setImportResult(null);
    setImportError(null);
    setImportOpen(true);
  }, []);

  const handleImportFile = useCallback(async (file: File) => {
    setImportLoading(true);
    setImportError(null);
    try {
      setImportResult(await parseExcelImport(file));
    } catch {
      setImportResult(null);
      setImportError(
        "Não foi possível ler a planilha. Confirme que é o arquivo .xlsx gerado pelo sistema e que ele não está aberto em outro programa.",
      );
    } finally {
      setImportLoading(false);
    }
  }, []);

  const handleImportApply = useCallback(
    async (decisions: ImportDecision[]) => {
      setImportApplying(true);
      try {
        const res = await applyImport(decisions);
        await refreshList();
        setChangeLogKey((k) => k + 1);
        setImportOpen(false);
        setImportResult(null);
        setStatus({
          type: "ok",
          text: res.applied
            ? `Sincronização concluída: ${res.applied} campo(s) atualizado(s) em ${res.osCount} OS, sem duplicar registros.`
            : `Sincronização revisada: nenhuma mudança do Excel foi aplicada (${res.osCount} OS mantidas com o valor do sistema).`,
        });
      } catch {
        setImportError(
          "Não foi possível aplicar a sincronização agora. Verifique a conexão e tente de novo — nada foi alterado.",
        );
      } finally {
        setImportApplying(false);
      }
    },
    [refreshList],
  );

  return (
    <section className="os-section" id="os-form" aria-label="OS - Movimentação de Pneu">
      <div className="os-quickbar">
        <div className="os-quickbar-info">
          <span className="os-quickbar-kicker">
            <i className="ri-file-list-3-line" aria-hidden="true" /> Ordem em edição
          </span>
          <span className="os-quickbar-num">Nº {form.numero || "s/n"}</span>
          <span className={`os-quickbar-tag${activeOsId ? " is-open" : ""}`}>
            {activeOsId ? "Aberta" : "Nova"}
          </span>
        </div>
        <div className="os-quickbar-actions">
          <button
            type="button"
            className="btn btn-blue os-quickbar-btn"
            onClick={handleSave}
            disabled={saving}
          >
            <i className="ri-save-3-line" aria-hidden="true" /> {saving ? "Salvando…" : "Salvar Dados"}
          </button>
          <button
            type="button"
            className="btn btn-primary os-quickbar-btn"
            onClick={handleFinishService}
            disabled={saving}
          >
            <i className="ri-check-double-line" aria-hidden="true" /> Finalizar Serviço
          </button>
        </div>
      </div>

      {status && (
        <p className={`os-status${status.type === "err" ? " is-err" : " is-ok"}`} role="status">
          <i
            className={status.type === "err" ? "ri-error-warning-line" : "ri-checkbox-circle-line"}
            aria-hidden="true"
          />
          {status.text}
        </p>
      )}

      <div className="os-paper" data-reveal>
        <OsHeaderFields form={form} patch={patch} />

        <div className="os-body">
          <div className="os-body-main">
            <OsTireTables
              form={form}
              setRemoved={setRemoved}
              setInstalled={setInstalled}
              activePosition={mapPosition}
              photoField={
                <OsPhotoField
                  fotos={fotos}
                  required={photoRequired}
                  onAdd={addPhotos}
                  onRemove={removePhoto}
                  onDownload={handlePhotoDownload}
                  onZoom={(i) =>
                    setLightbox({
                      urls: fotos.map((f) => f.previewUrl),
                      index: i,
                      title: `OS ${form.numero || "s/n"} — Registro Fotográfico`,
                    })
                  }
                />
              }
            />

            <OsMotives selected={form.motivos} onToggle={toggleMotivo} />
            <OsObservations
              observacoes={form.observacoes}
              onChange={(v) => patch({ observacoes: v.slice(0, 500) })}
              supervisorNome={form.supervisorNome}
              onSupervisorChange={(v) => patch({ supervisorNome: v.slice(0, 80) })}
            />
          </div>

          <aside className="os-body-side" aria-label="Mapa do caminhão e histórico de pneus">
            <TireMapBlock
              orders={savedList}
              lost={lostTires}
              equipment={form.equip}
              onEquipmentChange={(v) => patch({ equip: v })}
              selected={mapPosition}
              onSelect={handleMapSelect}
              overrides={situacoes}
              onSetStatus={handleSetSituacao}
            />
          </aside>
        </div>
      </div>

      <FinalizeFlow
        filled={filled}
        finalized={finalized}
        savedFlag={savedFlag}
        savedList={savedList}
        openingId={openingId}
        savedAt={activeSavedAt}
        onLoad={handleOpenOs}
        onDelete={handleDelete}
        onExcel={handleExcel}
        onImport={handleImportOpen}
        importing={importLoading}
        onPrint={handlePrint}
        onSample={handleSample}
      />

      <OsHistory
        orders={savedList}
        activeId={activeOsId}
        openingId={openingId}
        onOpen={handleOpenOs}
        onDelete={handleDelete}
      />

      <OsSummary orders={savedList} />

      <OsChangeLog refreshKey={changeLogKey} />

      <OsImport
        open={importOpen}
        loading={importLoading}
        applying={importApplying}
        result={importResult}
        error={importError}
        onPickFile={handleImportFile}
        onApply={handleImportApply}
        onClose={() => {
          if (!importApplying) setImportOpen(false);
        }}
      />

      <p className="os-foot-note">
        JULY QUARTZO · MINERAÇÃO E CONSTRUÇÃO — OS - MOVIMENTAÇÃO DE PNEU · os dados ficam
        associados à ordem de serviço informada no número (Nº).
      </p>

      {finishConfirmOpen && (
        <div className="modal-veil" role="dialog" aria-modal="true" aria-label="Finalizar serviço">
          <div className="modal">
            <h3>Finalizar o serviço atual?</h3>
            <p>
              O preenchimento de agora será encerrado. A OS {form.numero || "sem número"} é
              registrada e a ficha fica limpa, pronta para uma nova OS. Nenhuma OS salva nem o
              histórico dos pneus são apagados.
            </p>
            <div className="modal-actions">
              <button type="button" className="btn btn-ghost" onClick={() => setFinishConfirmOpen(false)}>
                Cancelar
              </button>
              <button type="button" className="btn btn-primary" onClick={() => void finishService()}>
                <i className="ri-check-double-line" aria-hidden="true" /> Finalizar e salvar
              </button>
            </div>
          </div>
        </div>
      )}

      {lightbox && (
        <div
          className="lightbox"
          role="dialog"
          aria-modal="true"
          aria-label={lightbox.title}
          onClick={() => setLightbox(null)}
        >
          <button type="button" className="lightbox-close" onClick={() => setLightbox(null)} aria-label="Fechar">
            <i className="ri-close-line" aria-hidden="true" />
          </button>
          <button
            type="button"
            className="lightbox-download"
            onClick={(e) => {
              e.stopPropagation();
              handlePhotoDownload(lightbox.index);
            }}
            aria-label="Baixar cópia com data e hora"
            title="Baixar cópia com data e hora"
          >
            <i className="ri-download-2-line" aria-hidden="true" /> Baixar com data
          </button>
          {lightbox.urls.length > 1 && (
            <button
              type="button"
              className="lightbox-nav prev"
              aria-label="Foto anterior"
              onClick={(e) => {
                e.stopPropagation();
                setLightbox((lb) => (lb ? { ...lb, index: (lb.index - 1 + lb.urls.length) % lb.urls.length } : lb));
              }}
            >
              <i className="ri-arrow-left-s-line" aria-hidden="true" />
            </button>
          )}
          <img
            src={lightbox.urls[lightbox.index]}
            alt={`${lightbox.title} — foto ${lightbox.index + 1}`}
            onClick={(e) => e.stopPropagation()}
          />
          {lightbox.urls.length > 1 && (
            <button
              type="button"
              className="lightbox-nav next"
              aria-label="Próxima foto"
              onClick={(e) => {
                e.stopPropagation();
                setLightbox((lb) => (lb ? { ...lb, index: (lb.index + 1) % lb.urls.length } : lb));
              }}
            >
              <i className="ri-arrow-right-s-line" aria-hidden="true" />
            </button>
          )}
          <span className="lightbox-cap">
            {lightbox.title} · foto {lightbox.index + 1} de {lightbox.urls.length}
          </span>
        </div>
      )}
    </section>
  );
}