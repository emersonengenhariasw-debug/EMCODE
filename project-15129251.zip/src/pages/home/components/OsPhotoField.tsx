import { useRef, useState } from "react";
import type { ChangeEvent } from "react";
import type { OsPhotoDraft } from "@/lib/osTypes";
import OsCameraCapture from "@/pages/home/components/OsCameraCapture";

const MAX_PHOTOS = 5;

interface Props {
  fotos: OsPhotoDraft[];
  required: boolean;
  onAdd: (files: File[]) => void;
  onRemove: (id: string) => void;
  onZoom: (index: number) => void;
  /** Baixa uma cópia da foto com a data e a hora carimbadas no rodapé. */
  onDownload: (index: number) => void;
}

/* Aparelhos de toque (celular/tablet) abrem a câmera direto pelo <input capture>;
   nos demais, usamos a interface de captura com getUserMedia como alternativa. */
function prefersNativeCapture(): boolean {
  if (typeof window === "undefined") return false;
  const coarse = window.matchMedia?.("(pointer: coarse)").matches ?? false;
  const touch = (navigator.maxTouchPoints ?? 0) > 0;
  return coarse || touch;
}

/**
 * Registro Fotográfico da OS — abaixo da ilustração do caminhão.
 * Permite tirar foto pela câmera ou anexar da galeria, visualizar,
 * ampliar e remover. Até 5 imagens por OS (JPG, JPEG, PNG).
 */
export default function OsPhotoField({ fotos, required, onAdd, onRemove, onZoom, onDownload }: Props) {
  const camRef = useRef<HTMLInputElement>(null);
  const galRef = useRef<HTMLInputElement>(null);
  const [cameraOpen, setCameraOpen] = useState(false);
  const full = fotos.length >= MAX_PHOTOS;

  const handle = (e: ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (list && list.length) onAdd(Array.from(list));
    e.target.value = "";
  };

  /* Abre a câmera: direto pelo input capture no celular/tablet;
     senão pela interface getUserMedia; e por último no input capture. */
  const openCamera = () => {
    if (prefersNativeCapture() && camRef.current) {
      camRef.current.click();
      return;
    }
    if (navigator.mediaDevices?.getUserMedia) {
      setCameraOpen(true);
      return;
    }
    camRef.current?.click();
  };

  return (
    <div className="lost-photo-block os-photo-block">
      <div className="os-block-label lost-photo-title">
        Registro Fotográfico{required ? <b className="lost-req"> *</b> : null}
      </div>

      <div className="lost-photo-actions">
        <button
          type="button"
          className="btn btn-solid btn-sm"
          onClick={openCamera}
          disabled={full}
        >
          <i className="ri-camera-line" aria-hidden="true" /> Tirar foto
        </button>
        <button
          type="button"
          className="btn btn-ghost btn-sm"
          onClick={() => galRef.current?.click()}
          disabled={full}
        >
          <i className="ri-image-add-line" aria-hidden="true" /> Anexar foto
        </button>
      </div>

      <div className="lost-photo-count">
        {fotos.length}/{MAX_PHOTOS} fotos
      </div>

      <input
        ref={camRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="lost-file-input"
        onChange={handle}
        aria-label="Tirar foto com a câmera"
      />
      <input
        ref={galRef}
        type="file"
        accept="image/jpeg,image/jpg,image/png"
        multiple
        className="lost-file-input"
        onChange={handle}
        aria-label="Anexar fotos da galeria"
      />

      {fotos.length === 0 ? (
        <p className="lost-photo-empty">
          <i className="ri-camera-off-line" aria-hidden="true" />
          {required
            ? "Este tipo de movimentação (perda, acidente ou avaria) exige pelo menos 1 foto para finalizar a OS."
            : "Fotos opcionais nesta movimentação. Você pode anexar até 5 imagens."}
        </p>
      ) : (
        <ul className="lost-photo-grid">
          {fotos.map((f, i) => (
            <li key={f.id} className="lost-photo">
              <button
                type="button"
                className="lost-photo-img"
                onClick={() => onZoom(i)}
                aria-label={`Ampliar foto ${i + 1}`}
              >
                {f.previewUrl ? (
                  <img src={f.previewUrl} alt={`Foto ${i + 1} da OS`} />
                ) : (
                  <i className="ri-image-line" aria-hidden="true" />
                )}
              </button>
              <button
                type="button"
                className="lost-photo-download"
                onClick={() => onDownload(i)}
                aria-label={`Baixar foto ${i + 1} com data e hora`}
                title="Baixar cópia com data e hora"
              >
                <i className="ri-download-2-line" aria-hidden="true" />
              </button>
              <button
                type="button"
                className="lost-photo-remove"
                onClick={() => onRemove(f.id)}
                aria-label={`Remover foto ${i + 1}`}
              >
                <i className="ri-close-line" aria-hidden="true" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {fotos.length > 0 && (
        <p className="lost-photo-hint">
          <i className="ri-information-line" aria-hidden="true" />
          Toque na foto para ampliar. Use <i className="ri-download-2-line" aria-hidden="true" /> para
          baixar uma cópia com a data e a hora no rodapé — a foto original é mantida.
        </p>
      )}

      <OsCameraCapture
        open={cameraOpen}
        onClose={() => setCameraOpen(false)}
        onCapture={(file) => onAdd([file])}
      />
    </div>
  );
}