import { useMemo, useState } from "react";
import type { SavedOs } from "@/lib/osTypes";
import { buildMotiveSummary, filterByPeriod } from "@/lib/osSummary";

interface Props {
  orders: SavedOs[];
}

export default function OsSummary({ orders }: Props) {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const finalized = useMemo(() => orders.filter((o) => o.finalized), [orders]);
  const inRange = useMemo(() => filterByPeriod(finalized, from, to), [finalized, from, to]);
  const summary = useMemo(() => buildMotiveSummary(inRange), [inRange]);

  const max = summary.items[0]?.count ?? 1;
  const hasFilter = Boolean(from || to);

  return (
    <section className="summary" id="os-resumo" aria-label="Resumo das OS finalizadas">
      <div className="summary-head">
        <div>
          <span className="summary-kicker">
            <i className="ri-bar-chart-2-line" aria-hidden="true" /> Painel de manutenção
          </span>
          <h2 className="summary-title">Resumo das OS finalizadas</h2>
          <p className="summary-sub">
            Totais por motivo somando as marcações de MOTIVO(S)/CAUSA(S) e o motivo lançado em
            cada pneu retirado.
          </p>
        </div>

        <div className="summary-filter">
          <label className="summary-date">
            <span>De</span>
            <input type="date" value={from} max={to || undefined} onChange={(e) => setFrom(e.target.value)} />
          </label>
          <label className="summary-date">
            <span>Até</span>
            <input type="date" value={to} min={from || undefined} onChange={(e) => setTo(e.target.value)} />
          </label>
          {hasFilter && (
            <button
              type="button"
              className="summary-clear"
              onClick={() => {
                setFrom("");
                setTo("");
              }}
            >
              <i className="ri-close-line" aria-hidden="true" /> Limpar
            </button>
          )}
        </div>
      </div>

      <div className="summary-stats">
        <div className="summary-stat">
          <b>{summary.osCount}</b>
          <span>{summary.osCount === 1 ? "OS finalizada" : "OS finalizadas"}{hasFilter ? " no período" : ""}</span>
        </div>
        <div className="summary-stat">
          <b>{summary.total}</b>
          <span>Apontamentos de motivo</span>
        </div>
        <div className="summary-stat">
          <b>{summary.tires}</b>
          <span>Pneus retirados c/ motivo</span>
        </div>
        <div className="summary-stat">
          <b>{summary.items.length}</b>
          <span>{summary.items.length === 1 ? "Motivo distinto" : "Motivos distintos"}</span>
        </div>
      </div>

      {finalized.length === 0 ? (
        <p className="summary-empty">
          <i className="ri-information-line" aria-hidden="true" /> Nenhuma OS finalizada neste tablet
          ainda. Finalize um serviço para os totais aparecerem aqui.
        </p>
      ) : summary.items.length === 0 ? (
        <p className="summary-empty">
          <i className="ri-information-line" aria-hidden="true" /> As OS finalizadas não têm motivos
          apontados{hasFilter ? " dentro do período selecionado" : ""}.
        </p>
      ) : (
        <ul className="summary-list">
          {summary.items.map((it, i) => {
            const pct = Math.max(6, Math.round((it.count / max) * 100));
            return (
              <li key={it.key} className="summary-row">
                <span className="summary-rank">{i + 1}</span>
                <div className="summary-rowmain">
                  <div className="summary-rowtop">
                    <span className="summary-label">
                      {it.code && <b className="summary-code">{it.code}</b>}
                      {it.short}
                    </span>
                    <span className="summary-count">
                      {it.count}
                      <em>{it.count === 1 ? "ocorrência" : "ocorrências"}</em>
                    </span>
                  </div>
                  <div className="summary-track">
                    <span className="summary-bar" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <p className="summary-foot">
        Contagem por tablets · OS finalizadas. Os totais consideram as duas fontes de motivo
        (marcações e pneu retirado) para refletir o que foi lançado na ficha.
      </p>
    </section>
  );
}