import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { listOs } from "@/lib/osDb";
import { listLostTires } from "@/lib/lostTiresDb";
import type { SavedOs } from "@/lib/osTypes";
import type { LostTireRecord } from "@/lib/lostTiresTypes";
import { OS_TURNO_OPTIONS } from "@/mocks/osForm";
import {
  EMPTY_FILTERS,
  type DashboardFilters,
  type DashboardKpis,
  filterOrders,
  filterLost,
  computeKpis,
  previousRange,
  deltaPct,
  monthlySeries,
  motiveSegments,
  turmaBreakdown,
  distinctValues,
  turmaOptions,
} from "@/lib/osDashboard";
import {
  KpiCard,
  MovementBarChart,
  MotiveDonut,
  TurmaBars,
} from "@/pages/home/components/TireDashboardCharts";

const BG =
  "https://public.readdy.ai/ai/img_res/edited_43eed6d2dc5cd592956eb09bdd1a4b81_5506ebaa.jpg";

const PERIODS = [
  { value: "all", label: "Todo o período" },
  { value: "30d", label: "Últimos 30 dias" },
  { value: "6m", label: "Últimos 6 meses" },
  { value: "year", label: "Este ano" },
];

const isoDay = (d: Date) => d.toISOString().slice(0, 10);

function periodRange(value: string): { from: string; to: string } {
  const today = new Date();
  const to = isoDay(today);
  if (value === "30d") {
    const f = new Date(today);
    f.setDate(f.getDate() - 29);
    return { from: isoDay(f), to };
  }
  if (value === "6m") {
    const f = new Date(today);
    f.setMonth(f.getMonth() - 6);
    return { from: isoDay(f), to };
  }
  if (value === "year") {
    return { from: `${today.getFullYear()}-01-01`, to };
  }
  return { from: "", to: "" };
}

const fmtDay = (iso: string) => {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
};

export default function TireDashboard() {
  const [orders, setOrders] = useState<SavedOs[]>([]);
  const [lost, setLost] = useState<LostTireRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filters, setFilters] = useState<DashboardFilters>(EMPTY_FILTERS);
  const [period, setPeriod] = useState("all");
  const sectionRef = useRef<HTMLElement>(null);

  const load = useCallback(async (initial: boolean) => {
    if (initial) setLoading(true);
    setError("");
    try {
      const [os, lostTires] = await Promise.all([listOs(), listLostTires()]);
      setOrders(os);
      setLost(lostTires);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Falha ao carregar os dados.");
    } finally {
      if (initial) setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(true);
  }, [load]);

  // Recarrega de forma silenciosa sempre que a seção volta a ficar visível,
  // para os indicadores refletirem as OS recém-finalizadas.
  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return undefined;
    let visible = false;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !visible) {
            visible = true;
            load(false);
          } else if (!entry.isIntersecting) {
            visible = false;
          }
        });
      },
      { threshold: 0.2 },
    );
    io.observe(el);
    const onVisible = () => {
      if (document.visibilityState === "visible") load(false);
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      io.disconnect();
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [load]);

  const filteredOrders = useMemo(() => filterOrders(orders, filters), [orders, filters]);
  const filteredLost = useMemo(() => filterLost(lost, filters), [lost, filters]);
  const kpis = useMemo(() => computeKpis(filteredOrders, filteredLost), [filteredOrders, filteredLost]);

  const prevKpis = useMemo(() => {
    const prev = previousRange(filters);
    if (!prev) return null;
    return computeKpis(filterOrders(orders, prev), filterLost(lost, prev));
  }, [orders, lost, filters]);

  const series = useMemo(() => monthlySeries(filteredOrders, 6), [filteredOrders]);
  const donut = useMemo(() => motiveSegments(filteredOrders, 5), [filteredOrders]);
  const turmas = useMemo(() => turmaBreakdown(filteredOrders), [filteredOrders]);

  const equipOptions = useMemo(() => distinctValues(orders, (o) => o.equip), [orders]);
  const operadorOptions = useMemo(() => distinctValues(orders, (o) => o.operador), [orders]);
  const turmaOpts = useMemo(() => turmaOptions(orders), [orders]);
  const turnoOpts = useMemo(() => [...OS_TURNO_OPTIONS], []);

  const delta = (key: keyof DashboardKpis) => (prevKpis ? deltaPct(kpis[key], prevKpis[key]) : null);

  const rangeLabel = useMemo(() => {
    if (filters.from && filters.to) return `${fmtDay(filters.from)} – ${fmtDay(filters.to)}`;
    if (filters.from) return `a partir de ${fmtDay(filters.from)}`;
    if (filters.to) return `até ${fmtDay(filters.to)}`;
    return "Todo o período";
  }, [filters.from, filters.to]);

  const setFilter = (patch: Partial<DashboardFilters>) => setFilters((f) => ({ ...f, ...patch }));

  const applyPeriod = (value: string) => {
    setPeriod(value);
    const r = periodRange(value);
    setFilters((f) => ({ ...f, from: r.from, to: r.to }));
  };

  const onDate = (key: "from" | "to", value: string) => {
    setPeriod("custom");
    setFilters((f) => ({ ...f, [key]: value }));
  };

  const clearFilters = () => {
    setFilters(EMPTY_FILTERS);
    setPeriod("all");
  };

  const activeFilters =
    Boolean(filters.from || filters.to || filters.equip || filters.operador || filters.turma || filters.turno);

  return (
    <section className="tireboard" id="story" ref={sectionRef} aria-label="Dashboard de Controle de Pneus">
      <img
        className="tireboard-bg"
        src={BG}
        alt="Oficina industrial bem iluminada com um operador segurando um tablet ao lado de pneus de caminhão"
        data-parallax="0.18"
      />
      <div className="tireboard-veil" aria-hidden="true" />

      <div className="tireboard-inner">
        <div className="tireboard-copy">
          <p className="stamp" data-reveal>
            02 — Controle e gestão
          </p>
          <h2 data-reveal>
            Dashboard de
            <br />
            Controle de <em className="accent">Pneus</em>
          </h2>
          <p className="tireboard-sub" data-reveal>
            Acompanhamento das movimentações
          </p>
          <p className="tireboard-lead" data-reveal>
            Visão completa das movimentações de pneus, com indicadores em tempo real para mais
            controle, segurança e produtividade na operação.
          </p>
          <ul className="tireboard-features" data-reveal>
            <li>
              <span className="tf-ico">
                <i className="ri-bar-chart-box-line" aria-hidden="true" />
              </span>
              <b>Dados em tempo real</b>
            </li>
            <li>
              <span className="tf-ico">
                <i className="ri-shield-check-line" aria-hidden="true" />
              </span>
              <b>Mais controle e segurança</b>
            </li>
            <li>
              <span className="tf-ico">
                <i className="ri-line-chart-line" aria-hidden="true" />
              </span>
              <b>Decisões mais estratégicas</b>
            </li>
          </ul>
        </div>

        <div className="tireboard-panel">
          <div className="dash-head">
            <div className="dash-title">
              <span className="dash-title-ico" aria-hidden="true">
                <i className="ri-bar-chart-box-fill" />
              </span>
              <span className="dash-title-text">
                <h3>Dashboard de Controle de Pneus</h3>
                <span className="dash-title-sub">Acompanhamento das movimentações</span>
              </span>
            </div>

            <div className="dash-head-actions">
              <div className="dash-period">
                <i className="ri-calendar-line" aria-hidden="true" />
                <select
                  value={period}
                  onChange={(e) => applyPeriod(e.target.value)}
                  aria-label="Período do dashboard"
                >
                  {PERIODS.map((p) => (
                    <option key={p.value} value={p.value}>
                      {p.label}
                    </option>
                  ))}
                  <option value="custom">Personalizado</option>
                </select>
                <span className="dash-period-range">{rangeLabel}</span>
              </div>
              <button
                type="button"
                className="dash-refresh"
                onClick={() => load(true)}
                aria-label="Atualizar indicadores"
                title="Atualizar indicadores"
              >
                <i className="ri-refresh-line" aria-hidden="true" />
              </button>
            </div>
          </div>

          {loading ? (
            <div className="dash-state">
              <i className="ri-loader-4-line spin" aria-hidden="true" />
              <span>Carregando indicadores…</span>
            </div>
          ) : error ? (
            <div className="dash-state">
              <i className="ri-error-warning-line" aria-hidden="true" />
              <span>{error}</span>
              <button type="button" className="btn btn-primary btn-sm" onClick={() => load(true)}>
                Tentar novamente
              </button>
            </div>
          ) : (
            <>
              <div className="dash-filters">
                <label className="dash-field">
                  <span>Data de</span>
                  <input type="date" value={filters.from} onChange={(e) => onDate("from", e.target.value)} />
                </label>
                <label className="dash-field">
                  <span>Data até</span>
                  <input type="date" value={filters.to} onChange={(e) => onDate("to", e.target.value)} />
                </label>
                <label className="dash-field">
                  <span>Equipamento</span>
                  <select value={filters.equip} onChange={(e) => setFilter({ equip: e.target.value })}>
                    <option value="">Todos</option>
                    {equipOptions.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="dash-field">
                  <span>Operador</span>
                  <select value={filters.operador} onChange={(e) => setFilter({ operador: e.target.value })}>
                    <option value="">Todos</option>
                    {operadorOptions.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="dash-field">
                  <span>Turma/Letra</span>
                  <select value={filters.turma} onChange={(e) => setFilter({ turma: e.target.value })}>
                    <option value="">Todas</option>
                    {turmaOpts.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="dash-field">
                  <span>Horário/Turno</span>
                  <select value={filters.turno} onChange={(e) => setFilter({ turno: e.target.value })}>
                    <option value="">Todos</option>
                    {turnoOpts.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </label>
                {activeFilters && (
                  <button type="button" className="dash-clear" onClick={clearFilters}>
                    <i className="ri-close-circle-line" aria-hidden="true" /> Limpar filtros
                  </button>
                )}
              </div>

              <div className="dash-kpis">
                <KpiCard label="OS finalizadas" value={kpis.osFinalizadas} icon="ri-file-list-3-line" tone="green" delta={delta("osFinalizadas")} />
                <KpiCard label="Pneus retirados" value={kpis.pneusRetirados} icon="ri-tape-line" tone="gold" delta={delta("pneusRetirados")} />
                <KpiCard label="Pneus instalados" value={kpis.pneusInstalados} icon="ri-settings-3-line" tone="green" delta={delta("pneusInstalados")} />
                <KpiCard label="Pneus perdidos" value={kpis.pneusPerdidos} icon="ri-alert-line" tone="gold" delta={delta("pneusPerdidos")} />
              </div>

              <div className="dash-card dash-card-chart">
                <div className="dash-card-head">
                  <span className="dash-card-title">
                    <i className="ri-bar-chart-2-line" aria-hidden="true" /> Movimentações por mês
                  </span>
                  <span className="dash-legend">
                    <span>
                      <i className="dash-dot is-green" aria-hidden="true" /> Retirados
                    </span>
                    <span>
                      <i className="dash-dot is-gold" aria-hidden="true" /> Instalados
                    </span>
                  </span>
                </div>
                <MovementBarChart series={series} />
              </div>

              <div className="dash-bottom">
                <div className="dash-card">
                  <div className="dash-card-head">
                    <span className="dash-card-title">
                      <i className="ri-pie-chart-2-line" aria-hidden="true" /> Motivos mais frequentes
                    </span>
                  </div>
                  <MotiveDonut segments={donut.segments} total={donut.total} />
                </div>

                <div className="dash-card">
                  <div className="dash-card-head">
                    <span className="dash-card-title">
                      <i className="ri-group-line" aria-hidden="true" /> Movimentações por turma/letra
                    </span>
                  </div>
                  <TurmaBars rows={turmas} />
                </div>
              </div>

              <p className="dash-foot">
                {filteredOrders.length} de {orders.length} OS consideradas
                {lost.length > 0 ? ` · ${filteredLost.length} de ${lost.length} pneus perdidos` : ""}
              </p>
            </>
          )}
        </div>
      </div>
    </section>
  );
}