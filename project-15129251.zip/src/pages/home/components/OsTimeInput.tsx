interface Props {
  id?: string;
  value: string;
  onChange: (v: string) => void;
  label?: string;
}

/* Aceita apenas HH:MM (24h). Durante a digitação aplica a máscara;
   ao sair do campo, descarta valores inválidos como 99:99. */
function maskTyping(raw: string): string {
  const digits = raw.replace(/\D/g, "").slice(0, 4);
  if (digits.length <= 2) return digits;
  return `${digits.slice(0, 2)}:${digits.slice(2)}`;
}

/* Só devolve um horário quando ele é realmente válido (00:00–23:59). */
function validTime(v: string): string {
  const m = /^(\d{2}):(\d{2})$/.exec(v);
  if (!m) return "";
  const hh = Number(m[1]);
  const mm = Number(m[2]);
  if (hh > 23 || mm > 59) return "";
  return `${m[1]}:${m[2]}`;
}

export default function OsTimeInput({ id, value, onChange, label }: Props) {
  const openPicker = () => {
    const el = document.getElementById(`${id}-native`) as
      | (HTMLInputElement & { showPicker?: () => void })
      | null;
    if (!el) return;
    try {
      if (typeof el.showPicker === "function") {
        el.showPicker();
        return;
      }
    } catch {
      /* se o navegador não permitir, cai no fallback abaixo */
    }
    el.focus();
    el.click();
  };

  return (
    <span className="os-time">
      <input
        id={id}
        className="os-input os-time-text"
        type="text"
        inputMode="numeric"
        autoComplete="off"
        maxLength={5}
        placeholder="HH:MM"
        value={value}
        aria-label={label}
        onChange={(e) => onChange(maskTyping(e.target.value))}
        onBlur={(e) => onChange(validTime(maskTyping(e.target.value)))}
      />
      <button
        type="button"
        className="os-time-btn"
        onClick={openPicker}
        tabIndex={-1}
        aria-label={label ? `Abrir relógio: ${label}` : "Abrir relógio"}
      >
        <i className="ri-time-line" aria-hidden="true" />
      </button>
      <input
        id={id ? `${id}-native` : undefined}
        className="os-time-native"
        type="time"
        tabIndex={-1}
        aria-hidden="true"
        value={validTime(value)}
        onChange={(e) => onChange(validTime(e.target.value))}
      />
    </span>
  );
}