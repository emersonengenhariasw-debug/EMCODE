import { useEffect, useMemo, useRef, useState, type ChangeEvent } from "react";
import type { FieldChange, ImportDecision, ImportResult } from "@/lib/osSync";

interface Props {
  open: boolean;
  loading: boolean;
  applying: boolean;
  result: ImportResult | null;
  error: string | null;
  /** Lê o arquivo Excel escolhido pelo usuário. */
  onPickFile: (file: File) => void;
  /** Aplica as decisões revisadas. */
  onApply: (decisions: ImportDecision[]) => void;
  onClose: () => void;
}

/* Agrupa as mudanças por OS para exibir em blocos. */
function groupByOs(changes: FieldChange[]): { osNumero: string; items: FieldChange[] }[] {
  const map = new Map<string, FieldChange[]>();
  changes.forEach((c) => {
    const arr = map.get(c.osNumero) ?? [];
    arr.push(c);
    map.set(c.osNumero, arr);
  });
  return Array.from(map.entries()).map(([osNumero, items]) => ({ osNumero, items }));
}

export default function OsImport({
  open,
  loading,
  applying,
  result,
  error,
  onPickFile,
  onApply,
  onClose,
}: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [decisions, setDecisions] = useState<Record<string, boolean>>({});

  // Ao chegar um novo resultado, pré-marca: conflitos mantêm o sistema (false),
  // mudanças simples já vêm marcadas para aplicar (true).
  useEffect(() => {
    if (!result) {
      setDecisions({});
      return;
    }
    const init: Record<string, boolean> = {};
    result.changes.forEach((c) => {
      init[c.key] = !c.conflict;
    });
    setDecisions(init);
  }, [result]);

  const grouped = useMemo(() => (result ? groupByOs(result.changes) : []), [result]);
  const conflicts = useMemo(
    () => (result ? result.changes.filter((c) => c.conflict) : []),
    [result],
  );

  if (!open) return null;

  const handlePick = () => inputRef.current?.click();
  const handleFile = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) onPickFile(file);
    e.target.value = "";
  };

  const handleApply = () => {
    if (!result) return;
    const list: ImportDecision[] = result.changes
      .filter((c) => c.conflict || decisions[c.key])
      .map((c) => ({ change: c, useExcel: Boolean(decisions[c.key]) }));
    onApply(list);
  };

  return (
    <div className="modal-veil" role="dialog" aria-modal="true" aria-label="Importar Excel">
      <div className="os-import">
        <div className="os-import-head">
          <div>
            <span className="summary-kicker">
              <i className="ri-refresh-line" aria-hidden="true" /> Sincronização
            </span>
            <h3 className="os-import-title">Importar planilha editada</h3>
            <p className="os-import-sub">
              Baixe a planilha, edite onde preferir e reimporte aqui. O sistema identifica cada pneu
              pelo identificador único, mostra o que mudou e nunca altera a OS errada.
            </p>
          </div>
          <button type="button" className="camera-close" onClick={onClose} aria-label="Fechar">
            <i className="ri-close-line" aria-hidden="true" />
          </button>
        </div>

        <input
          ref={inputRef}
          type="file"
          accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
          className="os-import-file"
          onChange={handleFile}
        />

        {loading && (
          <p className="os-import-note">
            <i className="ri-loader-4-line spin" aria-hidden="true" /> Lendo a planilha…
          </p>
        )}

        {error && (
          <p className="os-import-error">
            <i className="ri-error-warning-line" aria-hidden="true" /> {error}
          </p>
        )}

        {!result && !loading && (
          <div className="os-import-empty">
            <p>
              Selecione a planilha <b>CONTROLE_DE_PNEUS_JULY_QUARTZO.xlsx</b> (modelo
              profissional) ou a <b>CONTROLE_GERAL_DE_PNEUS_JULY_QUARTZO.xlsx</b> já editada. As
              alterações aparecerão para revisão antes de qualquer coisa ser gravada.
            </p>
            <button type="button" className="btn btn-primary" onClick={handlePick}>
              <i className="ri-file-excel-2-line" aria-hidden="true" /> Escolher planilha
            </button>
          </div>
        )}

        {result && (
          <>
            <div className="os-import-stats">
              <span className="os-import-stat">
                <b>{result.rowsRead}</b>
                <span>linhas lidas</span>
              </span>
              <span className="os-import-stat">
                <b>{result.changes.length - conflicts.length}</b>
                <span>mudanças</span>
              </span>
              <span className="os-import-stat">
                <b className={conflicts.length ? "is-conflict" : undefined}>{conflicts.length}</b>
                <span>conflitos</span>
              </span>
              <span className="os-import-file-name">{result.fileName}</span>
            </div>

            {result.notFound.length > 0 && (
              <p className="os-import-warn">
                <i className="ri-alert-line" aria-hidden="true" /> {result.notFound.length} OS da
                planilha não existem no sistema e foram ignoradas (nada foi criado):{" "}
                {result.notFound.join(", ")}.
              </p>
            )}

            {result.changes.length === 0 ? (
              <p className="os-import-note">
                <i className="ri-check-double-line" aria-hidden="true" /> Nenhuma mudança encontrada —
                o sistema e a planilha já estão iguais.
              </p>
            ) : (
              <div className="os-import-list">
                {grouped.map((g) => (
                  <div key={g.osNumero} className="os-import-group">
                    <span className="os-import-group-title">
                      <i className="ri-file-list-3-line" aria-hidden="true" /> OS {g.osNumero}
                    </span>
                    {g.items.map((c) => (
                      <div
                        key={c.key}
                        className={`os-import-row${c.conflict ? " is-conflict" : ""}`}
                      >
                        <div className="os-import-row-info">
                          <span className="os-import-row-label">{c.label}</span>
                          <span className="os-import-row-pneu">pneu {c.pneuId}</span>
                        </div>
                        <div className="os-import-values">
                          <span className="os-import-value">
                            <em>Sistema</em>
                            <b>{c.db || "—"}</b>
                          </span>
                          <i className="ri-arrow-right-line" aria-hidden="true" />
                          <span className="os-import-value is-xls">
                            <em>Excel</em>
                            <b>{c.xls || "—"}</b>
                          </span>
                        </div>
                        {c.conflict ? (
                          <div className="os-import-choice" role="radiogroup" aria-label="Escolha o valor">
                            <label>
                              <input
                                type="radio"
                                name={c.key}
                                checked={!decisions[c.key]}
                                onChange={() => setDecisions((d) => ({ ...d, [c.key]: false }))}
                              />
                              Manter sistema
                            </label>
                            <label>
                              <input
                                type="radio"
                                name={c.key}
                                checked={Boolean(decisions[c.key])}
                                onChange={() => setDecisions((d) => ({ ...d, [c.key]: true }))}
                              />
                              Usar Excel
                            </label>
                          </div>
                        ) : (
                          <label className="os-import-apply">
                            <input
                              type="checkbox"
                              checked={Boolean(decisions[c.key])}
                              onChange={(e) =>
                                setDecisions((d) => ({ ...d, [c.key]: e.target.checked }))
                              }
                            />
                            Aplicar
                          </label>
                        )}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}

            <div className="os-import-actions">
              <button type="button" className="btn btn-ghost" onClick={handlePick} disabled={applying}>
                <i className="ri-upload-2-line" aria-hidden="true" /> Trocar arquivo
              </button>
              <button type="button" className="btn btn-ghost" onClick={onClose} disabled={applying}>
                Cancelar
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={handleApply}
                disabled={applying || !result.changes.length}
              >
                {applying ? (
                  <>
                    <i className="ri-loader-4-line spin" aria-hidden="true" /> Aplicando…
                  </>
                ) : (
                  <>
                    <i className="ri-check-double-line" aria-hidden="true" /> Aplicar sincronização
                  </>
                )}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}