import type { OsFormData } from "@/lib/osTypes";
import { OS_TURNO_OPTIONS, OS_TURMA_OPTIONS } from "@/mocks/osForm";
import OsTimeInput from "@/pages/home/components/OsTimeInput";

interface Props {
  form: OsFormData;
  patch: (p: Partial<OsFormData>) => void;
}

export default function OsHeaderFields({ form, patch }: Props) {
  return (
    <>
      <header className="os-head">
        <div className="os-brand">
          <b>JULY QUARTZO</b>
          <span>Mineração e Construção</span>
        </div>
        <div className="os-title">OS - MOVIMENTAÇÃO DE PNEU</div>
        <div className="os-num">
          <label htmlFor="os-numero">Nº</label>
          <input
            id="os-numero"
            className="os-input os-num-input"
            inputMode="numeric"
            placeholder="0000"
            value={form.numero}
            onChange={(e) => patch({ numero: e.target.value })}
          />
        </div>
      </header>

      {/* Primeira linha — operação */}
      <div className="os-row r1">
        <div className="os-field">
          <label className="os-label" htmlFor="os-turno">Horário/Turno</label>
          <select
            id="os-turno"
            className="os-select"
            value={form.turno}
            onChange={(e) => patch({ turno: e.target.value })}
          >
            <option value="">Selecionar…</option>
            {OS_TURNO_OPTIONS.map((o) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
        </div>
        <div className="os-field">
          <label className="os-label" htmlFor="os-inicio">Início</label>
          <OsTimeInput
            id="os-inicio"
            label="Início"
            value={form.inicio}
            onChange={(v) => patch({ inicio: v })}
          />
        </div>
        <div className="os-field">
          <label className="os-label" htmlFor="os-termino">Término</label>
          <OsTimeInput
            id="os-termino"
            label="Término"
            value={form.termino}
            onChange={(v) => patch({ termino: v })}
          />
        </div>
        <div className="os-field">
          <label className="os-label" htmlFor="os-horimetro">Horímetro</label>
          <input
            id="os-horimetro"
            type="number"
            inputMode="numeric"
            className="os-input"
            placeholder="0"
            value={form.horimetro}
            onChange={(e) => patch({ horimetro: e.target.value })}
          />
        </div>
      </div>

      {/* Linha das datas — apenas Data de Entrada e Data de Saída (independentes) */}
      <div className="os-row r-dates">
        <div className="os-field">
          <label className="os-label" htmlFor="os-data-entrada">Data de Entrada</label>
          <input
            id="os-data-entrada"
            type="date"
            className="os-input"
            value={form.dataEntrada}
            onChange={(e) => patch({ dataEntrada: e.target.value })}
          />
        </div>
        <div className="os-field">
          <label className="os-label" htmlFor="os-data-saida">Data de Saída</label>
          <input
            id="os-data-saida"
            type="date"
            className="os-input"
            value={form.dataSaida}
            onChange={(e) => patch({ dataSaida: e.target.value })}
          />
        </div>
      </div>

      {/* Segunda linha */}
      <div className="os-row r2">
        <div className="os-field">
          <label className="os-label" htmlFor="os-operador">Operador/Condutor</label>
          <input
            id="os-operador"
            className="os-input"
            placeholder="Nome do operador"
            value={form.operador}
            onChange={(e) => patch({ operador: e.target.value })}
          />
        </div>
        <div className="os-field">
          <label className="os-label" htmlFor="os-km">KM</label>
          <input
            id="os-km"
            type="number"
            inputMode="numeric"
            className="os-input"
            placeholder="0"
            value={form.km}
            onChange={(e) => patch({ km: e.target.value })}
          />
        </div>
        <div className="os-field">
          <label className="os-label" htmlFor="os-equip">Equip</label>
          <input
            id="os-equip"
            className="os-input"
            placeholder="Equipamento"
            value={form.equip}
            onChange={(e) => patch({ equip: e.target.value })}
          />
        </div>
      </div>

      {/* Terceira linha */}
      <div className="os-row r3">
        <div className="os-field">
          <label className="os-label" htmlFor="os-exec">Executante(s)</label>
          <input
            id="os-exec"
            className="os-input"
            placeholder="Quem executou o serviço"
            value={form.executantes}
            onChange={(e) => patch({ executantes: e.target.value })}
          />
        </div>
        <div className="os-field">
          <label className="os-label" htmlFor="os-local">Local da Ocorrência</label>
          <input
            id="os-local"
            className="os-input"
            placeholder="Local da ocorrência"
            value={form.local}
            onChange={(e) => patch({ local: e.target.value })}
          />
        </div>
        <div className="os-field">
          <label className="os-label" htmlFor="os-turma">Turma/Letra</label>
          <select
            id="os-turma"
            className="os-select"
            value={form.turma}
            onChange={(e) => patch({ turma: e.target.value })}
          >
            <option value="">Selecionar…</option>
            {OS_TURMA_OPTIONS.map((o) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
        </div>
      </div>
    </>
  );
}