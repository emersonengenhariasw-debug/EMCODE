import { OS_MOTIVES } from "@/mocks/osForm";

interface Props {
  selected: string[];
  onToggle: (motive: string) => void;
}

export default function OsMotives({ selected, onToggle }: Props) {
  return (
    <div className="os-motives-block">
      <div className="os-block-label">Motivo (s) / Causa (s):</div>
      <div className="os-motives">
        {OS_MOTIVES.map((column, ci) => (
          <div key={`col-${ci}`} className="flex flex-col gap-1">
            {column.map((label) => (
              <label key={label} className="os-motive">
                <input
                  type="checkbox"
                  name="motivo"
                  value={label}
                  checked={selected.includes(label)}
                  onChange={() => onToggle(label)}
                />
                <span>{label}</span>
              </label>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}