const TRUCK_IMG =
  "https://static.readdy.ai/image/609965e270ebc56f2a8bcb8a9ed920d6/1217b9e46cfc3788ddbccebb35146bb5.png";

/**
 * Equipment seen from above with the ten tire positions numbered 1–10.
 * The drawing is the supplied artwork, kept as-is and scaled proportionally
 * inside its area (object-contain) so nothing is cropped or distorted.
 */
export default function TruckDiagram() {
  return (
    <figure className="truck-figure">
      <img
        src={TRUCK_IMG}
        alt="Desenho do caminhão visto de cima com dez posições de pneu numeradas de 1 a 10."
        title="Posições dos pneus do equipamento — 1 a 10"
        className="truck-img"
      />
    </figure>
  );
}