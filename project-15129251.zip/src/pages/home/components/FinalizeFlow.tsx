import { useEffect, useMemo, useState } from "react";
import type { SavedOs } from "@/lib/osTypes";
import { formatOsDateTime } from "@/lib/osDate";

interface Props {
  filled: boolean;
  finalized: boolean;
  savedFlag: boolean;
  savedList: SavedOs[];
  openingId?: string | null;
  /** Data e hora do registro da OS que está na tela (para exibir "Registrado em"). */
  savedAt?: string | null;
  /** Abre a OS pelo seu identificador único (Nº da OS). */
  onLoad: (id: string) => void;
  onDelete: (id: string) => void;
  onExcel: () => void;
  /** Abre a sincronização: importa uma planilha editada de volta ao sistema. */
  onImport: () => void;
  importing?: boolean;
  onPrint: () => void;
  onSample: () => void;
}

/* Quantas OS salvas aparecem por vez na faixa de botões. */
const SAVED_PAGE_SIZE = 5;

export default function FinalizeFlow({
  filled,
  finalized,
  savedFlag,
  savedList,
  openingId,
  savedAt,
  onLoad,
  onDelete,
  onExcel,
  onImport,
  importing,
  onPrint,
  onSample,
}: Props) {
  const [page, setPage] = useState(0);
  const [dir, setDir] = useState<"from-right" | "from-left">("from-right");

  // Sempre os mais recentes primeiro (pela data de salvamento).
  const sortedList = useMemo(
    () => [...savedList].sort((a, b) => (b.savedAt || "").localeCompare(a.savedAt || "")),
    [savedList],
  );

  const totalPages = Math.max(1, Math.ceil(sortedList.length / SAVED_PAGE_SIZE));
  // Mantém a página válida mesmo quando uma OS é excluída.
  const safePage = Math.min(page, totalPages - 1);
  const pageItems = sortedList.slice(
    safePage * SAVED_PAGE_SIZE,
    safePage * SAVED_PAGE_SIZE + SAVED_PAGE_SIZE,
  );
  const canPrev = safePage > 0;
  const canNext = safePage < totalPages - 1;

  useEffect(() => {
    setPage((p) => Math.min(p, Math.max(0, totalPages - 1)));
  }, [totalPages]);

  const goPrev = () => {
    if (!canPrev) return;
    setDir("from-left");
    setPage((p) => Math.max(0, p - 1));
  };
  const goNext = () => {
    if (!canNext) return;
    setDir("from-right");
    setPage((p) => Math.min(totalPages - 1, p + 1));
  };

  return (
    <div className="finish">
      <div className="finish-panel">
      <div className="finish-flow" aria-label="Fluxo da ordem de serviço">
        <span className={`flow-step${filled ? " done" : ""}`}>
          <i className="ri-edit-2-line" aria-hidden="true" /> Preencher OS
        </span>
        <i className="ri-arrow-right-line flow-arrow" aria-hidden="true" />
        <span className={`flow-step${finalized ? " done" : ""}`}>
          <i className="ri-check-double-line" aria-hidden="true" /> Finalizar
        </span>
        <i className="ri-arrow-right-line flow-arrow" aria-hidden="true" />
        <span className={`flow-step${savedFlag ? " done" : ""}`}>
          <i className="ri-save-3-line" aria-hidden="true" /> Salvar dados
        </span>
      </div>

      <div className="finish-actions">
        <button type="button" className="btn btn-ghost" onClick={onExcel}>
          <i className="ri-file-excel-2-line" aria-hidden="true" /> Excel
        </button>
        <button type="button" className="btn btn-ghost" onClick={onImport} disabled={importing}>
          <i className="ri-refresh-line" aria-hidden="true" /> Importar Excel
        </button>
        <button type="button" className="btn btn-ghost" onClick={onPrint}>
          <i className="ri-printer-line" aria-hidden="true" /> Imprimir
        </button>
      </div>

      {savedAt && (
        <p className="finish-saved">
          <i className="ri-time-line" aria-hidden="true" /> Registrado em{" "}
          <b>{formatOsDateTime(savedAt)}</b>
        </p>
      )}

      </div>

      {savedList.length === 0 && (
        <div className="os-sample-hint" aria-label="Testar a planilha">
          <span className="os-sample-text">
            <i className="ri-flask-line text-accent-500" aria-hidden="true" />
            Quer conferir como a planilha sai? Carregue uma OS já preenchida e clique em Excel.
          </span>
          <button type="button" className="btn btn-ghost btn-sm" onClick={onSample}>
            <i className="ri-file-add-line" aria-hidden="true" /> OS de exemplo
          </button>
        </div>
      )}

      {savedList.length > 0 && (
        <div className="os-saved-pager" aria-label="Ordens salvas neste dispositivo">
          <div className="os-saved-head">
            <span className="font-label text-[10px] uppercase tracking-[.14em] text-foreground-700">
              Ordens salvas
            </span>
            <span className="os-saved-count">
              {sortedList.length} {sortedList.length === 1 ? "OS" : "OS"} · página {safePage + 1} de {totalPages}
            </span>
          </div>

          <div className="os-saved-nav">
            <button
              type="button"
              className="os-saved-arrow"
              onClick={goPrev}
              disabled={!canPrev}
              aria-label="Ver OS mais recentes"
              title="OS mais recentes"
            >
              <i className="ri-arrow-left-s-line" aria-hidden="true" />
            </button>

            <div className="os-saved-viewport">
              <div key={safePage} className={`os-saved-list os-saved-anim ${dir}`}>
                {pageItems.map((r) => (
                  <span key={r.id} className="os-saved-chip">
                    <i className="ri-file-list-3-line text-primary-700" aria-hidden="true" />
                    <b className="font-semibold">OS {r.numero || "s/n"}</b>
                    <span className="text-foreground-600">{r.dataEntrada || r.dataSaida || "—"}</span>
                    <button
                      type="button"
                      disabled={openingId === r.id}
                      onClick={() => onLoad(r.id)}
                    >
                      {openingId === r.id ? "Abrindo…" : "Abrir"}
                    </button>
                    <button type="button" onClick={() => onDelete(r.id)}>Excluir</button>
                  </span>
                ))}
              </div>
            </div>

            <button
              type="button"
              className="os-saved-arrow"
              onClick={goNext}
              disabled={!canNext}
              aria-label="Ver OS mais antigas"
              title="OS mais antigas"
            >
              <i className="ri-arrow-right-s-line" aria-hidden="true" />
            </button>
          </div>

          {totalPages > 1 && (
            <div className="os-saved-dots" aria-hidden="true">
              {Array.from({ length: totalPages }).map((_, i) => (
                <span key={i} className={`os-saved-dot${i === safePage ? " is-on" : ""}`} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}