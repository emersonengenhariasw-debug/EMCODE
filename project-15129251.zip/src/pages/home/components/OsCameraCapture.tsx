import { useCallback, useEffect, useRef, useState } from "react";

interface Props {
  open: boolean;
  onClose: () => void;
  onCapture: (file: File) => void;
}

/**
 * Interface de captura pela câmera (getUserMedia) usada como alternativa
 * quando o aparelho não abre a câmera direto pelo <input capture>.
 * Usa preferencialmente a câmera traseira e permite confirmar ou repetir.
 */
export default function OsCameraCapture({ open, onClose, onCapture }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [error, setError] = useState("");
  const [shot, setShot] = useState("");
  const [ready, setReady] = useState(false);

  const stopStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setError("");
    setShot("");
    setReady(false);

    const start = async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          throw new Error("unsupported");
        }
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: "environment" } },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => undefined);
        }
        setReady(true);
      } catch {
        if (cancelled) return;
        setError(
          "Não foi possível abrir a câmera. Verifique se o acesso foi permitido no navegador e tente novamente.",
        );
      }
    };

    void start();
    return () => {
      cancelled = true;
      stopStream();
    };
  }, [open, stopStream]);

  const takePhoto = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    const w = video.videoWidth || 1280;
    const h = video.videoHeight || 720;
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, w, h);
    setShot(canvas.toDataURL("image/jpeg", 0.92));
  }, []);

  const confirm = useCallback(async () => {
    if (!shot) return;
    try {
      const res = await fetch(shot);
      const blob = await res.blob();
      const file = new File([blob], `os-foto-${Date.now()}.jpg`, { type: "image/jpeg" });
      onCapture(file);
      stopStream();
      onClose();
    } catch {
      setError("Não foi possível confirmar a foto. Tente novamente.");
    }
  }, [shot, onCapture, onClose, stopStream]);

  const close = useCallback(() => {
    stopStream();
    onClose();
  }, [onClose, stopStream]);

  if (!open) return null;

  return (
    <div className="camera-veil" role="dialog" aria-modal="true" aria-label="Tirar foto do pneu" onClick={close}>
      <div className="camera-card" onClick={(e) => e.stopPropagation()}>
        <div className="camera-head">
          <span className="camera-title">
            <i className="ri-camera-lens-line" aria-hidden="true" /> Tirar foto do pneu
          </span>
          <button type="button" className="camera-close" onClick={close} aria-label="Fechar câmera">
            <i className="ri-close-line" aria-hidden="true" />
          </button>
        </div>

        {error ? (
          <p className="camera-error">
            <i className="ri-error-warning-line" aria-hidden="true" /> {error}
          </p>
        ) : (
          <div className="camera-stage">
            {shot ? (
              <img className="camera-shot" src={shot} alt="Prévia da foto capturada" />
            ) : (
              <video ref={videoRef} className="camera-video" playsInline muted />
            )}
          </div>
        )}

        <div className="camera-actions">
          {shot ? (
            <>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => setShot("")}>
                <i className="ri-refresh-line" aria-hidden="true" /> Repetir
              </button>
              <button type="button" className="btn btn-solid btn-sm" onClick={confirm}>
                <i className="ri-check-line" aria-hidden="true" /> Confirmar
              </button>
            </>
          ) : (
            <button type="button" className="btn btn-solid btn-sm" onClick={takePhoto} disabled={!ready || !!error}>
              <i className="ri-camera-line" aria-hidden="true" /> Capturar
            </button>
          )}
        </div>
      </div>
    </div>
  );
}