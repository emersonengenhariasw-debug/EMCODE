/**
 * Slides de apresentação inicial (Manifesto · O desenho · Resultados).
 * O conteúdo, textos e imagens são exatamente os blocos que já existiam no site —
 * aqui eles apenas ficam dentro do carrossel.
 */

export function ManifestoSlide() {
  return (
    <section className="panel manifesto" id="belief" aria-label="Nosso compromisso">
      <span className="panel-accent panel-numeral" aria-hidden="true" data-parallax="0.55">
        OS
      </span>
      <p className="manifesto-text" data-words>
        Uma oficina sem papel, onde cada pneu tem nome, posição e{" "}
        <em className="accent">história</em> — e nenhuma decisão se perde pelo caminho.
      </p>
    </section>
  );
}

export function DiagramSlide() {
  return (
    <section className="panel" data-side="right" id="diagram" aria-label="O desenho do equipamento">
      <img
        className="panel-bg"
        src="https://readdy.ai/api/search-image?query=Close%20detail%20of%20heavy%20truck%20tires%20in%20a%20row%20on%20a%20mineral%20blue%20workshop%20floor%2C%20cool%20daylight%2C%20crisp%20tread%20pattern%2C%20shallow%20depth%20of%20field%2C%20desaturated%20industrial%20palette%20of%20navy%20grey%20and%20pale%20blue%2C%20editorial%20photography%2C%20soft%20background&width=2400&height=1350&seq=jq-tires-01&orientation=landscape"
        alt="Fileira de pneus de caminhão sobre o piso da oficina"
        data-parallax="0.32"
      />
      <div className="panel-veil" />
      <div className="panel-copy" data-parallax="-0.08">
        <p className="stamp" data-reveal>
          03 — O desenho
        </p>
        <h2 data-reveal>
          Dez posições,
          <br />
          todas <em className="accent">numeradas</em>
        </h2>
        <p className="sub" data-reveal>
          O equipamento aparece de cima, na vertical, com os dez pneus visíveis e numerados de 1
          a 10 — do eixo dianteiro às duas fileiras traseiras.
        </p>
        <div className="flex flex-wrap gap-2.5" data-reveal>
          <span className="inline-flex items-center gap-2 rounded-full bg-secondary-100 border border-secondary-300 px-3.5 py-1.5 text-[13px] text-primary-700">
            <i className="ri-roadster-line" aria-hidden="true" /> 1 — 2 dianteiro
          </span>
          <span className="inline-flex items-center gap-2 rounded-full bg-secondary-100 border border-secondary-300 px-3.5 py-1.5 text-[13px] text-primary-700">
            <i className="ri-layout-2-line" aria-hidden="true" /> 3 — 6 primeira fileira
          </span>
          <span className="inline-flex items-center gap-2 rounded-full bg-secondary-100 border border-secondary-300 px-3.5 py-1.5 text-[13px] text-primary-700">
            <i className="ri-layout-3-line" aria-hidden="true" /> 7 — 10 segunda fileira
          </span>
        </div>
      </div>
    </section>
  );
}

export function ProofSlide() {
  return (
    <section className="panel" data-side="left" id="proof" aria-label="Resultados">
      <img
        className="panel-bg"
        src="https://readdy.ai/api/search-image?query=Cool%20blue%20twilight%20exterior%20of%20a%20transport%20yard%20with%20a%20row%20of%20trucks%2C%20soft%20haze%2C%20industrial%20calm%2C%20desaturated%20navy%20and%20pale%20blue%20palette%2C%20editorial%20photography%2C%20large%20open%20sky%2C%20soft%20focus%20on%20the%20right&width=2400&height=1350&seq=jq-yard-01&orientation=landscape"
        alt="Pátio de transportes ao anoitecer com uma fileira de caminhões"
        data-parallax="0.32"
      />
      <div className="panel-veil" />
      <div className="panel-copy" data-parallax="-0.08">
        <p className="stamp" data-reveal>
          04 — Resultados
        </p>
        <h2 data-reveal>
          Menos erro,
          <br />
          mais <em className="accent">controle</em>
        </h2>
        <p className="sub" data-reveal>
          Cada OS guarda o que aconteceu com o pneu e devolve essa informação quando você
          precisar.
        </p>
        <div className="panel-stats" data-reveal>
          <div className="panel-stat">
            <b>10</b>
            <span>posições por equipamento</span>
          </div>
          <div className="panel-stat">
            <b>02</b>
            <span>tabelas por ordem</span>
          </div>
          <div className="panel-stat">
            <b>16</b>
            <span>motivos catalogados</span>
          </div>
        </div>
      </div>
    </section>
  );
}