import { useCallback, useEffect, useMemo, useState } from "react";
import { listOsChanges, type OsChangeRow } from "@/lib/osChangeLog";

interface Props {
  /** Muda a cada salvamento/importação para recarregar a lista. */
  refreshKey: number;
}

function fmtDateTime(iso: string): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString("pt-BR");
}

export default function OsChangeLog({ refreshKey }: Props) {
  const [rows, setRows] = useState<OsChangeRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [fOs, setFOs] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setRows(await listOsChanges(400));
    } catch {
      setError("Não foi possível carregar o histórico agora.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load, refreshKey]);

  const visible = useMemo(() => {
    const q = fOs.trim().toLowerCase();
    const filtered = q ? rows.filter((r) => (r.os_numero || "").toLowerCase().includes(q)) : rows;
    return filtered.slice(0, 200);
  }, [rows, fOs]);

  return (
    <section className="lost-block os-change-log" id="os-historico-alteracoes" aria-label="Histórico de alterações">
      <div className="lost-block-head">
        <div>
          <span className="summary-kicker">
            <i className="ri-git-commit-line" aria-hidden="true" /> Auditoria
          </span>
          <h2 className="lost-block-title">Histórico de alterações</h2>
          <p className="lost-block-sub">
            Cada mudança feita no sistema ou vinda do Excel fica registrada aqui: campo, valor
            anterior, valor novo, data/hora e a origem. Mais recentes primeiro.
          </p>
        </div>
        <div className="os-history-filters" style={{ marginTop: 0 }}>
          <label className="summary-date">
            <span>Nº da OS</span>
            <input
              type="text"
              placeholder="Ex.: 12"
              value={fOs}
              onChange={(e) => setFOs(e.target.value)}
            />
          </label>
          <button type="button" className="summary-clear" onClick={() => void load()}>
            <i className="ri-refresh-line" aria-hidden="true" /> Atualizar
          </button>
        </div>
      </div>

      {loading ? (
        <p className="lost-empty">
          <i className="ri-loader-4-line spin" aria-hidden="true" /> Carregando o histórico…
        </p>
      ) : error ? (
        <div className="lost-empty">
          <i className="ri-error-warning-line" aria-hidden="true" />
          <span>{error}</span>
          <button type="button" className="summary-clear" onClick={() => void load()}>
            <i className="ri-refresh-line" aria-hidden="true" /> Tentar de novo
          </button>
        </div>
      ) : visible.length === 0 ? (
        <p className="lost-empty">
          <i className="ri-information-line" aria-hidden="true" /> Nenhuma alteração registrada
          ainda. As edições feitas no sistema ou importadas do Excel aparecem aqui.
        </p>
      ) : (
        <div className="lost-table-wrap">
          <table className="lost-table os-changes-table">
            <thead>
              <tr>
                <th>Data / hora</th>
                <th>OS</th>
                <th>Pneu</th>
                <th>Campo</th>
                <th>Valor anterior</th>
                <th>Valor novo</th>
                <th>Origem</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((r) => (
                <tr key={r.id}>
                  <td>{fmtDateTime(r.alterado_em)}</td>
                  <td>
                    <b className="os-history-num">OS {r.os_numero}</b>
                  </td>
                  <td>{r.pneu_id || "—"}</td>
                  <td>{r.campo}</td>
                  <td className="os-changes-old">{r.valor_anterior || "—"}</td>
                  <td className="os-changes-new">{r.valor_novo || "—"}</td>
                  <td>
                    <span className={`os-origin ${r.origem === "excel" ? "is-excel" : "is-system"}`}>
                      <i
                        className={r.origem === "excel" ? "ri-file-excel-2-line" : "ri-computer-line"}
                        aria-hidden="true"
                      />
                      {r.origem === "excel" ? "Excel" : "Sistema"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <p className="summary-foot">
        Registro automático e permanente — nada é apagado ao sincronizar. Use o filtro por OS para
        ver só as alterações de uma ordem específica.
      </p>
    </section>
  );
}