export default function SiteFooter() {
  return (
    <footer className="site-footer" id="contato">
      <div className="foot-grid">
        <div className="foot-brand">
          <img
            className="foot-logo"
            src="https://public.readdy.ai/ai/img_res/a156b410-a185-484d-93b1-98da19bdb609.png"
            alt="JULY QUARTZO — Mineração e Construção"
          />
          <p>
            Mineração e Construção. A OS de movimentação de pneu, do papel ao tablet — com todas
            as posições, motivos e observações no lugar.
          </p>
          <div className="foot-social">
            <a href="#os-form" aria-label="Preencher uma OS">
              <i className="ri-file-edit-line" aria-hidden="true" />
            </a>
            <a href="#story" aria-label="Como funciona">
              <i className="ri-information-line" aria-hidden="true" />
            </a>
            <a href="#diagram" aria-label="Posições dos pneus">
              <i className="ri-roadster-line" aria-hidden="true" />
            </a>
          </div>
        </div>

        <nav aria-label="A OS">
          <h4>A OS</h4>
          <a href="#overview">Visão geral</a>
          <a href="#form">O formulário</a>
          <a href="#decision">Motivo e causa</a>
          <a href="#os-form">Preencher OS</a>
        </nav>

        <nav aria-label="Operação">
          <h4>Operação</h4>
          <a href="#story">Da prancheta ao tablet</a>
          <a href="#diagram">Dez posições</a>
          <a href="#proof">Resultados</a>
        </nav>

        <div>
          <h4>Manutenção</h4>
          <a href="#os-form">Oficina de manutenção</a>
          <a href="#os-form">Supervisor de manut.</a>
          <a href="#os-form">manutencao@julyquartzo.com.br</a>
        </div>
      </div>

      <div className="foot-bottom">
        <span>© {new Date().getFullYear()} July Quartzo Mineração e Construção. Todos os direitos reservados.</span>
        <span>OS - MOVIMENTAÇÃO DE PNEU · versão digital para tablet</span>
      </div>

      <div className="foot-credits">
        <span className="credits-dev">
          <i className="ri-code-s-slash-line" aria-hidden="true" />
          © 2026 — Desenvolvido por <strong>Emerson Silva</strong>
        </span>
        <div className="credits-links">
          <a
            href="https://wa.me/5574991181066"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Falar com o desenvolvedor no WhatsApp"
          >
            <i className="ri-whatsapp-line" aria-hidden="true" />
            (74) 99118-1066
          </a>
          <span className="credits-sep" aria-hidden="true" />
          <a
            href="mailto:emersonengenhariasw@gmail.com"
            aria-label="Enviar e-mail para o desenvolvedor"
          >
            <i className="ri-mail-line" aria-hidden="true" />
            emersonengenhariasw@gmail.com
          </a>
        </div>
      </div>
    </footer>
  );
}