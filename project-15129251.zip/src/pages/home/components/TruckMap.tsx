import { TIRE_GROUP_LABEL, TIRE_POSITIONS, type TireStatus } from "@/lib/tireMap";

const TRUCK_IMG =
  "https://static.readdy.ai/image/609965e270ebc56f2a8bcb8a9ed920d6/1217b9e46cfc3788ddbccebb35146bb5.png";

interface Props {
  statuses: Record<number, TireStatus>;
  selected: number | null;
  onSelect: (id: number) => void;
  disabled?: boolean;
}

/**
 * Desenho oficial do caminhão (visto de cima) com as 10 posições clicáveis por
 * cima. A numeração e a posição dos pneus seguem exatamente o documento.
 */
export default function TruckMap({ statuses, selected, onSelect, disabled }: Props) {
  return (
    <div className={`truckmap${disabled ? " is-disabled" : ""}`}>
      <img
        className="truckmap-img"
        src={TRUCK_IMG}
        alt="Desenho do caminhão visto de cima com as dez posições de pneu numeradas de 1 a 10."
        title="Posições dos pneus do equipamento — 1 a 10"
      />
      <div className="truckmap-layer">
        {TIRE_POSITIONS.map((p) => {
          const status = statuses[p.id] ?? "semRegistro";
          const isSel = selected === p.id;
          return (
            <button
              key={p.id}
              type="button"
              disabled={disabled}
              className={`truckmap-hot is-${status}${isSel ? " is-selected" : ""}`}
              style={{
                left: p.dx ? `calc(${p.x}% + ${p.dx}px)` : `${p.x}%`,
                top: p.dy ? `calc(${p.y}% + ${p.dy}px)` : `${p.y}%`,
              }}
              onClick={() => onSelect(p.id)}
              aria-pressed={isSel}
              aria-label={`Pneu ${p.id} — ${TIRE_GROUP_LABEL[p.group]}, lado ${p.side}${isSel ? " (selecionado)" : ""}`}
              title={`Pneu ${p.id} — ${TIRE_GROUP_LABEL[p.group]}`}
            >
              {p.id}
            </button>
          );
        })}
      </div>
    </div>
  );
}