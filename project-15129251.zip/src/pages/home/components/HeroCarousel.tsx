import { useCallback, useEffect, useRef, useState, type PointerEvent, type TouchEvent } from "react";
import FilmChapter from "@/pages/home/components/FilmChapter";
import {
  DiagramSlide,
  ManifestoSlide,
  ProofSlide,
} from "@/pages/home/components/HeroSlides";

/** Avanço automático a cada 6 s (conforme solicitado). */
const AUTOPLAY_MS = 6000;
/** ids usados para o menu continuar levando ao slide certo (#diagram, #proof). */
const SLIDE_IDS = ["filme", "belief", "diagram", "proof"];

export default function HeroCarousel() {
  const [reduced] = useState(
    () =>
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );
  const [index, setIndex] = useState(0);
  const [hovering, setHovering] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [inView, setInView] = useState(true);
  const [hidden, setHidden] = useState(false);
  const rootRef = useRef<HTMLElement>(null);
  const touchX = useRef<number | null>(null);

  const total = SLIDE_IDS.length;

  const go = useCallback(
    (i: number) => setIndex(((i % total) + total) % total),
    [total],
  );
  const step = useCallback(
    (dir: number) => setIndex((i) => ((i + dir) % total + total) % total),
    [total],
  );

  // Avanço automático — pausa ao interagir, ao sair da tela, com a aba oculta
  // e quando o dispositivo pede movimento reduzido.
  useEffect(() => {
    if (reduced || hovering || dragging || hidden || !inView) return undefined;
    const timer = window.setInterval(() => {
      setIndex((i) => (i + 1) % total);
    }, AUTOPLAY_MS);
    return () => window.clearInterval(timer);
  }, [reduced, hovering, dragging, hidden, inView, total, index]);

  // Só troca sozinho quando o carrossel está realmente na tela.
  useEffect(() => {
    const el = rootRef.current;
    if (!el) return undefined;
    const io = new IntersectionObserver(
      ([entry]) => setInView(entry.isIntersecting && entry.intersectionRatio > 0.4),
      { threshold: [0, 0.4, 1] },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    const onVis = () => setHidden(document.visibilityState !== "visible");
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);

  // O menu (#diagram / #proof) abre o slide correspondente.
  useEffect(() => {
    const sync = () => {
      const id = window.location.hash.replace(/^#/, "");
      const i = SLIDE_IDS.indexOf(id);
      if (i >= 0) setIndex(i);
    };
    sync();
    window.addEventListener("hashchange", sync);
    return () => window.removeEventListener("hashchange", sync);
  }, []);

  const onPointerEnter = (e: PointerEvent<HTMLElement>) => {
    if (e.pointerType === "mouse") setHovering(true);
  };
  const onPointerLeave = (e: PointerEvent<HTMLElement>) => {
    if (e.pointerType === "mouse") setHovering(false);
  };

  const onTouchStart = (e: TouchEvent<HTMLDivElement>) => {
    touchX.current = e.touches[0].clientX;
    setDragging(true);
  };
  const onTouchEnd = (e: TouchEvent<HTMLDivElement>) => {
    if (touchX.current !== null) {
      const dx = e.changedTouches[0].clientX - touchX.current;
      if (Math.abs(dx) > 45) step(dx < 0 ? 1 : -1);
    }
    touchX.current = null;
    setDragging(false);
  };

  const slides = [
    <FilmChapter key="filme" />,
    <ManifestoSlide key="belief" />,
    <DiagramSlide key="diagram" />,
    <ProofSlide key="proof" />,
  ];

  return (
    <section
      ref={rootRef}
      className={`hero-carousel${reduced ? " is-reduced" : ""}`}
      aria-label="Apresentação inicial da July Quartzo"
      onPointerEnter={onPointerEnter}
      onPointerLeave={onPointerLeave}
    >
      <div
        className="hero-viewport"
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
        onTouchCancel={onTouchEnd}
      >
        <div
          className="hero-track"
          style={{ transform: `translateX(-${index * 100}%)` }}
        >
          {slides.map((slide, i) => (
            <div
              key={SLIDE_IDS[i]}
              className={`hero-slide${i === index ? " is-active" : ""}`}
              aria-hidden={i !== index}
            >
              {slide}
            </div>
          ))}
        </div>
      </div>

      <button
        type="button"
        className="hero-arrow prev"
        onClick={() => step(-1)}
        aria-label="Slide anterior"
      >
        <i className="ri-arrow-left-s-line" aria-hidden="true" />
      </button>
      <button
        type="button"
        className="hero-arrow next"
        onClick={() => step(1)}
        aria-label="Próximo slide"
      >
        <i className="ri-arrow-right-s-line" aria-hidden="true" />
      </button>

      <div className="hero-dots" role="tablist" aria-label="Selecionar apresentação">
        {SLIDE_IDS.map((sid, i) => (
          <button
            key={sid}
            type="button"
            role="tab"
            aria-selected={i === index}
            aria-label={`Ir para a apresentação ${i + 1}`}
            className={`hero-dot${i === index ? " is-on" : ""}`}
            onClick={() => go(i)}
          />
        ))}
      </div>
    </section>
  );
}