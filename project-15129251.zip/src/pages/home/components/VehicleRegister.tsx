import { useState } from "react";
import type { FormEvent } from "react";
import { saveVehicle, type Vehicle } from "@/lib/vehicleDb";

interface Props {
  /** Chamado depois de um cadastro salvo com sucesso (para atualizar a lista). */
  onSaved: (vehicle: Vehicle) => void;
}

/**
 * Cadastro manual de caminhão/equipamento, logo abaixo da seleção de veículo.
 * Não exige fotografia. O código/identificação distingue o veículo e evita
 * que o mesmo caminhão seja cadastrado duas vezes.
 */
export default function VehicleRegister({ onSaved }: Props) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [okMsg, setOkMsg] = useState("");

  const toggle = () => {
    setOpen((v) => !v);
    setError("");
    setOkMsg("");
  };

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (saving) return;
    setError("");
    setOkMsg("");
    if (!code.trim()) {
      setError("Informe o código/identificação (ex.: CB-0).");
      return;
    }
    if (!name.trim()) {
      setError("Informe o modelo/nome do caminhão.");
      return;
    }
    setSaving(true);
    try {
      const saved = await saveVehicle({ code, name });
      onSaved(saved);
      setOkMsg(`Caminhão ${saved.code} cadastrado e selecionado.`);
      setName("");
      setCode("");
      setOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível cadastrar agora. Tente novamente.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="vehicle-reg">
      <button type="button" className="tiremap-addveh" onClick={toggle} aria-expanded={open}>
        <i className="ri-add-circle-line" aria-hidden="true" />
        {open ? "Fechar cadastro" : "Cadastrar Caminhão"}
      </button>

      {open && (
        <form className="vehicle-form" onSubmit={submit}>
          <label className="vehicle-field">
            <span>Modelo / Nome do caminhão</span>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value.slice(0, 60))}
              placeholder="Ex.: Caminhão de mina 400"
              maxLength={60}
            />
          </label>
          <label className="vehicle-field">
            <span>Código / Identificação</span>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value.slice(0, 24))}
              placeholder="Ex.: CB-0"
              maxLength={24}
            />
          </label>
          <div className="vehicle-form-actions">
            <button type="submit" className="btn btn-primary btn-sm" disabled={saving}>
              <i className="ri-save-3-line" aria-hidden="true" /> {saving ? "Salvando…" : "Salvar cadastro"}
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={toggle}>
              Cancelar
            </button>
          </div>
          <p className="vehicle-hint">
            <i className="ri-information-line" aria-hidden="true" /> A fotografia não é obrigatória.
          </p>
        </form>
      )}

      {error && (
        <p className="vehicle-msg is-err" role="alert">
          <i className="ri-error-warning-line" aria-hidden="true" /> {error}
        </p>
      )}
      {okMsg && !open && (
        <p className="vehicle-msg is-ok" role="status">
          <i className="ri-check-line" aria-hidden="true" /> {okMsg}
        </p>
      )}
    </div>
  );
}