import type { ReactNode } from "react";
import type { OsFormData, OsTireInstalled, OsTireRemoved } from "@/lib/osTypes";
import { OS_MOTIVO_CODES } from "@/mocks/osForm";

interface Props {
  form: OsFormData;
  setRemoved: (index: number, key: keyof OsTireRemoved, value: string) => void;
  setInstalled: (index: number, key: keyof OsTireInstalled, value: string) => void;
  /** Posição vinda do mapa do caminhão — destaca a linha correspondente. */
  activePosition?: number | null;
  /** Registro Fotográfico — renderizado na coluna à direita das tabelas. */
  photoField?: ReactNode;
}

export default function OsTireTables({
  form,
  setRemoved,
  setInstalled,
  activePosition,
  photoField,
}: Props) {
  return (
    <div className="os-tables-block">
      <div className="os-tables">
      <div>
        <div className="os-subhead">Pneu retirado</div>
        <table className="os-table os-table-removed">
          <thead>
            <tr>
              <th style={{ width: "16%" }}>Posição</th>
              <th style={{ width: "22%" }}>Marca</th>
              <th style={{ width: "18%" }}>Fogo</th>
              <th style={{ width: "12%" }}>MM</th>
              <th style={{ width: "20%" }}>Motivo</th>
              <th style={{ width: "12%" }}>Vidas</th>
            </tr>
          </thead>
          <tbody>
            {form.retirados.map((row, i) => (
              <tr key={`ret-${i}`} className={activePosition === i + 1 ? "is-map-pos" : undefined}>
                <td className="os-cell-pos" aria-label={`Posição ${i + 1}`}>{i + 1}</td>
                <td><input aria-label={`Marca linha ${i + 1}`} value={row.marca} onChange={(e) => setRemoved(i, "marca", e.target.value)} /></td>
                <td><input aria-label={`Fogo linha ${i + 1}`} value={row.fogo} onChange={(e) => setRemoved(i, "fogo", e.target.value)} /></td>
                <td><input aria-label={`MM linha ${i + 1}`} inputMode="numeric" value={row.mm} onChange={(e) => setRemoved(i, "mm", e.target.value)} /></td>
                <td>
                  <select
                    className="os-table-select"
                    aria-label={`Motivo linha ${i + 1}`}
                    value={row.motivo}
                    onChange={(e) => setRemoved(i, "motivo", e.target.value)}
                  >
                    <option value=""> </option>
                    {OS_MOTIVO_CODES.map((code) => (
                      <option key={code} value={code}>{code}</option>
                    ))}
                  </select>
                </td>
                <td><input aria-label={`Vidas linha ${i + 1}`} inputMode="numeric" value={row.vidas} onChange={(e) => setRemoved(i, "vidas", e.target.value)} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div>
        <div className="os-subhead">Pneu instalado</div>
        <table className="os-table">
          <thead>
            <tr>
              <th style={{ width: "30%" }}>Marca</th>
              <th style={{ width: "26%" }}>Fogo</th>
              <th style={{ width: "22%" }}>MM</th>
              <th style={{ width: "22%" }}>Vidas</th>
            </tr>
          </thead>
          <tbody>
            {form.instalados.map((row, i) => (
              <tr key={`inst-${i}`}>
                <td><input aria-label={`Marca instalado linha ${i + 1}`} value={row.marca} onChange={(e) => setInstalled(i, "marca", e.target.value)} /></td>
                <td><input aria-label={`Fogo instalado linha ${i + 1}`} value={row.fogo} onChange={(e) => setInstalled(i, "fogo", e.target.value)} /></td>
                <td><input aria-label={`MM instalado linha ${i + 1}`} inputMode="numeric" value={row.mm} onChange={(e) => setInstalled(i, "mm", e.target.value)} /></td>
                <td><input aria-label={`Vidas instalado linha ${i + 1}`} inputMode="numeric" value={row.vidas} onChange={(e) => setInstalled(i, "vidas", e.target.value)} /></td>
              </tr> 
            ))}
          </tbody>
        </table>
      </div>

      </div>
      {photoField ? <div className="os-photo-wrap">{photoField}</div> : null}
    </div>
  );
}