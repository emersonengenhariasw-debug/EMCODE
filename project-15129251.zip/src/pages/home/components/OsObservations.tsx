interface Props {
  observacoes: string;
  onChange: (value: string) => void;
  supervisorNome: string;
  onSupervisorChange: (value: string) => void;
}

export default function OsObservations({
  observacoes,
  onChange,
  supervisorNome,
  onSupervisorChange,
}: Props) {
  return (
    <div className="os-bottom">
      <div>
        <div className="os-obs-label">Observações:</div>
        <textarea
          className="os-textarea"
          maxLength={500}
          placeholder="Digite aqui as observações do serviço…"
          value={observacoes}
          onChange={(e) => onChange(e.target.value)}
          aria-label="Observações"
        />
        <div className="os-count">{observacoes.length}/500</div>
      </div>

      <div className="os-sign">
        <span className="os-sign-co">July Quartzo Construção</span>
        <input
          className="os-sign-name os-sign-input"
          type="text"
          value={supervisorNome}
          onChange={(e) => onSupervisorChange(e.target.value)}
          placeholder="Nome do supervisor"
          aria-label="Nome do supervisor"
          maxLength={80}
        />
        <span className="os-sign-role">Supervisor de Manut.</span>
      </div>
    </div>
  );
}