import TireDashboard from "@/pages/home/components/TireDashboard";

export default function SitePanels() {
  return (
    <>
      {/* PANEL — dashboard de controle de pneus (bloco 02, logo após a apresentação) */}
      <TireDashboard />
    </>
  );
}