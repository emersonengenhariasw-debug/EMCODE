import type { MonthPoint, DonutSegment, TurmaBar } from "@/lib/osDashboard";
import { formatInt } from "@/lib/osDashboard";

/* ===================== KPI ===================== */

type KpiTone = "gold" | "green";

interface KpiCardProps {
  label: string;
  value: number;
  icon: string;
  tone: KpiTone;
  delta: number | null;
}

export function KpiCard({ label, value, icon, tone, delta }: KpiCardProps) {
  const toneClass = tone === "gold" ? "is-gold" : "is-green";
  let deltaCls = "none";
  let deltaText = "—";
  if (delta !== null) {
    deltaCls = delta >= 0 ? "up" : "down";
    deltaText = `${delta >= 0 ? "+" : ""}${delta}%`;
  }
  return (
    <div className="dash-kpi">
      <div className="dash-kpi-top">
        <span className={`dash-kpi-ico ${toneClass}`} aria-hidden="true">
          <i className={icon} />
        </span>
        <span className="dash-kpi-label">{label}</span>
      </div>
      <div className="dash-kpi-value">{formatInt(value)}</div>
      <div className={`dash-kpi-delta ${deltaCls}`}>
        {delta !== null && (
          <i className={delta >= 0 ? "ri-arrow-up-line" : "ri-arrow-down-line"} aria-hidden="true" />
        )}
        <span>{deltaText}</span>
        {delta !== null && <em>vs. período anterior</em>}
      </div>
    </div>
  );
}

/* ================ MOVIMENTAÇÕES POR MÊS (barras) ================ */

interface BarChartProps {
  series: MonthPoint[];
}

export function MovementBarChart({ series }: BarChartProps) {
  const maxRaw = Math.max(1, ...series.map((s) => Math.max(s.retirados, s.instalados)));
  const step = Math.max(1, Math.ceil(maxRaw / 4));
  const top = step * 4;
  const ticks = [top, step * 3, step * 2, step, 0];

  const hasData = series.some((s) => s.retirados > 0 || s.instalados > 0);

  if (!hasData) {
    return (
      <div className="dash-empty">
        <i className="ri-bar-chart-2-line" aria-hidden="true" />
        <span>Sem dados de movimentação para os filtros selecionados.</span>
      </div>
    );
  }

  const h = (v: number) => `${(v / top) * 100}%`;

  return (
    <div className="dash-bars">
      <div className="dash-yaxis" aria-hidden="true">
        {ticks.map((t) => (
          <span key={t}>{t}</span>
        ))}
      </div>
      <div className="dash-plotarea">
        <div className="dash-plot">
          <div className="dash-gridlines" aria-hidden="true">
            <span /><span /><span /><span /><span />
          </div>
          <div className="dash-cols">
            {series.map((s) => (
              <div className="dash-col" key={s.key}>
                <span className="dash-bar is-green" style={{ height: h(s.retirados) }} title={`Retirados: ${s.retirados}`} />
                <span className="dash-bar is-gold" style={{ height: h(s.instalados) }} title={`Instalados: ${s.instalados}`} />
              </div>
            ))}
          </div>
        </div>
        <div className="dash-xaxis" aria-hidden="true">
          {series.map((s) => (
            <span key={s.key}>{s.label}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ================ MOTIVOS MAIS FREQUENTES (rosca) ================ */

interface DonutProps {
  segments: DonutSegment[];
  total: number;
}

const DONUT_COLORS = [
  "oklch(var(--accent-500))",
  "oklch(var(--secondary-500))",
  "oklch(var(--accent-400))",
  "oklch(var(--secondary-400))",
  "oklch(var(--accent-600))",
  "oklch(var(--secondary-600))",
];

export function MotiveDonut({ segments, total }: DonutProps) {
  if (!total || segments.length === 0) {
    return (
      <div className="dash-empty">
        <i className="ri-pie-chart-2-line" aria-hidden="true" />
        <span>Sem motivos registrados ainda.</span>
      </div>
    );
  }

  let acc = 0;
  const stops = segments
    .map((s, i) => {
      const start = (acc / total) * 100;
      acc += s.value;
      const end = (acc / total) * 100;
      const color = DONUT_COLORS[i % DONUT_COLORS.length];
      return `${color} ${start.toFixed(2)}% ${end.toFixed(2)}%`;
    })
    .join(", ");

  return (
    <div className="dash-donut-wrap">
      <div className="dash-donut" style={{ background: `conic-gradient(${stops})` }} role="img" aria-label={`Total de ${total} ocorrências`}>
        <div className="dash-donut-hole">
          <b>{formatInt(total)}</b>
          <span>ocorrências</span>
        </div>
      </div>
      <ul className="dash-donut-legend">
        {segments.map((s, i) => (
          <li key={s.label}>
            <span className="lg-dot" style={{ background: DONUT_COLORS[i % DONUT_COLORS.length] }} aria-hidden="true" />
            <span className="lg-name" title={s.label}>{s.label}</span>
            <span className="lg-val">{formatInt(s.value)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ================ MOVIMENTAÇÕES POR TURMA/LETRA ================ */

interface TurmaProps {
  rows: TurmaBar[];
}

export function TurmaBars({ rows }: TurmaProps) {
  const max = Math.max(1, ...rows.map((r) => r.value));
  const hasData = rows.some((r) => r.value > 0);

  return (
    <div>
      <ul className="dash-turmas">
        {rows.map((r, i) => (
          <li className="dash-turma" key={r.label}>
            <span className="nm">{r.label}</span>
            <span className="track">
              <span
                className={`bar ${i % 2 === 0 ? "is-green" : "is-gold"}`}
                style={{ width: `${hasData ? (r.value / max) * 100 : 0}%` }}
              />
            </span>
            <span className="qt">{formatInt(r.value)}</span>
          </li>
        ))}
      </ul>
      {!hasData && <div className="dash-mini-empty">Sem dados</div>}
    </div>
  );
}