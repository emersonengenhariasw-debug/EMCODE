import { useCallback, useEffect, useMemo, useState } from "react";
import type { SavedOs } from "@/lib/osTypes";
import type { LostTireRecord } from "@/lib/lostTiresTypes";
import {
  TIRE_STATUS_META,
  buildTireHistory,
  buildTireStatusMap,
  computeTireStatus,
  latestTireId,
  listVehicles,
  type TireStatus,
} from "@/lib/tireMap";
import { listRegisteredVehicles } from "@/lib/vehicleDb";
import type { EditableTireStatus } from "@/lib/tireStatusDb";
import TruckMap from "@/pages/home/components/TruckMap";
import TireHistoryPanel from "@/pages/home/components/TireHistoryPanel";
import VehicleRegister from "@/pages/home/components/VehicleRegister";

interface Props {
  orders: SavedOs[];
  lost: LostTireRecord[];
  equipment: string;
  onEquipmentChange: (value: string) => void;
  selected: number | null;
  onSelect: (id: number) => void;
  /** Situações escolhidas manualmente para cada posição (por caminhão). */
  overrides: Record<number, EditableTireStatus>;
  /** Registra a situação escolhida para uma posição do mapa. */
  onSetStatus: (position: number, status: EditableTireStatus) => void;
}

/**
 * Bloco branco do mapa do caminhão + detalhes/histórico do pneu selecionado.
 * Desktop: mapa à esquerda, detalhes à direita. Celular: detalhes abaixo do mapa.
 */
export default function TireMapBlock({
  orders,
  lost,
  equipment,
  onEquipmentChange,
  selected,
  onSelect,
  overrides,
  onSetStatus,
}: Props) {
  const [registered, setRegistered] = useState<string[]>([]);

  const refreshRegistered = useCallback(async () => {
    try {
      const list = await listRegisteredVehicles();
      setRegistered(list.map((v) => v.code).filter(Boolean));
    } catch {
      setRegistered([]);
    }
  }, []);

  useEffect(() => {
    void refreshRegistered();
  }, [refreshRegistered]);

  const vehicles = useMemo(() => {
    const set = new Set<string>();
    listVehicles(orders, lost).forEach((v) => set.add(v));
    registered.forEach((v) => set.add(v));
    const arr = Array.from(set).sort((a, b) => a.localeCompare(b, "pt-BR", { numeric: true }));
    const current = equipment.trim();
    if (current) {
      const i = arr.indexOf(current);
      if (i >= 0) arr.splice(i, 1);
      arr.unshift(current);
    }
    return arr;
  }, [orders, lost, registered, equipment]);

  const baseStatuses = useMemo(
    () => buildTireStatusMap(orders, lost, equipment),
    [orders, lost, equipment],
  );

  // Situação efetiva = a escolhida manualmente (quando houver) sobre a apurada
  // pelos registros reais. Assim o mapa mantém as cores já definidas no sistema.
  const statuses = useMemo(() => {
    const out: Record<number, TireStatus> = { ...baseStatuses };
    Object.entries(overrides).forEach(([key, value]) => {
      out[Number(key)] = value;
    });
    return out;
  }, [baseStatuses, overrides]);

  const events = useMemo(
    () => (selected && equipment.trim() ? buildTireHistory(orders, lost, equipment, selected) : []),
    [orders, lost, equipment, selected],
  );

  const status: TireStatus | null =
    selected && equipment.trim() ? statuses[selected] ?? computeTireStatus(orders, lost, equipment, selected) : null;

  const tireId = useMemo(() => latestTireId(events), [events]);

  const hasVehicle = Boolean(equipment.trim());

  return (
    <section className="tiremap-block" id="mapa-pneus" aria-label="Mapa do caminhão e histórico de pneus">
      <div className="tiremap-head">
        <div>
          <span className="tiremap-kicker">
            <i className="ri-roadster-line" aria-hidden="true" /> Mapa do caminhão
          </span>
          <h3 className="tiremap-title">Posições do veículo e histórico do pneu</h3>
          <p className="tiremap-sub">
            Selecione o caminhão, clique em um pneu para ver a situação e o histórico individual, e a
            posição selecionada é lançada automaticamente na OS.
          </p>
        </div>

        <div className="tiremap-vehicle-wrap">
          <div className="tiremap-vehicle">
            <label htmlFor="tiremap-veh">Caminhão</label>
            <select
              id="tiremap-veh"
              value={equipment}
              onChange={(e) => onEquipmentChange(e.target.value)}
            >
              <option value="">Selecione o caminhão</option>
              {vehicles.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>
          </div>
          <VehicleRegister
            onSaved={(v) => {
              void refreshRegistered();
              onEquipmentChange(v.code);
            }}
          />
        </div>
      </div>

      <div className="tiremap-grid">
        <div>
          <TruckMap
            statuses={statuses}
            selected={selected}
            onSelect={onSelect}
            disabled={!hasVehicle}
          />
          <ul className="tiremap-legend">
            {TIRE_STATUS_META.map((m) => (
              <li key={m.id}>
                <span className={`dot dot-${m.id}`} aria-hidden="true" /> {m.label}
              </li>
            ))}
          </ul>
          {!hasVehicle && (
            <p className="tiremap-hint">
              <i className="ri-information-line" aria-hidden="true" /> Selecione o caminhão para
              consultar as posições.
            </p>
          )}
        </div>

        <TireHistoryPanel
          vehicle={equipment}
          position={selected}
          status={status}
          onSetSituacao={(s) => {
            if (selected) onSetStatus(selected, s);
          }}
          tireId={tireId}
          events={events}
        />
      </div>
    </section>
  );
}