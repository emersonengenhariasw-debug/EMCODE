import { useEffect, useMemo, useRef, useState } from "react";
import type { SavedOs } from "@/lib/osTypes";
import { formatOsDateTime } from "@/lib/osDate";
import { OS_TURMA_OPTIONS, OS_TURNO_OPTIONS } from "@/mocks/osForm";

interface Props {
  orders: SavedOs[];
  activeId?: string;
  /** Nº da OS que está sendo aberta no momento (para o feedback visual). */
  openingId?: string | null;
  /** Abre a OS correspondente pelo seu identificador único (Nº da OS). */
  onOpen: (id: string) => void;
  onDelete: (id: string) => void;
}

/* ISO yyyy-mm-dd (ou datetime) → DD/MM/AAAA. */
function fmtDate(iso: string): string {
  if (!iso) return "—";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (m) return `${m[3]}/${m[2]}/${m[1]}`;
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleDateString("pt-BR");
}

const norm = (s: string) =>
  (s || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();

/* Data principal do registro: entrada → saída → data do salvamento. */
function mainDate(o: SavedOs): string {
  return (o.dataEntrada || o.dataSaida || (o.savedAt ? o.savedAt.slice(0, 10) : "")).trim();
}

/* Quantas OS entram na tabela de início e a cada clique em VER MAIS. */
const HISTORY_PAGE = 7;

export default function OsHistory({ orders, activeId, openingId, onOpen, onDelete }: Props) {
  const [fNumero, setFNumero] = useState("");
  const [fEntrada, setFEntrada] = useState("");
  const [fSaida, setFSaida] = useState("");
  const [fEquip, setFEquip] = useState("");
  const [fOperador, setFOperador] = useState("");
  const [fTurma, setFTurma] = useState("");
  const [fTurno, setFTurno] = useState("");
  const [visible, setVisible] = useState(HISTORY_PAGE);
  const lastReveal = useRef(HISTORY_PAGE);

  const hasFilter = Boolean(
    fNumero || fEntrada || fSaida || fEquip || fOperador || fTurma || fTurno,
  );

  const rows = useMemo(() => {
    const filtered = orders.filter((o) => {
      if (fNumero && !norm(o.numero).includes(norm(fNumero))) return false;
      if (fEntrada && (o.dataEntrada || "") !== fEntrada) return false;
      if (fSaida && (o.dataSaida || "") !== fSaida) return false;
      if (fEquip && !norm(o.equip).includes(norm(fEquip))) return false;
      if (fOperador && !norm(o.operador).includes(norm(fOperador))) return false;
      if (fTurma && (o.turma || "") !== fTurma) return false;
      if (fTurno && (o.turno || "") !== fTurno) return false;
      return true;
    });
    // Mais recentes primeiro (pela data do registro; empate desempata pelo salvamento).
    return filtered.sort((a, b) => {
      const da = mainDate(a);
      const db = mainDate(b);
      if (da === db) return (b.savedAt || "").localeCompare(a.savedAt || "");
      return db.localeCompare(da);
    });
  }, [orders, fNumero, fEntrada, fSaida, fEquip, fOperador, fTurma, fTurno]);

  /* Sempre que os filtros (ou a lista) mudam, volta a mostrar só os 7 mais recentes. */
  useEffect(() => {
    setVisible(HISTORY_PAGE);
    lastReveal.current = HISTORY_PAGE;
  }, [fNumero, fEntrada, fSaida, fEquip, fOperador, fTurma, fTurno, orders]);

  const shown = rows.slice(0, visible);
  const hasMore = visible < rows.length;

  const showMore = () => {
    lastReveal.current = visible;
    setVisible((v) => v + HISTORY_PAGE);
  };

  const clearFilters = () => {
    setFNumero("");
    setFEntrada("");
    setFSaida("");
    setFEquip("");
    setFOperador("");
    setFTurma("");
    setFTurno("");
  };

  return (
    <section className="lost-block os-history" id="os-historico" aria-label="Histórico das OS salvas">
      <div className="lost-block-head">
        <div>
          <span className="summary-kicker">
            <i className="ri-history-line" aria-hidden="true" /> Ordens salvas
          </span>
          <h2 className="lost-block-title">Histórico completo das OS</h2>
          <p className="lost-block-sub">
            Consulte todas as ordens de serviço registradas e abra uma OS para ver (ou editar) todos
            os dados preenchidos. Mais recentes primeiro.
          </p>
        </div>
        <span className="os-history-count">
          <b>{rows.length}</b>
          <span>{rows.length === 1 ? "OS listada" : "OS listadas"}</span>
        </span>
      </div>

      <div className="os-history-filters" aria-label="Filtros do histórico">
        <label className="summary-date">
          <span>Nº da OS</span>
          <input
            type="text"
            inputMode="numeric"
            placeholder="Ex.: 12"
            value={fNumero}
            onChange={(e) => setFNumero(e.target.value)}
          />
        </label>
        <label className="summary-date">
          <span>Data de entrada</span>
          <input type="date" value={fEntrada} onChange={(e) => setFEntrada(e.target.value)} />
        </label>
        <label className="summary-date">
          <span>Data de saída</span>
          <input type="date" value={fSaida} onChange={(e) => setFSaida(e.target.value)} />
        </label>
        <label className="summary-date">
          <span>Equipamento</span>
          <input
            type="text"
            placeholder="Ex.: CB-01"
            value={fEquip}
            onChange={(e) => setFEquip(e.target.value)}
          />
        </label>
        <label className="summary-date">
          <span>Operador</span>
          <input
            type="text"
            placeholder="Nome do operador"
            value={fOperador}
            onChange={(e) => setFOperador(e.target.value)}
          />
        </label>
        <label className="summary-date">
          <span>Turma/Letra</span>
          <select value={fTurma} onChange={(e) => setFTurma(e.target.value)}>
            <option value="">Todas</option>
            {OS_TURMA_OPTIONS.map((o) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
        </label>
        <label className="summary-date">
          <span>Horário/Turno</span>
          <select value={fTurno} onChange={(e) => setFTurno(e.target.value)}>
            <option value="">Todos</option>
            {OS_TURNO_OPTIONS.map((o) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
        </label>
        {hasFilter && (
          <button type="button" className="summary-clear" onClick={clearFilters}>
            <i className="ri-close-line" aria-hidden="true" /> Limpar filtros
          </button>
        )}
      </div>

      {orders.length === 0 ? (
        <p className="lost-empty">
          <i className="ri-information-line" aria-hidden="true" /> Nenhuma OS salva ainda. Finalize
          uma ordem de serviço para ela aparecer neste histórico.
        </p>
      ) : rows.length === 0 ? (
        <p className="lost-empty">
          <i className="ri-filter-off-line" aria-hidden="true" /> Nenhuma OS encontrada com os filtros
          aplicados. Ajuste ou limpe os filtros para ver todas.
        </p>
      ) : (
        <>
          <div className="lost-table-wrap">
            <table className="lost-table os-history-table">
              <thead>
                <tr>
                  <th>Nº OS</th>
                  <th>Data</th>
                  <th>Equipamento</th>
                  <th>Operador</th>
                  <th>Turma/Letra</th>
                  <th>Horário/Turno</th>
                  <th>Registrado em</th>
                  <th>Situação</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {shown.map((r, i) => {
                  const isActive = activeId === r.id;
                  const isNew = i >= lastReveal.current;
                  return (
                    <tr key={r.id} className={`${isActive ? "is-active" : ""}${isNew ? " is-new-row" : ""}`.trim() || undefined}>
                      <td>
                        <b className="os-history-num">OS {r.numero || "s/n"}</b>
                      </td>
                      <td>{fmtDate(mainDate(r))}</td>
                      <td>{r.equip || "—"}</td>
                      <td>{r.operador || "—"}</td>
                      <td>{r.turma || "—"}</td>
                      <td>{r.turno || "—"}</td>
                      <td>{formatOsDateTime(r.savedAt)}</td>
                      <td>
                        <span className={`lost-badge ${r.finalized ? "final" : "draft"}`}>
                          {r.finalized ? "Finalizada" : "Em preenchimento"}
                        </span>
                      </td>
                      <td>
                        <div className="lost-row-actions">
                          <button
                            type="button"
                            className="lost-icon-btn"
                            title={`Abrir OS ${r.numero || "s/n"}`}
                            aria-label={`Abrir OS ${r.numero || "s/n"}`}
                            disabled={openingId === r.id}
                            onClick={() => onOpen(r.id)}
                          >
                            <i
                              className={openingId === r.id ? "ri-loader-4-line spin" : "ri-folder-open-line"}
                              aria-hidden="true"
                            />
                          </button>
                          <button
                            type="button"
                            className="lost-icon-btn danger"
                            title={`Excluir OS ${r.numero || "s/n"}`}
                            onClick={() => onDelete(r.id)}
                          >
                            <i className="ri-delete-bin-6-line" aria-hidden="true" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="os-history-more">
            {hasMore ? (
              <button type="button" className="btn btn-ghost" onClick={showMore}>
                <i className="ri-arrow-down-s-line" aria-hidden="true" /> VER MAIS...
              </button>
            ) : (
              <span className="os-history-end">
                <i className="ri-checkbox-circle-line" aria-hidden="true" /> Todos os registros estão visíveis
              </span>
            )}
            <span className="os-history-more-info">
              Mostrando {shown.length} de {rows.length} {rows.length === 1 ? "OS" : "OS"}
            </span>
          </div>
        </>
      )}

      <p className="summary-foot">
        Cada linha é uma OS salva individualmente. O botão de pasta abre a ficha com todos os dados
        preenchidos (inclusive as fotos vinculadas).
      </p>
    </section>
  );
}