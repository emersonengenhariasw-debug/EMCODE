import { useEffect, useMemo, useState } from "react";

const LINKS = [
  { href: "#story", label: "A operação" },
  { href: "#diagram", label: "O desenho" },
  { href: "#proof", label: "Resultados" },
  { href: "#os-form", label: "Preencher OS" },
];

/* Endereço público da tela de instalação compartilhada. */
const FALLBACK_INSTALL_LINK = "https://jqzborrachariadigital.online/instalar";

export default function SiteNav() {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");
  const [shareToast, setShareToast] = useState<string | null>(null);

  const installLink = useMemo(() => {
    if (typeof window === "undefined") return FALLBACK_INSTALL_LINK;
    const base = (import.meta.env.BASE_URL || "/").replace(/\/+$/, "");
    return `${window.location.origin}${base}/instalar`;
  }, []);

  const copyInstallLink = async () => {
    try {
      await navigator.clipboard.writeText(installLink);
      setShareToast("Link de instalação copiado!");
    } catch {
      setShareToast("Copie o link: " + installLink);
    }
    setOpen(false);
    window.setTimeout(() => setShareToast(null), 2800);
  };

  useEffect(() => {
    const onScroll = () => {
      const chapter = document.querySelector<HTMLElement>(".chapter");
      const trigger = chapter ? chapter.offsetHeight - 90 : 400;
      setSolid(window.scrollY > trigger);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  /* Seção ativa: acende o brilho dourado no link correspondente à área em foco.
     Funciona tanto para as seções roladas quanto para os slides do carrossel. */
  useEffect(() => {
    const ids = LINKS.map((l) => l.href.slice(1));
    const els = ids
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => Boolean(el));
    if (!els.length) return undefined;
    const ratios = new Map<string, number>();
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => ratios.set((e.target as HTMLElement).id, e.intersectionRatio));
        let best = "";
        let bestRatio = 0.15;
        ratios.forEach((r, id) => {
          if (r > bestRatio) {
            bestRatio = r;
            best = id;
          }
        });
        setActive(best);
      },
      { threshold: [0, 0.15, 0.5, 0.75, 1] },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  return (
    <>
      <header className={`site-nav${solid ? " is-solid" : ""}`}>
        <a className="nav-brand" href="#top" aria-label="July Quartzo — Mineração e Construção, início">
          <img
            className="brand-mark"
            src="https://public.readdy.ai/ai/img_res/a156b410-a185-484d-93b1-98da19bdb609.png"
            alt="JULY QUARTZO — Mineração e Construção"
          />
        </a>

        <nav className="nav-links" aria-label="Navegação principal">
          {LINKS.map((l) => {
            const isActive = active === l.href.slice(1);
            return (
              <a
                key={l.href}
                className={`nav-link${isActive ? " is-active" : ""}`}
                href={l.href}
                aria-current={isActive ? "true" : undefined}
              >
                {l.label}
              </a>
            );
          })}
          <button
            type="button"
            className="nav-share"
            onClick={copyInstallLink}
            aria-label="Compartilhar instalação"
            title="Copiar o link de instalação"
          >
            <i className="ri-smartphone-line" aria-hidden="true" />
            <span className="nav-share-text">Compartilhar instalação</span>
          </button>
          <a className="nav-cta" href="#os-form">
            <i className="ri-file-edit-line" aria-hidden="true" /> Nova OS
          </a>
        </nav>

        <button
          className="nav-burger"
          type="button"
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <i className={open ? "ri-close-line" : "ri-menu-line"} aria-hidden="true" />
        </button>
      </header>

      {open && (
        <div className="nav-mobile">
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)}>
              {l.label}
            </a>
          ))}
          <a className="btn btn-primary" href="#os-form" onClick={() => setOpen(false)} style={{ marginTop: 10, justifyContent: "center" }}>
            <i className="ri-file-edit-line" aria-hidden="true" /> Nova OS
          </a>
          <button type="button" className="nav-mobile-share" onClick={copyInstallLink}>
            <i className="ri-smartphone-line" aria-hidden="true" /> Compartilhar instalação
          </button>
        </div>
      )}
      {shareToast && (
        <div className="nav-share-toast" role="status" aria-live="polite">
          {shareToast}
        </div>
      )}
    </>
  );
}