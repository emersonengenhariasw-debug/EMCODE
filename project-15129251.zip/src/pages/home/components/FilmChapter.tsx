const VIDEO_URL =
  "https://static.readdy.ai/video/c836fea67fe8332f3736535343261619/978fa882b7af90db9127f315cebbde74.mp4";
const VIDEO_COVER =
  "https://static.readdy.ai/image/609965e270ebc56f2a8bcb8a9ed920d6/836242f12a11986ae8fbf2c721600450.jpeg";

export default function FilmChapter() {
  return (
    <section
      className="chapter"
      data-video={VIDEO_URL}
      data-duration="14"
      data-poster={VIDEO_COVER}
      data-label="OS Movimentação de Pneu"
      aria-label="Filme de abertura — July Quartzo"
    >
      <div className="stage">
        <img
          className="plate"
          src={VIDEO_COVER}
          width="1920"
          height="1080"
          fetchPriority="high"
          decoding="async"
          alt="Tablet sobre a bancada de uma oficina de caminhões; a mão do operador levanta o aparelho e a tela acende com o formulário digital da OS."
        />
        <div className="veil" aria-hidden="true" />
        <div className="veil veil-light" aria-hidden="true" />


        {/* Beat 01 — acts 1 + 2 (0–6 s), the brand wakes up on the film */}
        <div
          className="beat"
          data-from="0"
          data-to="0.4286"
          data-pos="left"
          data-depth="soft"
          data-tone="dark"
          data-motion="track"
          id="overview"
        >
          <p className="stamp">01 · July Quartzo</p>
          <h2 data-split="lines">
            A OS do pneu,
            <br />
            agora <em className="accent">digital</em>.
          </h2>
          <p className="sub">
            Movimentação de pneu completa, preenchida direto no tablet da oficina.
          </p>
          <a className="cta" href="#os-form">
            Preencher OS <i className="ri-arrow-right-line" aria-hidden="true" />
          </a>
        </div>

        {/* Beat 02 — act 3 (6–10 s), the form sharpens into view */}
        <div
          className="beat"
          data-from="0.4286"
          data-to="0.7143"
          data-pos="left"
          data-depth="soft"
          data-tone="light"
          data-motion="zoom"
          id="form"
        >
          <p className="stamp">02 · O formulário</p>
          <h2 data-split="lines">
            Cada campo,
            <br />
            no <em className="accent">lugar</em> certo.
          </h2>
          <ul className="points">
            <li>Retirado e instalado</li>
            <li>Dez posições</li>
            <li>Motivos por código</li>
          </ul>
        </div>

        {/* Beat 03 — acts 4 + 5 (10–14 s), the decision */}
        <div
          className="beat"
          data-from="0.7143"
          data-to="1"
          data-pos="left"
          data-depth="soft"
          data-tone="dark"
          data-motion="drift"
          id="decision"
        >
          <p className="stamp">03 · Decisão</p>
          <h2 data-split="lines">
            Motivo e causa,
            <br />
            sem perder <em className="accent">nada</em>.
          </h2>
          <p className="sub">Finalize, salve e exporte a OS.</p>
          <a className="cta" href="#os-form">
            Ver formulário <i className="ri-arrow-right-line" aria-hidden="true" />
          </a>
        </div>

        <div className="scroll-cue" aria-hidden="true">
          <span />
        </div>
      </div>
    </section>
  );
}