import {
  EDITABLE_TIRE_STATUS_META,
  TIRE_EVENT_ICON,
  TIRE_EVENT_LABEL,
  TIRE_GROUP_LABEL,
  TIRE_POSITIONS,
  TIRE_STATUS_META,
  fmtEventDate,
  type TireEvent,
  type TireStatus,
} from "@/lib/tireMap";
import type { EditableTireStatus } from "@/lib/tireStatusDb";

interface Props {
  vehicle: string;
  position: number | null;
  status: TireStatus | null;
  onSetSituacao: (status: EditableTireStatus) => void;
  tireId: { fogo: string; marca: string };
  events: TireEvent[];
}

export default function TireHistoryPanel({ vehicle, position, status, onSetSituacao, tireId, events }: Props) {
  const pos = position ? TIRE_POSITIONS.find((p) => p.id === position) : undefined;
  const statusLabel = status ? TIRE_STATUS_META.find((m) => m.id === status)?.label ?? "" : "";

  if (!vehicle.trim() || !position) {
    return (
      <div className="tiredetail">
        <div className="tiredetail-empty">
          <i className="ri-cursor-line" aria-hidden="true" />
          <b>Selecione um pneu no mapa</b>
          <span>
            Escolha o caminhão e clique em uma das posições para ver a situação e o histórico
            individual do pneu.
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="tiredetail">
      <div className="tiredetail-head">
        <div>
          <div className="tiredetail-title">Pneu {position}</div>
          <div className="tiredetail-pos">
            {vehicle}
            {pos ? ` · ${TIRE_GROUP_LABEL[pos.group]} · lado ${pos.side}` : ""}
          </div>
        </div>
        {status && <span className={`tire-badge b-${status}`}>{statusLabel}</span>}
      </div>

      <div className="tire-ids">
        <div className="tire-id">
          <span>Identificação (fogo)</span>
          <b>{tireId.fogo || "—"}</b>
        </div>
        <div className="tire-id">
          <span>Marca</span>
          <b>{tireId.marca || "—"}</b>
        </div>
        <div className="tire-id">
          <span>Posição atual</span>
          <b>Pneu {position}</b>
        </div>
        <div className="tire-id">
          <span>Situação registrada</span>
          <b>{statusLabel || "—"}</b>
        </div>
      </div>

      <div className="tire-situacao">
        <span className="tire-situacao-title">
          <i className="ri-edit-2-line" aria-hidden="true" /> Situação do pneu (editável)
        </span>
        <div className="tire-situacao-opts" role="radiogroup" aria-label={`Situação do pneu ${position}`}>
          {EDITABLE_TIRE_STATUS_META.map((m) => (
            <button
              key={m.id}
              type="button"
              role="radio"
              aria-checked={status === m.id}
              className={`tire-situacao-opt${status === m.id ? " is-active" : ""}`}
              title={m.hint}
              onClick={() => onSetSituacao(m.id as EditableTireStatus)}
            >
              <span className={`dot dot-${m.id}`} aria-hidden="true" />
              {m.label}
            </button>
          ))}
        </div>
        <p className="tire-situacao-hint">
          <i className="ri-information-line" aria-hidden="true" /> A situação escolhida recolore o mapa
          e é gravada no banco ao clicar em “Salvar Dados”.
        </p>
      </div>

      <div className="tirehistory">
        <span className="tirehistory-title">
          <i className="ri-history-line" aria-hidden="true" /> Histórico registrado
          {events.length > 0 ? ` · ${events.length}` : ""}
        </span>

        {events.length === 0 ? (
          <p className="tirehistory-empty">
            <i className="ri-information-line" aria-hidden="true" /> Nenhum histórico registrado.
          </p>
        ) : (
          <ul className="tirehistory-list">
            {events.map((e) => (
              <li key={e.key} className={`tire-event k-${e.kind}`}>
                <div className="tire-event-top">
                  <span className="tire-event-kind">
                    <i className={TIRE_EVENT_ICON[e.kind]} aria-hidden="true" /> {TIRE_EVENT_LABEL[e.kind]}
                  </span>
                  <span className="tire-event-date">{fmtEventDate(e.date)}</span>
                </div>
                <div className="tire-event-meta">
                  <span>
                    OS/Registro: <b>{e.osNumero || "—"}</b>
                  </span>
                  {e.fogo && (
                    <span>
                      Fogo: <b>{e.fogo}</b>
                    </span>
                  )}
                  {e.marca && (
                    <span>
                      Marca: <b>{e.marca}</b>
                    </span>
                  )}
                  {e.mm && (
                    <span>
                      MM: <b>{e.mm}</b>
                    </span>
                  )}
                  {e.vidas && (
                    <span>
                      Vidas: <b>{e.vidas}</b>
                    </span>
                  )}
                  {e.motivo && (
                    <span>
                      Motivo: <b>{e.motivo}</b>
                    </span>
                  )}
                </div>
                {e.obs && <p className="tire-event-note">{e.obs}</p>}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}