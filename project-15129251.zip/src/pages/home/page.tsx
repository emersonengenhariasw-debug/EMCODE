import { useRef } from "react";
import SiteNav from "@/pages/home/components/SiteNav";
import HeroCarousel from "@/pages/home/components/HeroCarousel";
import SitePanels from "@/pages/home/components/SitePanels";
import OsForm from "@/pages/home/components/OsForm";
import SiteFooter from "@/pages/home/components/SiteFooter";
import InstallApp from "@/components/feature/InstallApp";
import { useChapterFilm } from "@/hooks/useChapterFilm";
import { usePanelMotion } from "@/hooks/usePanelMotion";

export default function Home() {
  const rootRef = useRef<HTMLDivElement>(null);
  useChapterFilm(rootRef);
  usePanelMotion();

  return (
    <div ref={rootRef} id="top">
      <SiteNav />
      <main>
        <h1 className="sr-only">
          OS - Movimentação de Pneu — July Quartzo Mineração e Construção
        </h1>
        <HeroCarousel />
        <SitePanels />
        <OsForm />
      </main>
      <SiteFooter />
      <InstallApp />
    </div>
  );
}