import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import InstallGuide from "@/components/feature/InstallGuide";
import { useInstallPrompt } from "@/hooks/useInstallPrompt";
import { usePwaReadiness } from "@/hooks/usePwaReadiness";
import InstallTopBar from "@/pages/install/components/InstallTopBar";
import InstallHero from "@/pages/install/components/InstallHero";
import ScreenshotGallery from "@/pages/install/components/ScreenshotGallery";
import FeatureGrid from "@/pages/install/components/FeatureGrid";
import InstallSteps from "@/pages/install/components/InstallSteps";
import InstallReadiness from "@/pages/install/components/InstallReadiness";
import {
  APP_SCREENSHOTS,
  INSTALL_FALLBACK_LINK,
} from "@/pages/install/installContent";

export default function InstallPage() {
  const { canPrompt, alreadyInstalled, platform, promptInstall } = useInstallPrompt();
  const checks = usePwaReadiness(canPrompt);

  const [guideOpen, setGuideOpen] = useState(false);
  const [working, setWorking] = useState(false);
  const [done, setDone] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [lightbox, setLightbox] = useState<number | null>(null);

  const shareLink = useMemo(() => {
    if (typeof window === "undefined") return INSTALL_FALLBACK_LINK;
    const base = (import.meta.env.BASE_URL || "/").replace(/\/+$/, "");
    return `${window.location.origin}${base}/instalar`;
  }, []);

  const showToast = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 2800);
  }, []);

  const handleInstall = useCallback(async () => {
    if (working || alreadyInstalled) return;

    /* Sem instalação direta: a ação real e compatível é abrir as instruções
       do navegador/aparelho em uso — nunca um botão decorativo. */
    if (!canPrompt) {
      setGuideOpen(true);
      return;
    }

    setWorking(true);
    const outcome = await promptInstall();
    setWorking(false);

    if (outcome === "accepted") {
      setDone(true);
      return;
    }
    if (outcome === "dismissed") {
      setGuideOpen(true);
    }
  }, [alreadyInstalled, canPrompt, promptInstall, working]);

  const handleWhatsAppShare = () => {
    const text = `Instale o aplicativo da JULY QUARTZO — Borracharia Digital: ${shareLink}`;
    window.open(
      `https://wa.me/?text=${encodeURIComponent(text)}`,
      "_blank",
      "noopener,noreferrer",
    );
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareLink);
      showToast("Link de instalação copiado!");
    } catch {
      showToast(`Copie o endereço: ${shareLink}`);
    }
  };

  useEffect(() => {
    if (lightbox === null) return undefined;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setLightbox(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightbox]);

  return (
    <div className="install-store">
      <InstallTopBar onInstall={handleInstall} busy={working} installed={alreadyInstalled} />

      <main>
        <InstallHero
          canPrompt={canPrompt}
          alreadyInstalled={alreadyInstalled}
          working={working}
          done={done}
          onInstall={handleInstall}
        />

        <ScreenshotGallery onOpen={setLightbox} />

        <FeatureGrid />

        <InstallSteps platform={platform} canPrompt={canPrompt} onInstall={handleInstall} />

        <InstallReadiness checks={checks} />

        <section className="st-section is-tight" aria-labelledby="st-share-title">
          <div className="st-share">
            <div className="st-share-text">
              <h3 id="st-share-title">Instale também no aparelho da equipe</h3>
              <p>
                Envie este endereço para o celular ou tablet usado em campo. Cada pessoa instala
                pelo próprio navegador, sem depender de um arquivo ou de uma loja.
              </p>
            </div>
            <div className="st-share-actions">
              <button type="button" className="st-share-btn is-solid" onClick={handleWhatsAppShare}>
                <i className="ri-whatsapp-line" aria-hidden="true" /> Enviar no WhatsApp
              </button>
              <button type="button" className="st-share-btn" onClick={handleCopyLink}>
                <i className="ri-link" aria-hidden="true" /> Copiar link
              </button>
              <Link to="/" className="st-share-btn">
                <i className="ri-apps-2-line" aria-hidden="true" /> Abrir agora
              </Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="st-footer">
        <div className="st-footer-inner">
          <span className="st-footer-brand">
            <i className="ri-building-2-line" aria-hidden="true" />
            JULY QUARTZO — Mineração e Construção · Borracharia Digital
          </span>
          <span className="st-footer-links">
            <a href="https://wa.me/5574991181066" target="_blank" rel="noopener noreferrer">
              <i className="ri-whatsapp-line" aria-hidden="true" /> (74) 99118-1066
            </a>
            <span className="st-footer-sep" aria-hidden="true" />
            <a href="mailto:emersongestaoti@gmail.com">
              <i className="ri-mail-line" aria-hidden="true" /> emersongestaoti@gmail.com
            </a>
            <span className="st-footer-sep" aria-hidden="true" />
            <span>© 2026 — Desenvolvido por Emerson Silva</span>
          </span>
        </div>
      </footer>

      {guideOpen && (
        <InstallGuide
          onClose={() => setGuideOpen(false)}
          hasNativePrompt={canPrompt}
          platform={platform}
        />
      )}

      {lightbox !== null && (
        <div
          className="st-lightbox"
          role="dialog"
          aria-modal="true"
          aria-label="Imagem ampliada do aplicativo"
          onClick={() => setLightbox(null)}
        >
          <button
            type="button"
            className="st-lightbox-close"
            aria-label="Fechar imagem"
            onClick={() => setLightbox(null)}
          >
            <i className="ri-close-line" aria-hidden="true" />
          </button>
          <img
            src={APP_SCREENSHOTS[lightbox]?.src}
            alt={APP_SCREENSHOTS[lightbox]?.caption}
            onClick={(event) => event.stopPropagation()}
          />
        </div>
      )}

      {toast && (
        <div className="st-toast" role="status" aria-live="polite">
          {toast}
        </div>
      )}
    </div>
  );
}