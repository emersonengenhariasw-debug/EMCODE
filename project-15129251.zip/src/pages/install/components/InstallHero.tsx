import { APP_ICON, APP_META } from "@/pages/install/installContent";

type Props = {
  canPrompt: boolean;
  alreadyInstalled: boolean;
  working: boolean;
  done: boolean;
  onInstall: () => void;
};

export default function InstallHero({
  canPrompt,
  alreadyInstalled,
  working,
  done,
  onInstall,
}: Props) {
  return (
    <section className="st-hero" aria-labelledby="st-hero-title">
      <div className="st-hero-inner">
        <div className="st-hero-copy">
          <span className="st-eyebrow">
            <i className="ri-smartphone-line" aria-hidden="true" />
            Aplicativo da operação
          </span>

          <h1 id="st-hero-title">
            Borracharia Digital
            <em>na tela inicial do seu aparelho</em>
          </h1>

          <p className="st-hero-sub">
            Instale o aplicativo da JULY QUARTZO — Mineração e Construção e abra as ordens de
            serviço, o controle e a movimentação de pneus em tela cheia, como um aplicativo
            comum. Sem baixar arquivo e sem passar por loja de aplicativos.
          </p>

          <div className="st-hero-tags">
            <span className="st-hero-tag">
              <i className="ri-check-line" aria-hidden="true" /> Instalação pelo navegador
            </span>
            <span className="st-hero-tag">
              <i className="ri-shield-check-line" aria-hidden="true" /> Conexão HTTPS
            </span>
            <span className="st-hero-tag">
              <i className="ri-device-line" aria-hidden="true" /> Celular, tablet e computador
            </span>
          </div>

          <div className="st-hero-actions">
            {alreadyInstalled ? (
              <div className="st-installed-box" role="status" aria-live="polite">
                <i className="ri-checkbox-circle-fill" aria-hidden="true" />
                <span>
                  <b>APLICATIVO JÁ INSTALADO</b>
                  <span>Abra o sistema pelo ícone da tela inicial. Se quiser reinstalar, remova o ícone e repita os passos.</span>
                </span>
              </div>
            ) : (
              <button
                type="button"
                className="st-install-btn"
                onClick={onInstall}
                disabled={working}
              >
                <i className="ri-download-2-line" aria-hidden="true" />
                {working ? "ABRINDO INSTALAÇÃO..." : "INSTALAR APP JQZ"}
              </button>
            )}

            {!alreadyInstalled && (
              <span className={`st-install-state${canPrompt ? " is-ready" : ""}`}>
                <i className={canPrompt ? "ri-flashlight-line" : "ri-information-line"} aria-hidden="true" />
                {canPrompt
                  ? "Instalação direta disponível: o navegador vai pedir sua confirmação."
                  : "Vamos abrir as instruções do seu navegador para concluir a instalação."}
              </span>
            )}

            {done && (
              <span className="st-install-state is-ready" role="status" aria-live="polite">
                <i className="ri-check-double-line" aria-hidden="true" />
                Instalação confirmada. O ícone da JULY QUARTZO já está na tela inicial.
              </span>
            )}
          </div>
        </div>

        <aside className="st-appcard" aria-label="Informações do aplicativo">
          <div className="st-appcard-top">
            <span className="st-appcard-icon">
              <img src={APP_ICON} alt="Ícone do aplicativo Borracharia Digital" />
            </span>
            <span className="st-appcard-title">
              <b>Borracharia Digital</b>
              <span>JULY QUARTZO</span>
              <em>Mineração e Construção</em>
            </span>
          </div>

          <dl className="st-appcard-meta">
            {APP_META.map((item) => (
              <div className="st-metarow" key={item.label}>
                <dt>{item.label}</dt>
                <dd>{item.value}</dd>
              </div>
            ))}
          </dl>

          <p className="st-appcard-note">
            <i className="ri-information-line" aria-hidden="true" />
            Este é o aplicativo oficial da equipe, disponível neste endereço. Não é distribuído
            pela Google Play Store.
          </p>
        </aside>
      </div>
    </section>
  );
}