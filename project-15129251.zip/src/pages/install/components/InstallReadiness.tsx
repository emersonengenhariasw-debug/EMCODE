import type { ReadinessCheck } from "@/hooks/usePwaReadiness";
import { TRANSPARENCY } from "@/pages/install/installContent";

type Props = {
  checks: ReadinessCheck[];
};

function iconFor(ok: boolean | null) {
  if (ok === null) return { className: "is-waiting", icon: "ri-loader-4-line" };
  return ok
    ? { className: "is-ok", icon: "ri-check-line" }
    : { className: "is-pending", icon: "ri-information-line" };
}

export default function InstallReadiness({ checks }: Props) {
  return (
    <section className="st-section" aria-labelledby="st-ready-title">
      <div className="st-section-head">
        <span className="st-kicker">
          <i className="ri-pulse-line" aria-hidden="true" /> Verificação agora
        </span>
        <h2 className="st-h2" id="st-ready-title">O que o seu navegador confirmou</h2>
        <p className="st-sub">
          Estas checagens são feitas neste exato momento, no aparelho em que você está. É assim que
          sabemos se a instalação direta pode aparecer.
        </p>
      </div>

      <div className="st-ready">
        <div className="st-card">
          <ul className="st-check-list">
            {checks.map((check) => {
              const state = iconFor(check.ok);
              return (
                <li className="st-check" key={check.id}>
                  <span className={`st-check-ico ${state.className}`}>
                    <i className={state.icon} aria-hidden="true" />
                  </span>
                  <span className="st-check-text">
                    <b>{check.label}</b>
                    <span>{check.detail}</span>
                  </span>
                </li>
              );
            })}
          </ul>

          <p className="st-ready-note" style={{ marginTop: 14 }}>
            <i className="ri-refresh-line" aria-hidden="true" />
            Se alguma verificação ficar pendente, recarregue esta página e aguarde alguns segundos.
            A instalação direta depende do navegador, e não de um botão alternativo.
          </p>
        </div>

        <div className="st-honest">
          {TRANSPARENCY.map((item) => (
            <div className="st-honest-item" key={item.title}>
              <i className={item.icon} aria-hidden="true" />
              <span>
                <b>{item.title}</b>
                <span>{item.text}</span>
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}