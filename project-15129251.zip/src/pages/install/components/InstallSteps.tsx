import { useState } from "react";
import type { InstallPlatform } from "@/components/feature/InstallGuide";
import { PLATFORM_GUIDES, type PlatformKey } from "@/pages/install/installContent";

type Props = {
  platform: InstallPlatform;
  canPrompt: boolean;
  onInstall: () => void;
};

function initialTab(platform: InstallPlatform): PlatformKey {
  if (platform === "ios") return "ios";
  if (platform === "desktop") return "desktop";
  return "android";
}

export default function InstallSteps({ platform, canPrompt, onInstall }: Props) {
  const [tab, setTab] = useState<PlatformKey>(() => initialTab(platform));
  const guide = PLATFORM_GUIDES.find((item) => item.key === tab) ?? PLATFORM_GUIDES[0];

  return (
    <section className="st-section" aria-labelledby="st-steps-title">
      <div className="st-section-head">
        <span className="st-kicker">
          <i className="ri-list-ordered" aria-hidden="true" /> Passo a passo
        </span>
        <h2 className="st-h2" id="st-steps-title">Como instalar no seu aparelho</h2>
        <p className="st-sub">
          Escolha o aparelho que você está usando. O processo é rápido e não pede nenhum arquivo.
        </p>
      </div>

      <div className="st-steps-layout">
        <div className="st-card">
          <div className="st-tabs" role="tablist" aria-label="Escolha o aparelho">
            {PLATFORM_GUIDES.map((item) => (
              <button
                key={item.key}
                type="button"
                role="tab"
                aria-selected={tab === item.key}
                className={`st-tab${tab === item.key ? " is-on" : ""}`}
                onClick={() => setTab(item.key)}
              >
                <i className={item.icon} aria-hidden="true" />
                <span>{item.label}</span>
              </button>
            ))}
          </div>

          <p className="st-sub" style={{ marginBottom: 14 }}>{guide.intro}</p>

          <ol className="st-steplist">
            {guide.steps.map((step, index) => (
              <li className="st-step" key={step.title}>
                <span className="st-step-num" aria-hidden="true">{index + 1}</span>
                <span className="st-step-text">
                  <b>{step.title}</b>
                  {step.detail}
                </span>
              </li>
            ))}
          </ol>

          <p className="st-steps-note">
            <i className="ri-lightbulb-line" aria-hidden="true" />
            {guide.note}
          </p>
        </div>

        <div className="st-card">
          <span className="st-limit-title">
            <i className="ri-shield-check-line" aria-hidden="true" />
            Antes de instalar
          </span>
          <ul className="st-limit-list">
            <li>
              <i className="ri-check-line" aria-hidden="true" />
              <span>
                Use um navegador atualizado: Chrome, Edge ou Samsung Internet no Android; Safari no
                iPhone e no iPad.
              </span>
            </li>
            <li>
              <i className="ri-check-line" aria-hidden="true" />
              <span>
                A instalação direta só aparece quando o navegador conclui a preparação do
                aplicativo. Se o botão não abrir a janela, use os passos ao lado.
              </span>
            </li>
            <li>
              <i className="ri-check-line" aria-hidden="true" />
              <span>
                Abriu este link dentro do WhatsApp ou do Instagram? Toque em “Abrir no navegador”
                antes de instalar.
              </span>
            </li>
            <li>
              <i className="ri-check-line" aria-hidden="true" />
              <span>
                Nada é baixado e nenhuma permissão especial é pedida. O aplicativo é o próprio
                sistema, guardado na tela inicial.
              </span>
            </li>
          </ul>

          {!canPrompt && (
            <button
              type="button"
              className="st-retry-btn"
              onClick={onInstall}
            >
              <i className="ri-refresh-line" aria-hidden="true" />
              Tentar novamente
            </button>
          )}
        </div>
      </div>
    </section>
  );
}