import { APP_FEATURES } from "@/pages/install/installContent";

export default function FeatureGrid() {
  return (
    <section className="st-section" aria-labelledby="st-features-title">
      <div className="st-section-head">
        <span className="st-kicker">
          <i className="ri-stack-line" aria-hidden="true" /> O que está dentro
        </span>
        <h2 className="st-h2" id="st-features-title">Funções que já fazem parte da rotina</h2>
        <p className="st-sub">
          Tudo o que a oficina usa hoje continua igual — a instalação apenas coloca o sistema a um
          toque de distância na tela inicial.
        </p>
      </div>

      <div className="st-features">
        {APP_FEATURES.map((feature) => (
          <article className="st-feature" key={feature.title}>
            <span className="st-feature-ico">
              <i className={feature.icon} aria-hidden="true" />
            </span>
            <b>{feature.title}</b>
            <p>{feature.text}</p>
          </article>
        ))}
      </div>
    </section>
  );
}