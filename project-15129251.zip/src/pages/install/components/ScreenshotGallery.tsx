import { APP_SCREENSHOTS } from "@/pages/install/installContent";

type Props = {
  onOpen: (index: number) => void;
};

export default function ScreenshotGallery({ onOpen }: Props) {
  return (
    <section className="st-section" aria-labelledby="st-shots-title">
      <div className="st-section-head">
        <span className="st-kicker">
          <i className="ri-image-line" aria-hidden="true" /> Por dentro do aplicativo
        </span>
        <h2 className="st-h2" id="st-shots-title">O sistema que a equipe já usa</h2>
        <p className="st-sub">
          Telas reais do sistema: a Ordem de Serviço de movimentação de pneu e o desenho das dez
          posições do caminhão.
        </p>
      </div>

      <div className="st-shots">
        {APP_SCREENSHOTS.map((shot, index) => (
          <button
            type="button"
            className="st-shot"
            key={shot.src}
            onClick={() => onOpen(index)}
            aria-label={`Ampliar imagem: ${shot.caption}`}
          >
            <span className="st-shot-frame">
              <img src={shot.src} alt={shot.caption} title={shot.caption} />
            </span>
            <span className="st-shot-caption">{shot.caption}</span>
          </button>
        ))}
      </div>

      <p className="st-shots-hint">
        <i className="ri-zoom-in-line" aria-hidden="true" /> Toque em uma imagem para ampliar
      </p>
    </section>
  );
}