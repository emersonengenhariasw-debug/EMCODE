import { Link } from "react-router-dom";
import { APP_ICON } from "@/pages/install/installContent";

type Props = {
  onInstall: () => void;
  busy: boolean;
  installed: boolean;
};

export default function InstallTopBar({ onInstall, busy, installed }: Props) {
  return (
    <header className="st-top">
      <div className="st-top-inner">
        <Link to="/" className="st-top-brand" aria-label="JULY QUARTZO — Borracharia Digital, início">
          <span className="st-top-icon">
            <img src={APP_ICON} alt="Ícone do aplicativo Borracharia Digital" />
          </span>
          <span className="st-top-names">
            <b>Borracharia Digital</b>
            <span>JULY QUARTZO</span>
          </span>
        </Link>

        <div className="st-top-actions">
          <Link to="/" className="st-top-link">
            <i className="ri-arrow-left-line" aria-hidden="true" />
            <span>Abrir sistema</span>
          </Link>
          <button
            type="button"
            className="st-top-install"
            onClick={onInstall}
            disabled={busy || installed}
          >
            <i className="ri-download-2-line" aria-hidden="true" />
            <span>{installed ? "Instalado" : "Instalar app"}</span>
          </button>
        </div>
      </div>
    </header>
  );
}