/* Conteúdo da página de instalação da PWA Borracharia Digital.
   Nenhuma informação de loja de aplicativos, APK ou versão é inventada aqui:
   só o que o próprio projeto oferece. */

export const APP_ICON =
  "https://storage.helloreaddy.io/project_files/bcb5d80a-7036-4efe-bafb-918772b3505c/32c7e022-3ff2-4dad-863a-1fc280857a4c_compressed_icon-512.webp";

export const INSTALL_FALLBACK_LINK = "https://jqzborrachariadigital.online/instalar";

export type AppMeta = { label: string; value: string };

export const APP_META: AppMeta[] = [
  { label: "Tipo", value: "Aplicativo web (PWA)" },
  { label: "Instalação", value: "Pelo navegador, sem loja" },
  { label: "Download", value: "Nenhum arquivo APK" },
  { label: "Plataformas", value: "Android · iPhone/iPad · PC" },
];

export type AppFeature = { icon: string; title: string; text: string };

export const APP_FEATURES: AppFeature[] = [
  {
    icon: "ri-file-list-3-line",
    title: "Ordem de Serviço completa",
    text: "Preencha, finalize e salve a OS de movimentação de pneu direto no tablet, celular ou computador.",
  },
  {
    icon: "ri-roadster-line",
    title: "Controle de pneus",
    text: "As dez posições do caminhão com a situação de cada pneu, retiradas, instalações e motivo de cada troca.",
  },
  {
    icon: "ri-history-line",
    title: "Histórico das OS",
    text: "Consulte as ordens já salvas por número, data ou veículo, sem depender de papel na oficina.",
  },
  {
    icon: "ri-bar-chart-box-line",
    title: "Indicadores da frota",
    text: "Acompanhe o volume de movimentações e os motivos mais frequentes em cada período.",
  },
  {
    icon: "ri-alert-line",
    title: "Pneus perdidos",
    text: "Registre ocorrências com fotos, motivo e responsável, mantendo tudo documentado.",
  },
  {
    icon: "ri-file-excel-2-line",
    title: "Exportação de dados",
    text: "Gere planilhas em Excel e arquivos em PDF para arquivar ou enviar à manutenção.",
  },
];

export type Screenshot = { src: string; caption: string };

export const APP_SCREENSHOTS: Screenshot[] = [
  {
    src: "https://readdy.ai/api/search-image?query=Digital%20tire%20service%20order%20form%20interface%20displayed%20on%20a%20tablet%20screen%2C%20clean%20green%20and%20white%20mining%20company%20layout%20with%20data%20tables%2C%20form%20fields%20and%20a%20ten%20position%20truck%20tire%20diagram%2C%20professional%20flat%20UI%20screenshot%2C%20crisp%20readable%20typography%2C%20dark%20green%20accents&width=1280&height=800&seq=jqz-pwa-shot-tablet&orientation=landscape",
    caption: "Ordem de Serviço no tablet — campos, tabelas e as dez posições de pneu.",
  },
  {
    src: "https://readdy.ai/api/search-image?query=Digital%20tire%20service%20order%20form%20interface%20displayed%20on%20a%20smartphone%20screen%2C%20mobile%20responsive%20green%20and%20white%20layout%20with%20stacked%20form%20fields%2C%20numeric%20keypad%20and%20truck%20tire%20diagram%20sections%2C%20professional%20flat%20UI%20screenshot%2C%20clear%20readable%20typography%2C%20dark%20green%20accents&width=720&height=1280&seq=jqz-pwa-shot-mobile&orientation=portrait",
    caption: "No celular: preenchimento rápido em campo, com os mesmos campos.",
  },
];

export type PlatformKey = "android" | "ios" | "desktop";

export type Step = { title: string; detail: string };

export type PlatformGuide = {
  key: PlatformKey;
  label: string;
  icon: string;
  intro: string;
  steps: Step[];
  note: string;
};

export const PLATFORM_GUIDES: PlatformGuide[] = [
  {
    key: "android",
    label: "Android",
    icon: "ri-android-line",
    intro: "No celular ou tablet Android a instalação é feita pelo Google Chrome.",
    steps: [
      { title: "Abra esta página no Chrome", detail: "Use o Google Chrome (ou o Samsung Internet) no aparelho." },
      { title: "Toque em INSTALAR APLICATIVO", detail: "Se a janela do navegador aparecer, confirme em “Instalar”." },
      { title: "Ou use o menu do navegador", detail: "Toque nos três pontos (⋮) e escolha “Instalar aplicativo” ou “Adicionar à tela inicial”." },
      { title: "Confirme o nome JULY QUARTZO", detail: "O ícone aparece na tela inicial e abre o sistema em tela cheia." },
    ],
    note: "A opção de instalação aparece quando o navegador termina de preparar o aplicativo — se ainda não apareceu, recarregue a página uma vez.",
  },
  {
    key: "ios",
    label: "iPhone / iPad",
    icon: "ri-apple-line",
    intro: "No iPhone e no iPad a instalação é feita pelo Safari.",
    steps: [
      { title: "Abra esta página no Safari", detail: "O Chrome e outros navegadores no iOS não instalam aplicativos na tela inicial." },
      { title: "Toque em Compartilhar", detail: "Ícone do quadrado com a seta para cima, na barra do navegador." },
      { title: "Escolha “Adicionar à Tela de Início”", detail: "Role a lista de opções até encontrar esse item." },
      { title: "Toque em Adicionar", detail: "O ícone JULY QUARTZO passa a abrir o sistema em tela cheia." },
    ],
    note: "No iOS a instalação é sempre manual: não existe janela automática de instalação como no Android.",
  },
  {
    key: "desktop",
    label: "Computador",
    icon: "ri-computer-line",
    intro: "No computador a instalação cria um atalho em janela própria, sem barras do navegador.",
    steps: [
      { title: "Abra no Chrome ou Edge", detail: "Navegadores atualizados no Windows, macOS ou Linux." },
      { title: "Clique no ícone de instalação", detail: "Ele aparece na barra de endereço — uma telinha com uma seta para baixo." },
      { title: "Confirme em “Instalar”", detail: "Ou use o menu do navegador em “Salvar e compartilhar → Instalar”." },
      { title: "Abra pelo atalho criado", detail: "O atalho fica na área de trabalho ou no menu iniciar." },
    ],
    note: "Se o ícone de instalação não aparecer, use o menu do navegador ou continue acessando pelo endereço normal — todas as funções são as mesmas.",
  },
];

export const TRANSPARENCY = [
  {
    icon: "ri-global-line",
    title: "É o site oficial, salvo no aparelho",
    text: "O aplicativo é o próprio sistema da Borracharia Digital, mantido no endereço jqzborrachariadigital.online.",
  },
  {
    icon: "ri-shield-keyhole-line",
    title: "Não é distribuído por loja de aplicativos",
    text: "Não existe publicação na Google Play Store. Este endereço é o canal oficial de instalação da equipe.",
  },
  {
    icon: "ri-download-cloud-line",
    title: "Nenhum APK é baixado",
    text: "Não é necessário baixar arquivo, liberar fontes desconhecidas ou desativar proteções do aparelho.",
  },
];