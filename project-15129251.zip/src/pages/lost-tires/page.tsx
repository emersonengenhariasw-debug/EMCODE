import { useCallback, useEffect, useMemo, useState } from "react";
import type { LostPhoto, LostTireRecord, PhotoDraft } from "@/lib/lostTiresTypes";
import {
  createEmptyLost,
  LOST_MOTIVES,
  LOST_OTHER_LABEL,
  LOST_POSITION_OPTIONS,
  LOST_TURMA_OPTIONS,
} from "@/mocks/lostTires";
import {
  deleteLostTire,
  listLostTires,
  saveLostTire,
  signLostPhoto,
  uploadLostPhoto,
} from "@/lib/lostTiresDb";
import { exportLostTiresExcel } from "@/lib/lostTiresExport";
import LostNav from "@/pages/lost-tires/components/LostNav";
import LostPhotoField from "@/pages/lost-tires/components/LostPhotoField";
import LostRecords from "@/pages/lost-tires/components/LostRecords";
import LostIndicators from "@/pages/lost-tires/components/LostIndicators";

type Status = { type: "ok" | "err"; text: string } | null;

const PHOTO_REQUIRED_MSG =
  "OBRIGATÓRIO ANEXAR FOTO DO PNEU PERDIDO PARA FINALIZAR O REGISTRO.";

/** Próximo Nº de registro (PP-0001…) — numeração própria, sem relação com as OS. */
function nextRegistro(records: LostTireRecord[]): string {
  let max = 0;
  records.forEach((r) => {
    const m = /PP-(\d+)/i.exec(r.registro);
    const n = m ? parseInt(m[1], 10) : parseInt(String(r.registro).replace(/\D/g, ""), 10);
    if (!Number.isNaN(n) && n > max) max = n;
  });
  return `PP-${String(max + 1).padStart(4, "0")}`;
}

/** Sobe as fotos pendentes e devolve a lista pronta para gravar no registro. */
async function ensureUploaded(drafts: PhotoDraft[], registro: string): Promise<LostPhoto[]> {
  const out: LostPhoto[] = [];
  for (const d of drafts) {
    if (d.path) {
      out.push({ id: d.id, path: d.path, name: d.name, uploadedAt: d.uploadedAt });
    } else if (d.file) {
      const up = await uploadLostPhoto(registro, d.file);
      out.push({ id: d.id, path: up.path, name: d.name, uploadedAt: up.uploadedAt });
    }
  }
  return out;
}

export default function LostTiresPage() {
  const [form, setForm] = useState(createEmptyLost);
  const [fotos, setFotos] = useState<PhotoDraft[]>([]);
  const [records, setRecords] = useState<LostTireRecord[]>([]);
  const [status, setStatus] = useState<Status>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<"historico" | "indicadores">("historico");
  const [lightbox, setLightbox] = useState<{ urls: string[]; index: number; title: string } | null>(null);

  const patch = useCallback((p: Partial<ReturnType<typeof createEmptyLost>>) => {
    setForm((prev) => ({ ...prev, ...p }));
  }, []);

  const refresh = useCallback(async () => {
    const list = await listLostTires();
    setRecords(list);
    return list;
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const list = await listLostTires();
        if (!active) return;
        setRecords(list);
        setForm((prev) => (prev.registro ? prev : { ...prev, registro: nextRegistro(list) }));
        setLoadError(null);
      } catch {
        if (active) setLoadError("Não foi possível carregar os registros. Verifique a conexão.");
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  /* ------------------------------------------------------------- fotos */

  const addPhotos = useCallback((files: File[]) => {
    const drafts: PhotoDraft[] = files
      .filter((f) => f.type.startsWith("image/"))
      .map((f) => ({
        id: `local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        name: f.name,
        file: f,
        previewUrl: URL.createObjectURL(f),
      }));
    if (drafts.length) setFotos((prev) => [...prev, ...drafts]);
  }, []);

  const removePhoto = useCallback((id: string) => {
    setFotos((prev) => prev.filter((f) => f.id !== id));
  }, []);

  /* ------------------------------------------------------------- salvar */

  const validate = useCallback(
    (finalize: boolean): string | null => {
      if (!finalize) return null;
      if (fotos.length === 0) return PHOTO_REQUIRED_MSG;
      if (!form.dataOcorrencia) return "Informe a DATA DA OCORRÊNCIA para finalizar o registro.";
      if (!form.operador.trim()) return "Informe o NOME DO OPERADOR para finalizar o registro.";
      if (!form.equipamento.trim()) return "Informe o EQUIPAMENTO / PREFIXO para finalizar o registro.";
      if (!form.posicao) return "Informe a POSIÇÃO DO PNEU para finalizar o registro.";
      if (!form.motivo) return "Selecione o MOTIVO DA PERDA para finalizar o registro.";
      if (form.motivo === LOST_OTHER_LABEL && !form.motivoOutros.trim()) {
        return "Quando o motivo for OUTROS, é obrigatório descrever a causa.";
      }
      if (!form.descricao.trim()) return "Descreva a OCORRÊNCIA para finalizar o registro.";
      return null;
    },
    [fotos, form],
  );

  const persist = useCallback(
    async (finalize: boolean) => {
      const msg = validate(finalize);
      if (msg) {
        setStatus({ type: "err", text: msg });
        return;
      }
      const registro = form.registro.trim();
      if (!registro) {
        setStatus({ type: "err", text: "Número do registro não gerado. Clique em NOVO REGISTRO." });
        return;
      }
      setBusy(true);
      try {
        const uploaded = await ensureUploaded(fotos, registro);
        setFotos((prev) =>
          prev.map((p, i) => ({
            ...p,
            path: uploaded[i]?.path ?? p.path,
            uploadedAt: uploaded[i]?.uploadedAt ?? p.uploadedAt,
          })),
        );
        const existing = records.find((r) => r.registro === registro);
        const record: LostTireRecord = {
          ...form,
          registro,
          id: registro,
          fotos: uploaded,
          status: finalize ? "finalizado" : "rascunho",
          createdAt: existing?.createdAt ?? new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await saveLostTire(record);
        await refresh();
        setStatus({
          type: "ok",
          text: finalize
            ? `Registro ${registro} FINALIZADO e salvo. Ele já aparece no histórico e na planilha.`
            : `Rascunho do registro ${registro} salvo. Você pode completar e finalizar depois.`,
        });
        if (finalize) setTab("historico");
      } catch {
        setStatus({
          type: "err",
          text: "Não foi possível salvar agora. Os dados continuam na tela — tente novamente.",
        });
      } finally {
        setBusy(false);
      }
    },
    [fotos, form, records, refresh, validate],
  );

  const handleNewRegistro = useCallback(() => {
    setForm({ ...createEmptyLost(), registro: nextRegistro(records) });
    setFotos([]);
    setStatus({ type: "ok", text: "Novo registro em branco. O número já está na sequência (PP-…)." });
    document.getElementById("lost-form")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [records]);

  const handleLoad = useCallback(async (record: LostTireRecord) => {
    setForm({
      ...createEmptyLost(),
      registro: record.registro,
      dataOcorrencia: record.dataOcorrencia,
      operador: record.operador,
      equipamento: record.equipamento,
      posicao: record.posicao,
      marca: record.marca,
      fogo: record.fogo,
      mm: record.mm,
      horimetro: record.horimetro,
      local: record.local,
      turma: record.turma,
      motivo: record.motivo,
      motivoOutros: record.motivoOutros,
      descricao: record.descricao,
      responsavel: record.responsavel,
      observacoes: record.observacoes,
    });
    const drafts: PhotoDraft[] = [];
    for (const f of record.fotos) {
      const url = f.path ? await signLostPhoto(f.path) : "";
      if (url) drafts.push({ ...f, previewUrl: url });
    }
    setFotos(drafts);
    setStatus({ type: "ok", text: `Registro ${record.registro} recuperado no formulário.` });
    document.getElementById("lost-form")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []);

  const handleDelete = useCallback(
    async (id: string) => {
      try {
        await deleteLostTire(id);
        await refresh();
        setStatus({ type: "ok", text: "Registro removido." });
      } catch {
        setStatus({ type: "err", text: "Não foi possível remover o registro." });
      }
    },
    [refresh],
  );

  const handleViewPhotos = useCallback(async (record: LostTireRecord) => {
    const urls: string[] = [];
    for (const f of record.fotos) {
      const url = f.path ? await signLostPhoto(f.path) : "";
      if (url) urls.push(url);
    }
    if (!urls.length) {
      setStatus({ type: "err", text: "Não foi possível abrir as fotos deste registro." });
      return;
    }
    setLightbox({ urls, index: 0, title: `Registro ${record.registro}` });
  }, []);

  const handleExcel = useCallback(async () => {
    const total = records.filter((r) => r.status === "finalizado").length;
    if (!total) {
      setStatus({
        type: "err",
        text: "Nenhum registro FINALIZADO para exportar. Finalize ao menos um pneu perdido.",
      });
      return;
    }
    try {
      const n = await exportLostTiresExcel(records);
      setStatus({
        type: "ok",
        text: `Planilha CONTROLE_DE_PNEUS_PERDIDOS_JULY_QUARTZO.xlsx gerada com ${n} ${
          n === 1 ? "registro" : "registros"
        } finalizados.`,
      });
    } catch {
      setStatus({ type: "err", text: "Não foi possível gerar a planilha neste dispositivo." });
    }
  }, [records]);

  const handleConsultar = useCallback(() => {
    setTab("historico");
    document.getElementById("lost-historico")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []);

  const openLightbox = useCallback((urls: string[], index: number, title: string) => {
    const clean = urls.filter(Boolean);
    if (!clean.length) return;
    setLightbox({ urls: clean, index: Math.min(index, clean.length - 1), title });
  }, []);

  const finalizedCount = useMemo(
    () => records.filter((r) => r.status === "finalizado").length,
    [records],
  );

  return (
    <div id="lost-top">
      <LostNav />

      <main className="lost-section" aria-label="Painel de Pneus Perdidos">
        <h1 className="sr-only">Painel de Pneus Perdidos — July Quartzo Mineração e Construção</h1>

        <header className="lost-hero">
          <span className="lost-hero-tag">
            <i className="ri-alert-line" aria-hidden="true" /> Painel independente das OS
          </span>
          <h2>Painel de Pneus Perdidos</h2>
          <p>
            Checklist exclusivo para registrar cada pneu perdido, com data, operador, motivo e
            fotos obrigatórias. Histórico, planilha e indicadores ficam totalmente separados do
            sistema de OS — Movimentação de Pneus.
          </p>
        </header>

        <div className="os-paper" id="lost-form">
          <header className="os-head">
            <div className="os-brand">
              <b>JULY QUARTZO</b>
              <span>Mineração e Construção</span>
            </div>
            <div className="os-title">Pneus Perdidos</div>
            <div className="os-num">
              <label htmlFor="lost-registro">Registro</label>
              <input
                id="lost-registro"
                className="os-input os-num-input"
                value={form.registro}
                readOnly
                aria-label="Número do registro (automático)"
              />
            </div>
          </header>

          <div className="lost-form-grid">
            <div className="os-field">
              <label className="os-label" htmlFor="lost-data">
                Data da Ocorrência <b className="lost-req">*</b>
              </label>
              <input
                id="lost-data"
                type="date"
                className="os-input"
                value={form.dataOcorrencia}
                onChange={(e) => patch({ dataOcorrencia: e.target.value })}
              />
            </div>

            <div className="os-field">
              <label className="os-label" htmlFor="lost-operador">
                Nome do Operador <b className="lost-req">*</b>
              </label>
              <input
                id="lost-operador"
                className="os-input"
                placeholder="Nome de quem operava"
                value={form.operador}
                onChange={(e) => patch({ operador: e.target.value })}
              />
            </div>

            <div className="os-field">
              <label className="os-label" htmlFor="lost-equip">
                Equipamento / Prefixo <b className="lost-req">*</b>
              </label>
              <input
                id="lost-equip"
                className="os-input"
                placeholder="Ex: CB-04 / Escavadeira"
                value={form.equipamento}
                onChange={(e) => patch({ equipamento: e.target.value })}
              />
            </div>

            <div className="os-field">
              <label className="os-label" htmlFor="lost-posicao">
                Posição do Pneu <b className="lost-req">*</b>
              </label>
              <select
                id="lost-posicao"
                className="os-select"
                value={form.posicao}
                onChange={(e) => patch({ posicao: e.target.value })}
              >
                <option value="">Selecionar…</option>
                {LOST_POSITION_OPTIONS.map((o) => (
                  <option key={o} value={o}>{o}</option>
                ))}
              </select>
            </div>

            <div className="os-field">
              <label className="os-label" htmlFor="lost-marca">Marca do Pneu</label>
              <input
                id="lost-marca"
                className="os-input"
                placeholder="Marca"
                value={form.marca}
                onChange={(e) => patch({ marca: e.target.value })}
              />
            </div>

            <div className="os-field">
              <label className="os-label" htmlFor="lost-fogo">Nº de Fogo / Identificação</label>
              <input
                id="lost-fogo"
                className="os-input"
                placeholder="Número de fogo"
                value={form.fogo}
                onChange={(e) => patch({ fogo: e.target.value })}
              />
            </div>

            <div className="os-field">
              <label className="os-label" htmlFor="lost-mm">MM do Pneu</label>
              <input
                id="lost-mm"
                className="os-input"
                inputMode="numeric"
                placeholder="Ex: 42"
                value={form.mm}
                onChange={(e) => patch({ mm: e.target.value })}
              />
            </div>

            <div className="os-field">
              <label className="os-label" htmlFor="lost-horimetro">Horímetro / KM</label>
              <input
                id="lost-horimetro"
                className="os-input"
                placeholder="Ex: 12500"
                value={form.horimetro}
                onChange={(e) => patch({ horimetro: e.target.value })}
              />
            </div>

            <div className="os-field">
              <label className="os-label" htmlFor="lost-local">Local da Ocorrência</label>
              <input
                id="lost-local"
                className="os-input"
                placeholder="Onde aconteceu"
                value={form.local}
                onChange={(e) => patch({ local: e.target.value })}
              />
            </div>

            <div className="os-field">
              <label className="os-label" htmlFor="lost-turma">Turma / Letra</label>
              <select
                id="lost-turma"
                className="os-select"
                value={form.turma}
                onChange={(e) => patch({ turma: e.target.value })}
              >
                <option value="">Selecionar…</option>
                {LOST_TURMA_OPTIONS.map((o) => (
                  <option key={o} value={o}>{o}</option>
                ))}
              </select>
            </div>

            <div className="os-field">
              <label className="os-label" htmlFor="lost-motivo">
                Motivo da Perda <b className="lost-req">*</b>
              </label>
              <select
                id="lost-motivo"
                className="os-select"
                value={form.motivo}
                onChange={(e) => patch({ motivo: e.target.value })}
              >
                <option value="">Selecionar…</option>
                {LOST_MOTIVES.map((o) => (
                  <option key={o} value={o}>{o}</option>
                ))}
              </select>
            </div>

            {form.motivo === LOST_OTHER_LABEL && (
              <div className="os-field span-2">
                <label className="os-label" htmlFor="lost-motivo-outros">
                  Descreva o motivo (OUTROS) <b className="lost-req">*</b>
                </label>
                <input
                  id="lost-motivo-outros"
                  className="os-input"
                  placeholder="Qual foi o motivo da perda?"
                  value={form.motivoOutros}
                  onChange={(e) => patch({ motivoOutros: e.target.value })}
                />
              </div>
            )}

            <div className="os-field span-3">
              <label className="os-label" htmlFor="lost-desc">
                Descrição da Ocorrência <b className="lost-req">*</b>
              </label>
              <textarea
                id="lost-desc"
                className="os-textarea"
                maxLength={500}
                placeholder="Descreva como o pneu foi perdido…"
                value={form.descricao}
                onChange={(e) => patch({ descricao: e.target.value })}
              />
            </div>

            <div className="os-field">
              <label className="os-label" htmlFor="lost-responsavel">Responsável pelo Registro</label>
              <input
                id="lost-responsavel"
                className="os-input"
                placeholder="Quem está lançando"
                value={form.responsavel}
                onChange={(e) => patch({ responsavel: e.target.value })}
              />
            </div>

            <div className="os-field span-2">
              <label className="os-label" htmlFor="lost-obs">Observações Adicionais</label>
              <input
                id="lost-obs"
                className="os-input"
                placeholder="Observações"
                value={form.observacoes}
                onChange={(e) => patch({ observacoes: e.target.value })}
              />
            </div>
          </div>

          <LostPhotoField fotos={fotos} onAdd={addPhotos} onRemove={removePhoto} onZoom={(i) => openLightbox(fotos.map((f) => f.previewUrl), i, "Foto do pneu perdido")} />
        </div>

        <div className="finish">
          <div className="finish-actions">
            <button type="button" className="btn btn-ghost" onClick={handleNewRegistro} disabled={busy}>
              <i className="ri-file-add-line" aria-hidden="true" /> NOVO REGISTRO
            </button>
            <button type="button" className="btn btn-solid" onClick={() => persist(false)} disabled={busy}>
              <i className="ri-draft-line" aria-hidden="true" /> SALVAR RASCUNHO
            </button>
            <button type="button" className="btn btn-primary" onClick={() => persist(true)} disabled={busy}>
              <i className="ri-check-double-line" aria-hidden="true" /> FINALIZAR REGISTRO
            </button>
            <button type="button" className="btn btn-ghost" onClick={handleConsultar}>
              <i className="ri-search-line" aria-hidden="true" /> CONSULTAR REGISTROS
            </button>
            <button type="button" className="btn btn-ghost" onClick={handleExcel}>
              <i className="ri-file-excel-2-line" aria-hidden="true" /> EXPORTAR EXCEL
            </button>
            <button type="button" className="btn btn-ghost" onClick={() => window.print()}>
              <i className="ri-printer-line" aria-hidden="true" /> IMPRIMIR
            </button>
          </div>

          {status && (
            <p
              className="finish-note"
              style={{ color: status.type === "ok" ? "oklch(var(--accent-700))" : "oklch(var(--primary-800))" }}
              role="status"
            >
              {status.text}
            </p>
          )}
        </div>

        <section className="lost-block" id="lost-historico" aria-label="Histórico de pneus perdidos">
          <div className="lost-block-head">
            <div>
              <div className="lost-block-title">Histórico de Pneus Perdidos</div>
              <p className="lost-block-sub">
                {finalizedCount} {finalizedCount === 1 ? "registro finalizado" : "registros finalizados"} ·
                consulte, abra e visualize as fotos. Nenhum registro anterior é apagado ao criar um novo.
              </p>
            </div>
            <div className="lost-tabs" role="tablist" aria-label="Visualização">
              <button
                type="button"
                role="tab"
                aria-selected={tab === "historico"}
                className={`lost-tab${tab === "historico" ? " is-on" : ""}`}
                onClick={() => setTab("historico")}
              >
                <i className="ri-list-check-2" aria-hidden="true" /> Registros
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={tab === "indicadores"}
                className={`lost-tab${tab === "indicadores" ? " is-on" : ""}`}
                onClick={() => setTab("indicadores")}
              >
                <i className="ri-bar-chart-2-line" aria-hidden="true" /> Indicadores
              </button>
            </div>
          </div>

          {loading ? (
            <p className="lost-empty"><i className="ri-loader-4-line" aria-hidden="true" /> Carregando registros…</p>
          ) : loadError ? (
            <p className="lost-empty">
              <i className="ri-error-warning-line" aria-hidden="true" /> {loadError}
            </p>
          ) : tab === "historico" ? (
            <LostRecords
              records={records}
              onLoad={handleLoad}
              onViewPhotos={handleViewPhotos}
              onDelete={handleDelete}
            />
          ) : (
            <LostIndicators records={records} />
          )}
        </section>

        <p className="os-foot-note">
          JULY QUARTZO · MINERAÇÃO E CONSTRUÇÃO — PAINEL DE PNEUS PERDIDOS · registros e numeração
          próprios, separados das OS de movimentação.
        </p>
      </main>

      {lightbox && (
        <div className="lightbox" role="dialog" aria-modal="true" aria-label={lightbox.title} onClick={() => setLightbox(null)}>
          <button type="button" className="lightbox-close" onClick={() => setLightbox(null)} aria-label="Fechar">
            <i className="ri-close-line" aria-hidden="true" />
          </button>
          {lightbox.urls.length > 1 && (
            <button
              type="button"
              className="lightbox-nav prev"
              aria-label="Foto anterior"
              onClick={(e) => {
                e.stopPropagation();
                setLightbox((lb) => (lb ? { ...lb, index: (lb.index - 1 + lb.urls.length) % lb.urls.length } : lb));
              }}
            >
              <i className="ri-arrow-left-s-line" aria-hidden="true" />
            </button>
          )}
          <img
            src={lightbox.urls[lightbox.index]}
            alt={`${lightbox.title} — foto ${lightbox.index + 1}`}
            onClick={(e) => e.stopPropagation()}
          />
          {lightbox.urls.length > 1 && (
            <button
              type="button"
              className="lightbox-nav next"
              aria-label="Próxima foto"
              onClick={(e) => {
                e.stopPropagation();
                setLightbox((lb) => (lb ? { ...lb, index: (lb.index + 1) % lb.urls.length } : lb));
              }}
            >
              <i className="ri-arrow-right-s-line" aria-hidden="true" />
            </button>
          )}
          <span className="lightbox-cap">
            {lightbox.title} · foto {lightbox.index + 1} de {lightbox.urls.length}
          </span>
        </div>
      )}
    </div>
  );
}