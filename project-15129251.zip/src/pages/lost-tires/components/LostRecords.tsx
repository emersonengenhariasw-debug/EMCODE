import type { LostTireRecord } from "@/lib/lostTiresTypes";

interface Props {
  records: LostTireRecord[];
  onLoad: (record: LostTireRecord) => void;
  onViewPhotos: (record: LostTireRecord) => void;
  onDelete: (id: string) => void;
}

/** ISO yyyy-mm-dd → DD/MM/AAAA. */
function fmtDate(iso: string): string {
  if (!iso) return "—";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : iso;
}

export default function LostRecords({ records, onLoad, onViewPhotos, onDelete }: Props) {
  if (records.length === 0) {
    return (
      <p className="lost-empty">
        <i className="ri-inbox-line" aria-hidden="true" />
        Nenhum registro de pneu perdido ainda. Preencha o checklist acima e clique em FINALIZAR
        REGISTRO.
      </p>
    );
  }

  return (
    <div className="lost-table-wrap">
      <table className="lost-table">
        <thead>
          <tr>
            <th>Nº Registro</th>
            <th>Data</th>
            <th>Operador</th>
            <th>Equipamento</th>
            <th>Posição</th>
            <th>Marca</th>
            <th>Fogo</th>
            <th>Motivo da perda</th>
            <th>Fotos</th>
            <th>Situação</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {records.map((r) => (
            <tr key={r.id}>
              <td><b>{r.registro}</b></td>
              <td>{fmtDate(r.dataOcorrencia)}</td>
              <td>{r.operador || "—"}</td>
              <td>{r.equipamento || "—"}</td>
              <td>{r.posicao || "—"}</td>
              <td>{r.marca || "—"}</td>
              <td>{r.fogo || "—"}</td>
              <td>{r.motivo || "—"}</td>
              <td>
                <i className="ri-image-2-line" aria-hidden="true" /> {r.fotos.length}
              </td>
              <td>
                <span className={`lost-badge ${r.status === "finalizado" ? "final" : "draft"}`}>
                  {r.status === "finalizado" ? "Finalizado" : "Rascunho"}
                </span>
              </td>
              <td>
                <div className="lost-row-actions">
                  <button
                    type="button"
                    className="lost-icon-btn"
                    title="Abrir no formulário"
                    aria-label={`Abrir registro ${r.registro}`}
                    onClick={() => onLoad(r)}
                  >
                    <i className="ri-folder-open-line" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    className="lost-icon-btn"
                    title="Visualizar fotos"
                    aria-label={`Visualizar fotos do registro ${r.registro}`}
                    onClick={() => onViewPhotos(r)}
                    disabled={r.fotos.length === 0}
                  >
                    <i className="ri-image-line" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    className="lost-icon-btn danger"
                    title="Excluir registro"
                    aria-label={`Excluir registro ${r.registro}`}
                    onClick={() => onDelete(r.id)}
                  >
                    <i className="ri-delete-bin-line" aria-hidden="true" />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}