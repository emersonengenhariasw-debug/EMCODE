import { useRef } from "react";
import type { ChangeEvent } from "react";
import type { PhotoDraft } from "@/lib/lostTiresTypes";

interface Props {
  fotos: PhotoDraft[];
  onAdd: (files: File[]) => void;
  onRemove: (id: string) => void;
  onZoom: (index: number) => void;
}

export default function LostPhotoField({ fotos, onAdd, onRemove, onZoom }: Props) {
  const camRef = useRef<HTMLInputElement>(null);
  const galRef = useRef<HTMLInputElement>(null);

  const handle = (e: ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (list && list.length) onAdd(Array.from(list));
    e.target.value = "";
  };

  return (
    <div className="lost-photo-block">
      <div className="os-block-label lost-photo-label">
        <span>
          Fotos do pneu perdido <b className="lost-req">*</b>
        </span>
        <span className="lost-photo-count">
          {fotos.length} {fotos.length === 1 ? "anexada" : "anexadas"}
        </span>
      </div>

      <div className="lost-photo-actions">
        <button type="button" className="btn btn-solid btn-sm" onClick={() => camRef.current?.click()}>
          <i className="ri-camera-line" aria-hidden="true" /> Tirar foto
        </button>
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => galRef.current?.click()}>
          <i className="ri-image-add-line" aria-hidden="true" /> Escolher da galeria
        </button>
      </div>

      <input
        ref={camRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="lost-file-input"
        onChange={handle}
        aria-label="Tirar foto do pneu perdido"
      />
      <input
        ref={galRef}
        type="file"
        accept="image/*"
        multiple
        className="lost-file-input"
        onChange={handle}
        aria-label="Escolher fotos da galeria"
      />

      {fotos.length === 0 ? (
        <p className="lost-photo-empty">
          <i className="ri-camera-off-line" aria-hidden="true" />
          Anexe pelo menos 1 foto do pneu perdido. Sem foto não é possível finalizar o registro.
        </p>
      ) : (
        <ul className="lost-photo-grid">
          {fotos.map((f, i) => (
            <li key={f.id} className="lost-photo">
              <button
                type="button"
                className="lost-photo-img"
                onClick={() => onZoom(i)}
                aria-label={`Ampliar foto ${i + 1}`}
              >
                {f.previewUrl ? (
                  <img src={f.previewUrl} alt={`Foto ${i + 1} do pneu perdido`} />
                ) : (
                  <i className="ri-image-line" aria-hidden="true" />
                )}
              </button>
              <button
                type="button"
                className="lost-photo-remove"
                onClick={() => onRemove(f.id)}
                aria-label={`Remover foto ${i + 1}`}
              >
                <i className="ri-close-line" aria-hidden="true" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {fotos.length > 0 && (
        <p className="lost-photo-hint">
          <i className="ri-information-line" aria-hidden="true" />
          Toque na foto para ampliar. Cada imagem recebe data e hora no envio e fica vinculada ao
          número do registro.
        </p>
      )}
    </div>
  );
}