import { useMemo } from "react";
import type { LostTireRecord } from "@/lib/lostTiresTypes";

interface Props {
  records: LostTireRecord[];
}

interface Agg {
  label: string;
  count: number;
}

function groupBy(rows: LostTireRecord[], pick: (r: LostTireRecord) => string): Agg[] {
  const map = new Map<string, number>();
  rows.forEach((r) => {
    const key = pick(r);
    map.set(key, (map.get(key) ?? 0) + 1);
  });
  return Array.from(map.entries())
    .map(([label, count]) => ({ label, count }))
    .sort((a, b) => b.count - a.count || a.label.localeCompare(b.label));
}

function monthLabel(iso: string): string {
  const m = /^(\d{4})-(\d{2})/.exec(iso);
  return m ? `${m[2]}/${m[1]}` : "Sem data";
}

function BarList({ items }: { items: Agg[] }) {
  if (items.length === 0) {
    return <p className="lost-empty"><i className="ri-information-line" aria-hidden="true" /> Sem dados no período.</p>;
  }
  const max = items[0]?.count ?? 1;
  return (
    <ul className="lost-ind-list">
      {items.map((it) => (
        <li key={it.label} className="lost-ind-item">
          <span className="nm">{it.label}</span>
          <span className="lost-ind-track">
            <span className="lost-ind-bar" style={{ width: `${Math.max(6, Math.round((it.count / max) * 100))}%` }} />
          </span>
          <span className="qt">{it.count}</span>
        </li>
      ))}
    </ul>
  );
}

export default function LostIndicators({ records }: Props) {
  const finalized = useMemo(() => records.filter((r) => r.status === "finalizado"), [records]);

  const byEquip = useMemo(() => groupBy(finalized, (r) => r.equipamento.trim() || "Sem equipamento"), [finalized]);
  const byOperador = useMemo(() => groupBy(finalized, (r) => r.operador.trim() || "Sem operador"), [finalized]);
  const byMotivo = useMemo(() => groupBy(finalized, (r) => r.motivo.trim() || "Sem motivo"), [finalized]);
  const byMes = useMemo(() => groupBy(finalized, (r) => monthLabel(r.dataOcorrencia)), [finalized]);

  const finalComFoto = finalized.filter((r) => r.fotos.length > 0).length;

  return (
    <div className="lost-ind">
      <div className="lost-ind-grid">
        <div className="lost-ind-card">
          <b>{finalized.length}</b>
          <span>Pneus perdidos (finalizados)</span>
        </div>
        <div className="lost-ind-card">
          <b>{byEquip.length}</b>
          <span>Equipamentos distintos</span>
        </div>
        <div className="lost-ind-card">
          <b>{byMotivo.length}</b>
          <span>Motivos distintos</span>
        </div>
        <div className="lost-ind-card">
          <b>{finalComFoto}</b>
          <span>Com fotos anexadas</span>
        </div>
      </div>

      <div className="lost-ind-section">
        <h3><i className="ri-truck-line" aria-hidden="true" /> Quantidade por equipamento</h3>
        <BarList items={byEquip} />
      </div>

      <div className="lost-ind-section">
        <h3><i className="ri-user-line" aria-hidden="true" /> Quantidade por operador</h3>
        <BarList items={byOperador} />
      </div>

      <div className="lost-ind-section">
        <h3><i className="ri-tools-line" aria-hidden="true" /> Quantidade por motivo</h3>
        <BarList items={byMotivo} />
      </div>

      <div className="lost-ind-section">
        <h3><i className="ri-calendar-line" aria-hidden="true" /> Quantidade por mês</h3>
        <BarList items={byMes} />
      </div>

      <p className="summary-foot">
        Indicadores exclusivos do painel de pneus perdidos · consideram apenas registros
        finalizados. Não se misturam com o painel de manutenção nem com as OS de movimentação.
      </p>
    </div>
  );
}