import { Link } from "react-router-dom";

export default function LostNav() {
  return (
    <header className="lost-nav">
      <Link className="lost-nav-brand" to="/" aria-label="JULY QUARTZO — Mineração e Construção, início">
        <img
          className="brand-mark"
          src="https://public.readdy.ai/ai/img_res/a156b410-a185-484d-93b1-98da19bdb609.png"
          alt="JULY QUARTZO — Mineração e Construção"
        />
      </Link>

      <div className="lost-nav-title">
        <span className="lost-nav-kicker">Painel exclusivo</span>
        <b>Pneus Perdidos</b>
      </div>

      <nav className="lost-nav-actions" aria-label="Navegação do painel de pneus perdidos">
        <a className="lost-nav-link" href="#lost-form">Novo registro</a>
        <a className="lost-nav-link" href="#lost-historico">Consultar</a>
        <Link className="lost-nav-back" to="/">
          <i className="ri-arrow-left-line" aria-hidden="true" /> Voltar às OS
        </Link>
      </nav>
    </header>
  );
}