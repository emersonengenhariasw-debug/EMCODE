import { BrowserRouter } from "react-router-dom";
import { AppRoutes } from "./router";
import { I18nextProvider } from "react-i18next";
import i18n from "./i18n";
import RouteSeoManager from "@/components/feature/RouteSeoManager";
import StructuredData from "@/components/feature/StructuredData";
import AppSplash from "@/components/feature/AppSplash";


function App() {
  return (
    <I18nextProvider i18n={i18n}>
      <AppSplash />
      <BrowserRouter basename={__BASE_PATH__}>
        <RouteSeoManager />
        <StructuredData />
        <AppRoutes />
      </BrowserRouter>
    </I18nextProvider>
  );
}

export default App;
