import { useEffect, useMemo, useState } from "react";
import { isStandaloneApp } from "@/hooks/useInstallPrompt";

/* Verificações reais de instalabilidade da PWA, feitas no próprio navegador.
   Nada é presumido: HTTPS, manifesto e service worker são consultados de fato. */
export type ReadinessCheck = {
  id: string;
  label: string;
  detail: string;
  ok: boolean | null;
};

type BaseState = {
  secure: boolean | null;
  manifest: boolean | null;
  serviceWorker: boolean | null;
  standalone: boolean;
};

export function usePwaReadiness(canPrompt: boolean): ReadinessCheck[] {
  const [base, setBase] = useState<BaseState>({
    secure: null,
    manifest: null,
    serviceWorker: null,
    standalone: false,
  });

  useEffect(() => {
    let alive = true;

    const run = async () => {
      const secure =
        typeof window !== "undefined" &&
        (window.isSecureContext || window.location.protocol === "https:");

      let manifest = false;
      const link = document.querySelector<HTMLLinkElement>('link[rel="manifest"]');
      if (link) {
        try {
          const response = await fetch(link.href, { cache: "no-store" });
          manifest = response.ok;
        } catch {
          manifest = false;
        }
      }

      let serviceWorker = false;
      try {
        if ("serviceWorker" in navigator) {
          const registrations = await navigator.serviceWorker.getRegistrations();
          serviceWorker = registrations.some(
            (reg) => Boolean(reg.active || reg.installing || reg.waiting),
          );
        }
      } catch {
        serviceWorker = false;
      }

      if (!alive) return;
      setBase({ secure, manifest, serviceWorker, standalone: isStandaloneApp() });
    };

    run();
    return () => {
      alive = false;
    };
  }, []);

  return useMemo<ReadinessCheck[]>(() => {
    const status = (value: boolean | null): boolean | null => value;
    return [
      {
        id: "https",
        label: "Conexão segura (HTTPS)",
        detail:
          base.secure === null
            ? "Verificando a conexão…"
            : base.secure
              ? "O endereço usa HTTPS, exigência do navegador para instalar."
              : "O navegador só permite instalar em endereços HTTPS.",
        ok: status(base.secure),
      },
      {
        id: "manifest",
        label: "Manifesto do aplicativo",
        detail:
          base.manifest === null
            ? "Verificando os dados do aplicativo…"
            : base.manifest
              ? "Nome, ícones e cor da marca encontrados e válidos."
              : "O manifesto não respondeu. Recarregue a página antes de instalar.",
        ok: status(base.manifest),
      },
      {
        id: "sw",
        label: "Funcionamento como aplicativo",
        detail:
          base.serviceWorker === null
            ? "Verificando o suporte offline…"
            : base.serviceWorker
              ? "A estrutura do sistema já está pronta para abrir em tela cheia."
              : "Ainda preparando o aplicativo. Recarregue a página e tente de novo.",
        ok: status(base.serviceWorker),
      },
      {
        id: "prompt",
        label: "Instalação direta neste navegador",
        detail: canPrompt
          ? "Disponível: o botão INSTALAR APLICATIVO abre a janela oficial do navegador."
          : "Não disponível agora: use as instruções do seu aparelho na seção acima.",
        ok: canPrompt,
      },
      {
        id: "standalone",
        label: "Aplicativo aberto como instalado",
        detail: base.standalone
          ? "Este acesso já está no modo aplicativo, sem barras do navegador."
          : "Este acesso está no navegador comum.",
        ok: base.standalone,
      },
    ];
  }, [base, canPrompt]);
}