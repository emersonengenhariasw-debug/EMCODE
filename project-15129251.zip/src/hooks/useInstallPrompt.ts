import { useCallback, useEffect, useState } from "react";
import type { InstallPlatform } from "@/components/feature/InstallGuide";

/* Evento nativo do PWA (Chrome/Edge/Android). Fica disponível após o
   navegador considerar o app instalável. */
export type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

/* Chave única do convite de instalação: quem já instalou ou dispensou não
   recebe o convite de novo. O botão da página /instalar continua sempre lá. */
const DISMISS_KEY = "jqz:install-invite-dismissed";

/* Detecta o dispositivo para mostrar as instruções certas quando a instalação
   automática não estiver disponível. */
export function detectInstallPlatform(): InstallPlatform {
  if (typeof navigator === "undefined") return "other";
  const ua = navigator.userAgent || "";
  const touchPoints = navigator.maxTouchPoints || 0;
  const isIPad = /Macintosh/.test(ua) && touchPoints > 1;
  if (/iPad|iPhone|iPod/.test(ua) || isIPad) return "ios";
  if (/Android/i.test(ua)) return "android";
  return "desktop";
}

/* O app está aberto como aplicativo instalado (fora do navegador comum)?
   Considera standalone, fullscreen, minimal-ui e o modo legado do iOS. */
export function isStandaloneApp(): boolean {
  if (typeof window === "undefined") return false;
  const modes = ["standalone", "fullscreen", "minimal-ui"];
  const media = modes.some((mode) =>
    window.matchMedia(`(display-mode: ${mode})`).matches,
  );
  const legacy =
    (navigator as unknown as { standalone?: boolean }).standalone === true;
  return media || legacy;
}

function readDismissed(): boolean {
  try {
    return window.localStorage.getItem(DISMISS_KEY) === "1";
  } catch {
    /* armazenamento bloqueado — trata como não dispensado */
    return false;
  }
}

function writeDismissed(): void {
  try {
    window.localStorage.setItem(DISMISS_KEY, "1");
  } catch {
    /* armazenamento bloqueado — o convite volta na próxima visita */
  }
}

/* Lógica compartilhada de instalação: guarda o evento de instalação,
   sabe se o app já está instalado e dispara a solicitação após a ação
   da pessoa (nunca automaticamente). */
export function useInstallPrompt() {
  const [deferred, setDeferred] = useState<InstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [justInstalled, setJustInstalled] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [standalone, setStandalone] = useState(false);
  const [platform] = useState<InstallPlatform>(() => detectInstallPlatform());

  useEffect(() => {
    setDismissed(readDismissed());
    setStandalone(isStandaloneApp());

    const queries = ["standalone", "fullscreen", "minimal-ui"].map((mode) =>
      window.matchMedia(`(display-mode: ${mode})`),
    );

    const onBeforeInstall = (event: Event) => {
      event.preventDefault();
      setDeferred(event as InstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setJustInstalled(true);
      setDeferred(null);
      setDismissed(true);
      writeDismissed();
    };
    const onMediaChange = () => setStandalone(isStandaloneApp());

    window.addEventListener("beforeinstallprompt", onBeforeInstall);
    window.addEventListener("appinstalled", onInstalled);
    queries.forEach((query) => query.addEventListener("change", onMediaChange));

    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstall);
      window.removeEventListener("appinstalled", onInstalled);
      queries.forEach((query) => query.removeEventListener("change", onMediaChange));
    };
  }, []);

  /* Dispara a solicitação nativa de instalação. Retorna o desfecho real
     informado pelo navegador — nada é simulado. */
  const promptInstall = useCallback(async (): Promise<
    "accepted" | "dismissed" | "unavailable"
  > => {
    const event = deferred;
    if (!event) return "unavailable";

    try {
      await event.prompt();
    } catch {
      /* o navegador cancelou a abertura — cai no guia manual */
      return "unavailable";
    }

    let outcome: "accepted" | "dismissed" = "dismissed";
    try {
      const choice = await event.userChoice;
      outcome = choice.outcome;
    } catch {
      /* janela fechada sem resposta — considera cancelado */
    }

    setDeferred(null);
    return outcome;
  }, [deferred]);

  /* Guarda que a pessoa não quer mais ver o convite. */
  const dismissInvite = useCallback(() => {
    setDismissed(true);
    writeDismissed();
  }, []);

  const clearJustInstalled = useCallback(() => setJustInstalled(false), []);

  return {
    deferred,
    canPrompt: Boolean(deferred),
    installed,
    justInstalled,
    clearJustInstalled,
    dismissed,
    dismissInvite,
    standalone,
    alreadyInstalled: installed || standalone,
    platform,
    promptInstall,
  };
}