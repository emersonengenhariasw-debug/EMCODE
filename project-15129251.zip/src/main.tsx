import { StrictMode } from 'react'
import './i18n'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'

/* PWA — manifesto + service worker (arquivos publicados na raiz do site).
   A injeção do link e o registro são silenciosos: não afetam o uso normal do app. */
const basePath = import.meta.env.BASE_URL || '/'

if (typeof document !== 'undefined' && !document.querySelector('link[rel="manifest"]')) {
  const manifestLink = document.createElement('link')
  manifestLink.rel = 'manifest'
  manifestLink.href = `${basePath}manifest.webmanifest`
  document.head.appendChild(manifestLink)
}

if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
  // Só recarrega quando ESTA aba pediu a troca de versão — evita loop e
  // evita recarregar na primeira instalação.
  let updateRequested = false

  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register(`${basePath}sw.js`)
      .then((reg) => {
        reg.addEventListener('updatefound', () => {
          const next = reg.installing
          if (!next) return
          next.addEventListener('statechange', () => {
            // Nova versão instalada e já existe uma em uso → assume o controle.
            if (next.state === 'installed' && navigator.serviceWorker.controller) {
              updateRequested = true
              next.postMessage({ type: 'SKIP_WAITING' })
            }
          })
        })
      })
      .catch(() => {
        /* registro silencioso — o app continua funcionando normalmente */
      })
  })

  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (!updateRequested) return
    updateRequested = false
    window.location.reload()
  })
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)