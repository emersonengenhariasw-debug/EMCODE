import type { RouteObject } from "react-router-dom";
import NotFound from "@/pages/NotFound";
import Home from "@/pages/home/page";
import InstallPage from "@/pages/install/page";

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/instalar",
    element: <InstallPage />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
];

export default routes;