import { useEffect, useState } from "react";
import InstallGuide from "@/components/feature/InstallGuide";
import { useInstallPrompt } from "@/hooks/useInstallPrompt";

export default function InstallApp() {
  const {
    canPrompt,
    alreadyInstalled,
    justInstalled,
    clearJustInstalled,
    dismissed,
    dismissInvite,
    platform,
    promptInstall,
  } = useInstallPrompt();

  const [guideOpen, setGuideOpen] = useState(false);
  const [installing, setInstalling] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  /* Confirmação de instalação fica na tela por alguns segundos e sai sozinha. */
  useEffect(() => {
    if (!justInstalled) return undefined;
    const timer = window.setTimeout(() => clearJustInstalled(), 12000);
    return () => window.clearTimeout(timer);
  }, [justInstalled, clearJustInstalled]);

  useEffect(() => {
    if (!notice) return undefined;
    const timer = window.setTimeout(() => setNotice(null), 7000);
    return () => window.clearTimeout(timer);
  }, [notice]);

  const handleInstall = async () => {
    if (installing) return;

    /* Sem instalação direta: a ação real e compatível é abrir as instruções
       do navegador/aparelho em uso — nunca um botão decorativo. */
    if (!canPrompt) {
      setGuideOpen(true);
      return;
    }

    setInstalling(true);
    const outcome = await promptInstall();
    setInstalling(false);

    if (outcome === "accepted") {
      setNotice("Instalação confirmada. Abra o aplicativo pelo ícone da tela inicial.");
      return;
    }

    if (outcome === "dismissed") {
      setNotice("Instalação cancelada. Você pode concluir depois pelo menu do navegador.");
      setGuideOpen(true);
      return;
    }

    setGuideOpen(true);
  };

  /* Já instalado ou convite dispensado: não insiste mais na tela. */
  if (dismissed || alreadyInstalled) return null;

  return (
    <>
      {notice && (
        <div className="install-fab-note" role="status" aria-live="polite">
          <i className="ri-information-line" aria-hidden="true" />
          <span>{notice}</span>
        </div>
      )}

      <div className="install-fab">
        <button
          type="button"
          className="install-fab-btn"
          onClick={handleInstall}
          disabled={installing}
          aria-label="Instalar o aplicativo JQZ na tela inicial"
        >
          <i className="ri-smartphone-line install-fab-ico" aria-hidden="true" />
          <span className="install-fab-label">
            {installing ? "ABRINDO INSTALAÇÃO..." : "INSTALAR APP JQZ"}
          </span>
          <span className="install-fab-label-short">INSTALAR</span>
        </button>
        <button
          type="button"
          className="install-fab-close"
          onClick={dismissInvite}
          aria-label="Ocultar convite de instalação"
        >
          <i className="ri-close-line" aria-hidden="true" />
        </button>
      </div>

      {guideOpen && (
        <InstallGuide
          onClose={() => setGuideOpen(false)}
          hasNativePrompt={canPrompt}
          platform={platform}
        />
      )}
    </>
  );
}