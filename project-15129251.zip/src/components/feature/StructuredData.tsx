import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { buildHomeSchemas } from "@/lib/seo/schema";

const SCRIPT_ID = "route-jsonld";

/**
 * Injects Schema.org JSON-LD for indexable routes only.
 * Deliberately separate from the runtime OG/Twitter head manager.
 */
export default function StructuredData() {
  const location = useLocation();

  useEffect(() => {
    const existing = document.getElementById(SCRIPT_ID);

    if (location.pathname !== "/") {
      if (existing) existing.remove();
      return;
    }

    let el = existing as HTMLScriptElement | null;
    if (!el) {
      el = document.createElement("script");
      el.type = "application/ld+json";
      el.id = SCRIPT_ID;
      document.head.appendChild(el);
    }
    el.textContent = JSON.stringify(buildHomeSchemas());
  }, [location.pathname]);

  return null;
}