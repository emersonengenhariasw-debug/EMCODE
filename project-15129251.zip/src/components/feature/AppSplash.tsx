import { useEffect, useState } from "react";

/* Tela de abertura (splash) da JULY QUARTZO — Borracharia Digital.
   - Usa EXATAMENTE o logotipo institucional enviado (verde + dourado),
     agora com fundo transparente: aparece centralizado, sem bordas nem
     retângulos indesejados sobre o fundo verde-escuro da marca.
   - Um pneu realista com reflexos dourados sutis é integrado ao fundo,
     bem discreto, atrás do logotipo (sem cobrir letras nem prejudicar a leitura).
   - Montada uma única vez na raiz do app: aparece ao abrir/reiniciar e NÃO
     reaparece ao navegar entre as telas.
   - O logotipo é exibido com proporção preservada (sem esticar, distorcer ou
     cortar) e se adapta a celular, tablet e computador.
   - Camada puramente visual: fica POR CIMA do sistema, sem bloquear o
     carregamento, as rotas, a autenticação ou o fluxo normal do app. */

// Logotipo oficial enviado (fundo removido, preservando logo, letras e cores).
const SPLASH_URL =
  "https://public.readdy.ai/ai/img_res/0798eab8-394f-4dd7-be7e-c383f5f2484f.png";

// Pneu realista com reflexos dourados — integrado ao fundo verde-escuro.
const TIRE_URL =
  "https://readdy.ai/api/search-image?query=cinematic%20dark%20deep%20green%20studio%20backdrop%20with%20a%20large%20realistic%20black%20truck%20tire%20in%20the%20background%2C%20detailed%20aggressive%20tread%20pattern%2C%20subtle%20golden%20metallic%20rim%20reflections%2C%20soft%20dramatic%20rim%20lighting%2C%20deep%20empty%20dark%20center%20space%2C%20premium%20automotive%20luxury%20mood%2C%20elegant%20minimal%20composition%2C%20high%20detail&width=1920&height=1080&seq=jqz-splash-tire-2026-a1&orientation=landscape";

const HOLD_MS = 2000; // duração visível da abertura (~2 s)
const FADE_MS = 500; // transição suave de saída

export default function AppSplash() {
  const [phase, setPhase] = useState<"enter" | "leaving" | "done">("enter");

  useEffect(() => {
    const leaveTimer = window.setTimeout(() => setPhase("leaving"), HOLD_MS);
    const doneTimer = window.setTimeout(
      () => setPhase("done"),
      HOLD_MS + FADE_MS,
    );
    return () => {
      window.clearTimeout(leaveTimer);
      window.clearTimeout(doneTimer);
    };
  }, []);

  if (phase === "done") return null;

  return (
    <div
      className={`app-splash${phase === "leaving" ? " is-leaving" : ""}`}
      role="presentation"
      aria-hidden="true"
    >
      <div className="app-splash-bg" />
      <img
        className="app-splash-tire"
        src={TIRE_URL}
        alt=""
        aria-hidden="true"
      />
      <div className="app-splash-veil" />
      <div className="app-splash-glow" />
      <img
        className="app-splash-poster"
        src={SPLASH_URL}
        alt="JULY QUARTZO — Mineração e Construção · Borracharia Digital"
      />
      <div className="app-splash-sheen" />
      <div className="app-splash-vignette" />
    </div>
  );
}