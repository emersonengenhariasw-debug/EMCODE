import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { resolveRouteSeo } from "@/lib/seo/routeSeo";

function upsertMeta(attr: "name" | "property", key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

function removeMeta(attr: "name" | "property", key: string) {
  const el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
  if (el) el.remove();
}

function upsertCanonical(href: string) {
  let el = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
  if (!el) {
    el = document.createElement("link");
    el.setAttribute("rel", "canonical");
    document.head.appendChild(el);
  }
  el.setAttribute("href", href);
}

/**
 * Single centralized, route-aware head manager for the SPA.
 * Rewrites every managed tag on each route change so no metadata
 * from a previous route can leak into the next one.
 */
export default function RouteSeoManager() {
  const location = useLocation();

  useEffect(() => {
    const seo = resolveRouteSeo(location.pathname);

    document.title = seo.title;
    upsertMeta("name", "description", seo.description);
    upsertMeta("name", "keywords", seo.keywords);
    upsertMeta("name", "robots", seo.robots);
    upsertCanonical(seo.canonical);

    upsertMeta("property", "og:type", seo.ogType);
    upsertMeta("property", "og:title", seo.ogTitle);
    upsertMeta("property", "og:description", seo.ogDescription);
    upsertMeta("property", "og:url", seo.canonical);
    if (seo.ogImage) {
      upsertMeta("property", "og:image", seo.ogImage);
    } else {
      removeMeta("property", "og:image");
    }

    upsertMeta("name", "twitter:card", seo.twitterCard);
    upsertMeta("name", "twitter:title", seo.ogTitle);
    upsertMeta("name", "twitter:description", seo.ogDescription);
    if (seo.ogImage) {
      upsertMeta("name", "twitter:image", seo.ogImage);
    } else {
      removeMeta("name", "twitter:image");
    }
  }, [location.pathname]);

  return null;
}