export type InstallPlatform = "ios" | "android" | "desktop" | "other";

type InstallGuideProps = {
  onClose: () => void;
  hasNativePrompt?: boolean;
  platform?: InstallPlatform;
};

type Step = { title: string; detail: string };

const ANDROID_STEPS: Step[] = [
  { title: "Abra pelo Google Chrome", detail: "no celular ou tablet Android." },
  { title: "Toque no menu (⋮)", detail: "no canto superior direito do navegador." },
  { title: "Toque em \"Instalar aplicativo\"", detail: "ou em \"Adicionar à tela inicial\"." },
  { title: "Confirme o nome JULY QUARTZO", detail: "e aguarde o ícone aparecer." },
  { title: "Abra pelo ícone", detail: "o sistema entra direto no formulário da OS." },
];

const IOS_STEPS: Step[] = [
  { title: "Abra pelo Safari", detail: "no iPhone ou iPad (a instalação não funciona pelo Chrome no iOS)." },
  { title: "Toque em Compartilhar", detail: "no ícone do quadrado com a seta para cima, na barra inferior." },
  { title: "Toque em \"Adicionar à Tela de Início\"", detail: "role a lista de opções até encontrar." },
  { title: "Confirme o nome JULY QUARTZO", detail: "e toque em \"Adicionar\"." },
  { title: "Abra pelo ícone", detail: "o sistema entra direto no formulário da OS." },
];

const DESKTOP_STEPS: Step[] = [
  { title: "Abra pelo Chrome ou Edge", detail: "no computador." },
  { title: "Clique no ícone de instalação", detail: "que aparece na barra de endereço (uma telinha com uma seta)." },
  { title: "Clique em \"Instalar\"", detail: "e confirme o nome JULY QUARTZO." },
  { title: "Abra pelo atalho criado", detail: "na área de trabalho ou no menu iniciar." },
];

export default function InstallGuide({ onClose, hasNativePrompt = false, platform = "other" }: InstallGuideProps) {
  const steps = platform === "ios" ? IOS_STEPS : platform === "desktop" ? DESKTOP_STEPS : ANDROID_STEPS;

  const intro = hasNativePrompt
    ? "Se a janela de instalação não apareceu, siga os passos rápidos abaixo."
    : platform === "ios"
      ? "No iPhone e no iPad a instalação é feita pelo Safari, seguindo estes passos rápidos."
      : platform === "desktop"
        ? "Siga os passos rápidos abaixo para instalar no computador."
        : "No momento o navegador não ofereceu a instalação automática. Siga os passos rápidos abaixo.";

  const tipIcon = platform === "desktop" ? "ri-computer-line" : platform === "ios" ? "ri-smartphone-line" : "ri-tablet-line";
  const tipText =
    platform === "ios"
      ? "Dica para iPhone e iPad: depois de adicionar, o JULY QUARTZO abre em tela cheia, com cara de aplicativo."
      : platform === "desktop"
        ? "Dica: o aplicativo instalado abre em uma janela própria, sem as barras do navegador."
        : "Dica para tablet: vire o aparelho na horizontal para ver o formulário completo com mais conforto.";

  return (
    <div className="modal-veil" role="dialog" aria-modal="true" aria-label="Como instalar o aplicativo" onClick={onClose}>
      <div className="install-guide" onClick={(e) => e.stopPropagation()}>
        <h3>Instalar o aplicativo</h3>
        <p>{intro}</p>

        <ol className="install-steps">
          {steps.map((step) => (
            <li className="install-step" key={step.title}>
              <span className="install-step-num">{steps.indexOf(step) + 1}</span>
              <span className="install-step-text">
                <b>{step.title}</b> {step.detail}
              </span>
            </li>
          ))}
        </ol>

        <div className="install-tip">
          <i className={tipIcon} aria-hidden="true" />
          <span>{tipText}</span>
        </div>

        <div className="modal-actions">
          <button type="button" className="btn btn-primary" onClick={onClose}>
            <i className="ri-check-line" aria-hidden="true" /> Entendi
          </button>
        </div>
      </div>
    </div>
  );
}