import type { LostTireForm } from "@/lib/lostTiresTypes";

/* MOTIVO DA PERDA — lista oficial do painel de PNEUS PERDIDOS.
   Isolada dos motivos das OS: nenhum item daqui aparece nas OS. */
export const LOST_MOTIVES: string[] = [
  "1 - DESGASTE PREMATURO",
  "2 - CORTE LATERAL",
  "3 - CORTE NA BANDA",
  "4 - CORTE NO OMBRO",
  "5 - ESTOURO",
  "6 - FURO POR METAL",
  "7 - ARRANCAMENTO DE BORRACHA",
  "8 - RODA DANIFICADA",
  "9 - CÂMARA DE AR DANIFICADA",
  "10 - PROTETOR DANIFICADO",
  "11 - ACIDENTE OPERACIONAL",
  "12 - FALHA MECÂNICA",
  "13 - PNEU IRRECUPERÁVEL",
  "14 - OUTROS",
];

/** Exige descrição quando o motivo for OUTROS. */
export const LOST_OTHER_LABEL = "14 - OUTROS";

export const LOST_TURMA_OPTIONS = ["A", "B", "C", "D", "E"];

export const LOST_POSITION_OPTIONS = [
  "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Estepe",
];

export const createEmptyLost = (): LostTireForm => ({
  registro: "",
  dataOcorrencia: "",
  operador: "",
  equipamento: "",
  posicao: "",
  marca: "",
  fogo: "",
  mm: "",
  horimetro: "",
  local: "",
  turma: "",
  motivo: "",
  motivoOutros: "",
  descricao: "",
  responsavel: "",
  observacoes: "",
});