import type { OsFormData } from "@/lib/osTypes";

/* MOTIVO (S) / CAUSA (S) — reproduced exactly as on the physical OS.
   Repeated codes (15, 15) and the out-of-order 14 are intentional and must stay. */
export const OS_MOTIVES: string[][] = [
  [
    "1-DESGASTE - FIM DE VIDA (REFORMAR)",
    "2-ACIDENTE (CORTE LATERAL)",
    "3-ACIDENTE (CORTE BANDA)",
    "4-ACIDENTE (CORTE OMBRO)",
  ],
  [
    "5-ACIDENTE (ESTOURO)",
    "6-RODÍZIO",
    "7-DEFEITO",
    "8-SUCATA/DESCARTE",
  ],
  [
    "9-RESERVA",
    "10-TROCA HORÍMETRO",
    "11-FURO POR METAL",
    "12-DEFEITO",
  ],
  [
    "13-ARRANCAMENTO BORRACHA",
    "15-RODA DANIFICADA",
    "15-CÂMARA DE AR DANIFICADA",
    "14-PROTETOR DANIFICADO",
  ],
];

export const OS_TURNO_OPTIONS = [
  "ADM",
  "1",
  "2",
  "3",
];

/* Turma/Letra — ADM + letras A, B e C. */
export const OS_TURMA_OPTIONS = ["ADM", "A", "B", "C"];

/* Motive codes 1..15 offered by the MOTIVO column of "Pneu retirado". */
export const OS_MOTIVO_CODES = [
  "1", "2", "3", "4", "5", "6", "7", "8",
  "9", "10", "11", "12", "13", "14", "15",
];

/* Códigos de motivo que EXIGEM registro fotográfico (perda, acidente ou avaria).
   Acidentes (2,3,4,5), Furo por metal (11), Arrancamento (13),
   Roda danificada / Câmara de ar (15) e Protetor danificado (14).
   Rodízio (6), Reserva (9) e Troca Horímetro (10) NÃO exigem foto. */
export const OS_PHOTO_REQUIRED_CODES = ["2", "3", "4", "5", "11", "13", "14", "15"];

/** Código (dígitos iniciais) de um motivo em texto. */
function motiveCode(value: string): string {
  const m = /^\s*(\d+)/.exec(value || "");
  return m ? m[1] : "";
}

/** True quando a movimentação envolve perda/acidente/avaria e exige foto. */
export function osRequiresPhoto(form: OsFormData): boolean {
  const codes = new Set(OS_PHOTO_REQUIRED_CODES);
  if (form.motivos.some((m) => codes.has(motiveCode(m)))) return true;
  return form.retirados.some((r) => codes.has(motiveCode(r.motivo)));
}

/* Number of editable lines kept in each table, matching the printed sheet. */
export const OS_REMOVED_ROWS = 10;
export const OS_INSTALLED_ROWS = 10;

/* A blank order — the values never carry over between orders. */
export const createEmptyOs = (): OsFormData => ({
  numero: "",
  turno: "",
  inicio: "",
  termino: "",
  horimetro: "",
  data: "",
  dataEntrada: "",
  dataSaida: "",
  operador: "",
  km: "",
  equip: "",
  executantes: "",
  local: "",
  turma: "",
  retirados: Array.from({ length: OS_REMOVED_ROWS }, () => ({
    posicao: "",
    marca: "",
    fogo: "",
    mm: "",
    motivo: "",
    vidas: "",
  })),
  instalados: Array.from({ length: OS_INSTALLED_ROWS }, () => ({
    marca: "",
    fogo: "",
    mm: "",
    vidas: "",
  })),
  motivos: [],
  observacoes: "",
  supervisorNome: "",
  fotos: [],
});

/* Ten tire positions of the equipment (top view, cab first). */
export const TRUCK_POSITIONS_LABEL = [
  "1 — 2",
  "3 — 4 | 5 — 6",
  "7 — 8 | 9 — 10",
];